"""Hlási, keď ostrovček číta kľúč, ktorý GUI nepozná (po pridaní novej voľby do kódu treba spustiť tools/gen_schema.py)."""
import json, os, subprocess, sys, tempfile, unittest
ROOT = os.path.join(os.path.dirname(__file__), '..')
sys.path.insert(0, ROOT)
import schema

REPO = os.environ.get('DI_REPO', os.path.join(ROOT, '..', 'dynamic-island'))


@unittest.skipUnless(os.path.isdir(os.path.join(REPO, 'src')), 'chýba zdrojový kód ostrovčeka (DI_REPO)')
class Coverage(unittest.TestCase):
    def test_all_keys_in_schema(self):
        out = subprocess.run([sys.executable, os.path.join(ROOT, 'tools', 'gen_schema.py'), REPO], capture_output=True, text=True)
        self.assertEqual(out.returncode, 0, out.stderr)
        built = schema.build()
        gen = json.load(open(os.path.join(ROOT, 'schema_gen.json'), encoding='utf8'))
        missing = [(r['section'], r['key']) for r in gen if (r['section'], r['key']) not in built]
        self.assertEqual(missing, [])
        secs = {s for _g, s, _t in schema.sections_in_order()}
        self.assertEqual(sorted({k[0] for k in built} - secs), [])


if __name__ == '__main__':
    unittest.main()
