"""Dymový test GUI: bez GTK (atrapy), len overí, že sa kód stránok a riadkov dá prejsť bez NameError / TypeError."""
import os, sys, types, shutil, tempfile
from unittest.mock import MagicMock

ROOT = os.path.join(os.path.dirname(__file__), '..')
sys.path.insert(0, ROOT)


class Meta(type):
    def __getattr__(cls, n):
        if n.startswith('__'):
            raise AttributeError(n)
        return MagicMock()


class Stub(metaclass=Meta):
    def __init__(self, *a, **k):
        self._v = k
    def __getattr__(self, n):
        if n.startswith('__'):
            raise AttributeError(n)
        return MagicMock()
    @classmethod
    def new(cls, *a, **k):
        return cls()
    @classmethod
    def from_string(cls, *a):
        return None


class Mod(types.ModuleType):
    def __getattr__(self, n):
        if n.startswith('__'):
            raise AttributeError(n)
        v = type(n, (Stub,), {})
        setattr(self, n, v)
        return v


gi = types.ModuleType('gi')
gi.require_version = lambda *a: None
repo = types.ModuleType('gi.repository')
for n in ('Adw', 'Gdk', 'Gio', 'GLib', 'Gtk', 'Pango'):
    setattr(repo, n, Mod(n))
repo.GLib.markup_escape_text = staticmethod(lambda s: s)
repo.GLib.Error = Exception
gi.repository = repo
sys.modules['gi'] = gi
sys.modules['gi.repository'] = repo

import importlib.machinery, importlib.util
loader = importlib.machinery.SourceFileLoader('dis', os.path.join(ROOT, 'dynamic-island-settings'))
spec = importlib.util.spec_from_loader('dis', loader)
dis = importlib.util.module_from_spec(spec)
loader.exec_module(dis)

import schema
from model import Model

d = tempfile.mkdtemp()
p = os.path.join(d, 'config.toml')
shutil.copy(os.environ.get('DI_CONFIG', '/home/claude/rosmapo/dynamic-island/config/dynamic-island/config.toml'), p)
m = Model(p)
w = dis.Window.__new__(dis.Window)
dis.Window.__init__(w, MagicMock(), m)
n = 0
for _g, sec, title in schema.sections_in_order():
    w.build_section(sec); n += 1
w.build_section('')
w.build_other()
for (sec, key), e in m.schema.items():
    if e['type'] != 'modules':
        w.make_row(e); n += 1
for aid in schema.ARRAYS:
    w.build_array_page(aid); n += 1
    w.build_section(aid)
for aid, a in schema.ARRAYS.items():
    for spec in a['specs'].values():
        w.make_row(spec, binding=dis.RecBinding({'fields': {}}, spec, lambda: None))
print('ok', n)
