import os, shutil, sys, tempfile, tomllib, unittest
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
import schema, tomledit
from model import Model, RESET

CFG = os.environ.get('DI_CONFIG', '/home/claude/rosmapo/dynamic-island/config/dynamic-island/config.toml')


class T(unittest.TestCase):
    def setUp(self):
        self.d = tempfile.mkdtemp()
        self.p = os.path.join(self.d, 'config.toml')
        shutil.copy(CFG, self.p)
        self.m = Model(self.p)

    def test_edit_keeps_comments_and_other_values(self):
        before = tomllib.loads(self.m.text)
        n_comments = self.m.text.count('#')
        self.m.set('island', 'font_size', 20)
        self.m.set('capture', 'cursor', True)
        self.m.set('clipboard', 'search', True)
        self.m.set('', 'modules', ['clock', 'audio'])
        self.m.save()
        after = tomllib.loads(open(self.p, encoding='utf8').read())
        self.assertEqual(after['island']['font_size'], 20)
        self.assertEqual(after['modules'], ['clock', 'audio'])
        self.assertEqual(after['capture']['cursor'], True)
        before['island']['font_size'] = 20; before['capture']['cursor'] = True; before['clipboard']['search'] = True; before['modules'] = ['clock', 'audio']
        self.assertEqual(before, after)
        self.assertGreaterEqual(open(self.p, encoding='utf8').read().count('#'), n_comments)
        self.assertEqual(len([n for n in os.listdir(self.d) if '.bak-' in n]), 1)

    def test_reset_comments_key_out(self):
        self.assertTrue(self.m.in_file('island', 'shadow'))
        self.m.reset('island', 'shadow')
        self.assertTrue(self.m.is_default('island', 'shadow'))
        self.m.save()
        self.assertFalse(self.m.in_file('island', 'shadow'))
        self.assertIn('# shadow', self.m.text)
        # opätovné nastavenie a reset nenamnoží komentáre
        self.m.set('island', 'shadow', False); self.m.save()
        self.m.reset('island', 'shadow'); self.m.save()
        self.assertEqual(self.m.text.count('# shadow'), 1)

    def test_default_not_written(self):
        e = self.m.entry('island', 'poll_ms') if False else self.m.entry('clock', 'locale')
        self.m.reset('autohide', 'nonexistent')
        self.m.set('trash', 'rows', self.m.entry('trash', 'rows')['default'] if not self.m.in_file('trash', 'rows') else 5)
        self.m.save()

    def test_indexed(self):
        pats = [(p, l, t) for p, l, t in schema.INDEXED[0][2]]
        items = self.m.get_indexed('quickset', 'Záložky kontajnera', pats, 8)
        self.assertEqual(items[0]['tab{i}'], 'menu:settings')
        self.assertEqual(len(items), 6)
        items = items[:4]
        self.m.set_indexed('quickset', 'Záložky kontajnera', items)
        self.m.save()
        q = tomllib.loads(open(self.p, encoding='utf8').read())['quickset']
        self.assertNotIn('tab5', q); self.assertNotIn('tab6_icon', q); self.assertEqual(q['tab4'], 'monitor')

    def test_unknown_and_schema_defaults(self):
        for (sec, key), e in self.m.schema.items():
            self.assertIn(e['type'], ('bool', 'int', 'float', 'str', 'color', 'path', 'command', 'icon', 'enum', 'strlist', 'numlist', 'font', 'modules'))
        self.assertEqual(self.m.unknown(), [])

    def test_bad_toml_not_written(self):
        self.m.pending[('island', 'font_size')] = object()
        with self.assertRaises(Exception):
            self.m.save()
        self.assertEqual(open(self.p, encoding='utf8').read(), self.m.text)

    def test_arrays_through_model(self):
        self.assertFalse(self.m.dirty())
        menus = self.m.get_array('menu')
        self.assertEqual(len(menus), 4)
        self.assertFalse(self.m.dirty())            # samotné načítanie nie je zmena
        menus[0]['fields']['title'] = 'Systém'
        menus[1]['children'].append({'src': None, 'fields': {'label': 'X', 'command': 'x'}})
        self.assertTrue(self.m.dirty())
        rules = self.m.get_array('notifications.rule')
        rules[0]['fields']['timeout_ms'] = 0
        self.m.set('island', 'font_size', 18)
        self.m.save()
        o = tomllib.loads(open(self.p, encoding='utf8').read())
        self.assertEqual(o['menu'][0]['title'], 'Systém')
        self.assertEqual(o['menu'][1]['item'][-1]['label'], 'X')
        self.assertEqual(o['notifications']['rule'][0]['timeout_ms'], 0)
        self.assertEqual(o['island']['font_size'], 18)
        self.assertFalse(self.m.dirty())
        # po uložení sa načíta znova a ďalšia úprava ide z nového stavu
        self.assertEqual(self.m.get_array('menu')[0]['fields']['title'], 'Systém')

    def test_map(self):
        self.m.set_map('keyboard.names', {'Slovak': 'SVK'})
        self.m.save()
        o = tomllib.loads(open(self.p, encoding='utf8').read())
        self.assertEqual(o['keyboard']['names'], {'Slovak': 'SVK'})


if __name__ == '__main__':
    unittest.main()
