import os, sys, tomllib, unittest
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
import arrays

CFG = os.environ.get('DI_CONFIG', '/home/claude/rosmapo/dynamic-island/config/dynamic-island/config.toml')
MENU = {k: {} for k in ('name', 'title', 'type', 'columns', 'icon_columns', 'text_columns', 'rows', 'icon_size', 'text_size', 'cell_width', 'gap', 'padding', 'separator_thickness', 'separator_length', 'wait_exec', 'wait_timeout_ms')}
ITEM = {k: {} for k in ('separator', 'icon', 'label', 'command', 'exec', 'interval', 'track')}
RULE = {k: {} for k in ('summary', 'app', 'body', 'on_click', 'timeout_ms')}


def load():
    return open(CFG, encoding='utf8').read()


def run(text, recs, name='menu', specs=MENU, child=('menu.item', ITEM)):
    out = arrays.apply_family(text.split('\n'), name, recs, specs, child)
    return '\n'.join(out)


class T(unittest.TestCase):
    def test_roundtrip_identity(self):
        t = load()
        recs = arrays.read_records(t, 'menu', MENU, ('menu.item', ITEM))
        self.assertEqual(run(t, recs), t)
        r = arrays.read_records(t, 'notifications.rule', RULE)
        self.assertEqual(run(t, r, 'notifications.rule', RULE, None), t)

    def test_edit_item_and_menu(self):
        t = load()
        recs = arrays.read_records(t, 'menu', MENU, ('menu.item', ITEM))
        before = tomllib.loads(t)
        recs[1]['fields']['title'] = 'Rádio 2'
        recs[1]['children'][1]['fields']['label'] = 'Zmenené'
        del recs[1]['children'][0]            # prvý oddeľovač
        recs[1]['children'].append({'src': None, 'fields': {'label': 'Nové', 'command': 'mpv x', 'track': 'radio'}})
        out = run(t, recs)
        after = tomllib.loads(out)
        m = after['menu'][1]
        self.assertEqual(m['title'], 'Rádio 2')
        self.assertEqual(m['item'][0]['label'], 'Zmenené')
        self.assertEqual(m['item'][-1]['label'], 'Nové')
        self.assertEqual(len(m['item']), len(before['menu'][1]['item']))   # -1 +1
        self.assertEqual(after['menu'][0], before['menu'][0])
        self.assertEqual(after['menu'][3], before['menu'][3])
        self.assertEqual(out.count('# uprav na svoj'), t.count('# uprav na svoj'))

    def test_reorder_and_delete_menu(self):
        t = load()
        recs = arrays.read_records(t, 'menu', MENU, ('menu.item', ITEM))
        before = tomllib.loads(t)
        names = [m['name'] for m in before['menu']]
        recs[0], recs[2] = recs[2], recs[0]
        out = run(t, recs)
        after = tomllib.loads(out)
        self.assertEqual([m['name'] for m in after['menu']], [names[2], names[1], names[0], names[3]])
        self.assertEqual(after['menu'][0], before['menu'][2])
        recs = recs[:1] + recs[2:]
        out = run(t, recs)
        self.assertEqual(len(tomllib.loads(out)['menu']), 3)
        self.assertNotIn('\n\n\n', out.replace('\n\n\n\n', ''))  # bez rozrastania prázdnych riadkov

    def test_new_menu(self):
        t = load()
        recs = arrays.read_records(t, 'menu', MENU, ('menu.item', ITEM))
        recs.append({'src': None, 'fields': {'name': 'nove', 'title': 'Nové', 'text_columns': 2},
                     'children': [{'src': None, 'fields': {'label': 'A', 'command': 'a'}}, {'src': None, 'fields': {'separator': True}}]})
        out = run(t, recs)
        m = tomllib.loads(out)['menu'][-1]
        self.assertEqual((m['name'], m['text_columns']), ('nove', 2))
        self.assertEqual(m['item'], [{'label': 'A', 'command': 'a'}, {'separator': True}])

    def test_rules_and_custom(self):
        t = load()
        r = arrays.read_records(t, 'notifications.rule', RULE)
        self.assertEqual(len(r), 1)
        r[0]['fields']['timeout_ms'] = 0
        r.append({'src': None, 'fields': {'summary': 'X', 'on_click': 'y'}})
        out = run(t, r, 'notifications.rule', RULE, None)
        rules = tomllib.loads(out)['notifications']['rule']
        self.assertEqual((rules[0]['timeout_ms'], rules[1]['summary']), (0, 'X'))
        # zmazanie jediného pravidla
        out = run(t, [], 'notifications.rule', RULE, None)
        self.assertNotIn('rule', tomllib.loads(out)['notifications'])
        # vlastné moduly: pridanie do súboru, kde ešte nie sú
        CUST = {k: {} for k in ('name', 'exec', 'text', 'interval', 'json')}
        c = arrays.read_records(t, 'custom', CUST)
        c.append({'src': None, 'fields': {'name': 'ram', 'exec': 'echo 1', 'interval': 5, 'json': False}})
        out = run(t, c, 'custom', CUST, None)
        cs = tomllib.loads(out)['custom']
        self.assertEqual(cs[-1], {'name': 'ram', 'exec': 'echo 1', 'interval': 5, 'json': False})
        self.assertEqual(cs[0]['name'], 'off')


if __name__ == '__main__':
    unittest.main()
