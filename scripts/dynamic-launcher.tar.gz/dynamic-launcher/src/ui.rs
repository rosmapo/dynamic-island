//! Stav a rozloženie okna launchera: panely (menu, schránka, kôš, wallpaper, Wi-Fi, Bluetooth, audio, monitor, capture, quickset), animácie.
//! Všetky rozmery sa tu počítajú vo FYZICKÝCH pixeloch (logické * scale).
use crate::anim::Spring;
use crate::config::{Color, Config, MenuKind, SepAlign, Theme};
use crate::icons::IconCache;
use crate::data::*;
use crate::render::{Frame, Item, Rect};
use crate::text::{GlyphQuad, Text};
use std::time::{Duration, Instant};

#[derive(Clone, Debug, PartialEq)]
pub enum Action {
    Run(String),
    /// načítať históriu schránky (výsledok príde ako `Msg::Clip`)
    ClipLoad,
    /// skopírovať položku histórie (celý riadok z `cliphist list`)
    ClipCopy(String),
    /// načítať kôš zo všetkých diskov (výsledok príde ako `Msg::Trash`)
    TrashLoad,
    /// obnoviť vybrané položky koša na pôvodné miesto
    TrashRestore(Vec<crate::trash::TrashEntry>),
    /// natrvalo zmazať všetky uvedené položky koša
    TrashEmpty(Vec<crate::trash::TrashEntry>),
    /// načítať zoznam obrázkov a náhľady modulu wallpaper
    WallLoad,
    /// nastaviť pozadie skriptom (`wallpaper -v CESTA`)
    WallApply { path: String, background_only: bool },
    /// nastaviť tému (názov, cesta) alebo návrat do režimu „wallpaper“ (`None`)
    WallTheme(Option<(String, String)>),
    Audio(crate::audio::AudioCmd),
    Wifi(crate::wifi::WifiCmd),
    Monitor(crate::monitor::MonitorCmd),
    /// snímka obrazovky / nahrávanie (vykoná samostatný proces)
    Capture(crate::capture::Request),
    Bluetooth(crate::bluetooth::BtCmd),
    /// vložiť schránku do poľa hesla
    WifiPaste,
    /// spustiť `exec` položky menu; výstup príde ako `Msg::MenuExec` (generácia = ktoré otvorenie menu)
    MenuExec { gen: u64, idx: usize, cmd: String },
}

#[derive(Clone, Copy, PartialEq, Debug)]
enum Panel {
    None,
    Menu(usize),
    Clip,
    Trash,
    Wall,
    Wifi,
    Audio,
    Monitor,
    /// snímka obrazovky / nahrávanie videa
    Capture,
    Bluetooth,
}

#[derive(Clone, Copy, PartialEq, Debug)]
enum Hit {
    MenuItem(usize),
    ClipItem(usize),
    /// riadok koša (index do `trash`) – klik prepne jeho výber
    TrashRow(usize),
    /// zaškrtávacie políčko v hlavičke zoznamu: vybrať všetko / zrušiť výber
    TrashAll,
    TrashRestore,
    TrashEmpty,
    /// potvrdenie vyprázdnenia: áno / nie
    TrashYes,
    TrashNo,
    WallItem(usize),
    AudioMute(bool),
    AudioSlider(bool),
    AudioDev(bool, usize),
    WallRollout,
    WallButton(usize),
    WallTheme(usize),
    WifiRow(usize),
    /// posledný riadok zoznamu: pripojenie k skrytej sieti
    WifiHidden,
    WifiToggle,
    WifiRefresh,
    WifiEditor,
    /// posuvník jasu (false) / kontrastu (true)
    MonSlider(bool),
    /// tlačidlo teploty farieb
    MonPreset(usize),
    /// tlačidlo vstupu
    MonInput(usize),
    /// prepínač nočného režimu
    MonNight,
    /// panel capture: oblasť (index do `Mode::ALL`), typ (`Kind::ALL`), časovač (index do `delays`)
    CapMode(usize),
    CapKind(usize),
    CapDelay(usize),
    /// prepínač kurzora (obrázok) / zvuku (video)
    CapToggle,
    /// hlavné tlačidlo: snímať / nahrávať
    CapGo,
    BtRow(usize),
    BtToggle,
    BtDiscoverable,
    BtRefresh,
    BtEditor,
    /// záložka kontajnera `quickset`
    HwTab(usize),
    /// tlačidlo druhej lišty kontajnera (`inversetabN`): príkaz alebo samostatný panel
    HwBtn(usize),
    Panel,
}

/// Riadok vo flow layoute menu (indexy do `menu.items`).
enum MenuLayoutRow {
    Icons(Vec<usize>),
    Labels(Vec<usize>),
    /// Riadok textu cez celú šírku (`line`), index do `menu.items`.
    Line(usize),
    /// Oddeľovač s polohou čiary v riadku.
    Separator(SepAlign),
}

const BTN_LEFT: u32 = 0x110;
const BTN_RIGHT: u32 = 0x111;
const BTN_MIDDLE: u32 = 0x112;

// kontajner quickset (logické px)
const HW_BAR_PAD: f32 = 10.0; // okraj lišty okolo záložiek
const HW_BAR_INSET: f32 = 6.0; // odsadenie podkladu lišty od okraja okna

// panel schránky (logické px)
/// po koľkých sekundách bez stlačenia klávesu sa zadávanie hesla zruší
const WIFI_PW_IDLE_SECS: u64 = 45;
const WIFI_PAD: f32 = 14.0;
const WIFI_HEAD: f32 = 44.0;
const WIFI_ROW_EXTRA: f32 = 20.0; // výška riadku = písmo + toto
const WIFI_FOOT: f32 = 30.0;
const WIFI_SCROLLBAR: f32 = 8.0;
const WIFI_SCROLL_UNIT: f32 = 10.0;
const AUDIO_PAD: f32 = 14.0;
const AUDIO_ROW_EXTRA: f32 = 20.0;
const AUDIO_LABEL: f32 = 26.0;
const AUDIO_GAP: f32 = 16.0;
const AUDIO_SCROLL_UNIT: f32 = 10.0;
const WALL_HEAD: f32 = 44.0;
const WALL_PAD: f32 = 14.0;
const WALL_GAP: f32 = 12.0;
const WALL_SCROLLBAR: f32 = 8.0;
const WALL_SCROLL_UNIT: f32 = 10.0;
const CLIP_PAD: f32 = 12.0;
const CLIP_ROW_EXTRA: f32 = 16.0; // výška riadku = písmo + toto
const CLIP_SCROLLBAR: f32 = 8.0;
/// jednotka osi kolieska zodpovedajúca jednému riadku
const CLIP_SCROLL_UNIT: f32 = 10.0;
const TRASH_PAD: f32 = 12.0;
const TRASH_GAP: f32 = 8.0;
const TRASH_SCROLLBAR: f32 = 8.0;
const TRASH_SCROLL_UNIT: f32 = 10.0;

pub struct Ui {
    pub cfg: Config,
    pub theme: Theme,
    pub scale: f32,
    pub icons: IconCache,
    surf_w: f32,
    surf_h: f32,

    panel: Panel,       // cieľový panel
    panel_shown: Panel, // panel, ktorý sa práve kreslí (kým sa zatvára)
    big: Panel,         // veľký panel nahrádzajúci ostrovček (kalendár / disky)
    /// kontajner `quickset`: `big` je panel aktívnej záložky (`hw_tab`), okolo neho sa kreslí lišta;
    /// rozmery okna sa menia pružinami, aby sa prepnutie záložky animovalo
    hw: bool,
    hw_tab: usize,
    hw_w: Spring,
    hw_h: Spring,
    /// veľký panel sa práve otvára z ostrovčeka: veľkosť okna sa nastaví naraz, každá ďalšia zmena veľkosti (prepnutie
    /// panela v kontajneri / mimo neho, zmena obsahu) ide pružinami
    big_snap: bool,
    panel_h: Spring,
    panel_w: Spring,
    panel_a: Spring,
    radius: Spring,

    cal_t: Spring,
    /// história schránky (najnovšie prvé), prvý viditeľný riadok, nazbieraný posun kolieska
    /// položky menu s `exec`: výstupy (podľa indexu položky) otvoreného menu `menu_mi`; `None` = ešte nenačítané.
    /// Nič sa neukladá medzi otvoreniami – pri každom otvorení sa začína prázdne.
    menu_mi: usize,
    menu_gen: u64,
    menu_out: Vec<Option<String>>,
    /// kedy sa má `exec` položky s `interval` > 0 spustiť znova (nastaví sa až po dobehnutí predošlého behu)
    menu_due: Vec<Option<Instant>>,
    /// `wait_exec`: menu `.0` sa otvorí, keď sú položky načítané alebo najneskôr v čase `.1`
    menu_wait: Option<(usize, Instant)>,
    clip: Vec<ClipEntry>,
    clip_loaded: bool,
    clip_scroll: usize,
    clip_acc: f32,
    /// filter písaný na klávesnici (bez políčka), indexy do `clip` vyhovujúce filtru a vybraná pozícia v nich
    /// (`None` = klávesnicou nič nevybrané, zvýrazňuje sa len riadok pod myšou)
    clip_query: String,
    clip_view: Vec<usize>,
    clip_sel: Option<usize>,
    /// modul trash: položky (najnovšie zmazané prvé), prvý viditeľný riadok, nazbieraný posun kolieska,
    /// vybrané položky (podľa cesty `.trashinfo`, prežijú opätovné načítanie), hláška a zapnuté potvrdenie vyprázdnenia
    trash: Vec<crate::trash::TrashEntry>,
    trash_loaded: bool,
    trash_scroll: usize,
    trash_acc: f32,
    trash_sel: std::collections::HashSet<std::path::PathBuf>,
    trash_note: String,
    trash_confirm: bool,
    /// modul wallpaper: obrázky, aktuálne pozadie, prvý viditeľný riadok mriežky, nazbieraný posun kolieska
    wall: Vec<crate::wallpaper::WallEntry>,
    wall_loaded: bool,
    wall_current: String,
    wall_scroll: usize,
    wall_acc: f32,
    /// témy (názov, cesta), aktuálna téma (prázdna = „wallpaper“), rozbalená ponuka tém a jej skrolovanie
    wall_themes: Vec<(String, String)>,
    wall_theme: String,
    wall_menu: bool,
    wall_menu_scroll: usize,
    /// modul audio: zariadenia, ťahaný posuvník (`false` = výstup, `true` = vstup), dráhy posuvníkov z posledného kreslenia
    audio: crate::audio::AudioState,
    audio_loaded: bool,
    audio_drag: Option<bool>,
    audio_sent: Instant,
    audio_unsent: bool,
    audio_rects: [Rect; 2],
    audio_acc: f32,
    /// modul Wi-Fi: stav, správa vo päte, skrolovanie, rozpísané heslo
    wifi: crate::wifi::WifiState,
    wifi_loaded: bool,
    wifi_note: String,
    wifi_scroll: usize,
    wifi_acc: f32,
    wifi_pw: Option<WifiPw>,
    /// poistka: zadávanie hesla sa po nečinnosti samo zruší (uvoľní klávesnicu)
    wifi_pw_until: Option<Instant>,
    /// modul monitor: jas/kontrast/preset/vstup/nočný režim
    monitor: crate::monitor::MonitorState,
    monitor_loaded: bool,
    /// ťahaný posuvník: false = jas, true = kontrast
    monitor_drag: Option<bool>,
    monitor_sent: Instant,
    monitor_unsent: bool,
    /// dráhy posuvníkov z posledného kreslenia [jas, kontrast]
    monitor_rects: [Rect; 2],
    /// panel capture: voľby, priebeh a posledná správa
    cap_mode: crate::capture::Mode,
    cap_kind: crate::capture::Kind,
    cap_delay: usize,
    cap_cursor: bool,
    cap_audio: bool,
    /// modul Bluetooth
    bluetooth: crate::bluetooth::BtState,
    bluetooth_loaded: bool,
    bluetooth_scroll: usize,
    bluetooth_acc: f32,
    /// akcie, ktoré vznikli mimo `click` (otvorenie panela) – `click` ich vráti volajúcemu
    queued: Vec<Action>,

    ptr: Option<(f32, f32)>,
    hover: Option<Hit>,
    /// po prepnutí panelu cez `module:` sa odchod myši ignoruje, kým myš nevstúpi do nového panela
    /// (nový panel môže mať inú veľkosť, takže myš po kliku často skončí mimo neho)
    /// Some(najskôr kedy ho pohyb myši môže zrušiť) = odklad zatvorenia je aktívny
    /// názov otvoreného okna (pre `open_named`)
    ext_name: String,
    /// okno sa už raz otvorilo (kým nie, `finished()` je false)
    started: bool,

    pub pill: Rect,
    hits: Vec<(Rect, Hit)>,
}

/// Rozpísané zadávanie hesla pre zabezpečenú sieť.
struct WifiPw {
    ssid: String,
    ap: String,
    key_mgmt: String,
    text: String,
    /// skrytá sieť: SSID zadáva používateľ
    hidden: bool,
    /// práve sa píše názov skrytej siete (potom heslo)
    ssid_stage: bool,
}

fn fade(c: Color, a: f32) -> Color {
    [c[0], c[1], c[2], c[3] * a.clamp(0.0, 1.0)]
}

fn menu_content_width(kind: MenuKind, icon_grid_w: f32, text_grid_w: f32, m: &crate::config::MenuCfg) -> f32 {
    match kind {
        MenuKind::Text => text_grid_w,
        MenuKind::Icons => icon_grid_w,
        MenuKind::Hybrid => {
            let has_icons = m.items.iter().any(|it| !it.separator && !it.icon.is_empty());
            let has_labels = m.items.iter().any(|it| !it.separator && !it.line && it.icon.is_empty() && !it.label.is_empty());
            let mut w = 0.0f32;
            if has_icons {
                w = w.max(icon_grid_w);
            }
            if has_labels {
                w = w.max(text_grid_w);
            }
            if w > 0.0 {
                w
            } else {
                icon_grid_w
            }
        }
    }
}

impl Ui {
    pub fn new(cfg: Config, theme: Theme, scale: f32) -> Ui {
        let cap_defaults = (cfg.capture.mode, cfg.capture.kind, cfg.capture.cursor, cfg.capture.audio);
        let (sw, sh) = (cfg.surface_w as f32 * scale, cfg.surface_h as f32 * scale);
        let radius = cfg.radius;
        let mut ui = Ui {
            icons: {
                let dir = cfg.path.parent().map(|p| p.to_path_buf()).unwrap_or_else(|| std::path::PathBuf::from("."));
                let mut ic = IconCache::new(dir);
                let paths: Vec<String> = cfg.menus.iter().flat_map(|m| m.items.iter().map(|it| it.icon.clone())).filter(|s| !s.is_empty()).collect();
                ic.preload(paths.iter().map(|s| s.as_str()));
                ic
            },
            cfg,
            theme,
            scale,
            surf_w: sw,
            surf_h: sh,
            panel: Panel::None,
            panel_shown: Panel::None,
            big: Panel::None,
            hw: false,
            hw_tab: 0,
            hw_w: Spring::with(0.0, 240.0, 26.0),
            hw_h: Spring::with(0.0, 240.0, 26.0),
            big_snap: false,
            panel_h: Spring::with(0.0, 240.0, 26.0),
            panel_w: Spring::with(0.0, 240.0, 26.0),
            panel_a: Spring::with(0.0, 420.0, 42.0),
            radius: Spring::with(radius, 300.0, 30.0),
            cal_t: Spring::with(0.0, 260.0, 26.0),
            clip: Vec::new(),
            clip_loaded: false,
            clip_scroll: 0,
            clip_acc: 0.0,
            clip_query: String::new(),
            clip_view: Vec::new(),
            clip_sel: None,
            trash: Vec::new(),
            trash_loaded: false,
            trash_scroll: 0,
            trash_acc: 0.0,
            trash_sel: std::collections::HashSet::new(),
            trash_note: String::new(),
            trash_confirm: false,
            menu_mi: 0,
            menu_gen: 0,
            menu_out: Vec::new(),
            menu_due: Vec::new(),
            menu_wait: None,
            wall: Vec::new(),
            wall_loaded: false,
            wall_current: String::new(),
            wall_scroll: 0,
            wall_acc: 0.0,
            wall_themes: Vec::new(),
            wall_theme: String::new(),
            wall_menu: false,
            wall_menu_scroll: 0,
            audio: Default::default(),
            audio_loaded: false,
            audio_drag: None,
            audio_sent: Instant::now(),
            audio_unsent: false,
            audio_rects: [Rect::new(0.0, 0.0, 0.0, 0.0); 2],
            audio_acc: 0.0,
            wifi: Default::default(),
            wifi_loaded: false,
            wifi_note: String::new(),
            wifi_scroll: 0,
            wifi_acc: 0.0,
            wifi_pw: None,
            wifi_pw_until: None,
            monitor: Default::default(),
            monitor_loaded: false,
            monitor_drag: None,
            monitor_sent: Instant::now(),
            monitor_unsent: false,
            monitor_rects: [Rect::new(0.0, 0.0, 0.0, 0.0); 2],
            cap_mode: cap_defaults.0,
            cap_kind: cap_defaults.1,
            cap_delay: 0,
            cap_cursor: cap_defaults.2,
            cap_audio: cap_defaults.3,
            bluetooth: Default::default(),
            bluetooth_loaded: false,
            bluetooth_scroll: 0,
            bluetooth_acc: 0.0,
            queued: Vec::new(),
            ptr: None,
            hover: None,
            ext_name: String::new(),
            started: false,
            pill: Rect::new(0.0, 0.0, 0.0, 0.0),
            hits: Vec::new(),
        };
        ui
    }

    pub fn set_scale(&mut self, scale: f32) {
        self.scale = scale;
        self.surf_w = self.cfg.surface_w as f32 * scale;
        self.surf_h = self.cfg.surface_h as f32 * scale;
    }

    fn s(&self, v: f32) -> f32 {
        v * self.scale
    }

    // ------------------------------------------------------------- dáta
    pub fn apply(&mut self, m: Msg, now: Instant) {
        match m {
            Msg::MenuExec(gen, idx, out) => {
                // výstup z predošlého otvorenia menu sa ignoruje
                if gen == self.menu_gen && idx < self.menu_out.len() {
                    self.menu_out[idx] = Some(out);
                    let interval = self.cfg.menus.get(self.menu_mi).and_then(|m| m.items.get(idx)).map_or(0.0, |it| it.interval);
                    if interval > 0.0 {
                        self.menu_due[idx] = Some(now + Duration::from_secs_f64(interval));
                    }
                    if let Some((mi, _)) = self.menu_wait {
                        if mi == self.menu_mi && self.menu_ready() {
                            self.set_panel(Panel::Menu(mi));
                        }
                    }
                }
            }
            Msg::Clip(v) => {
                self.clip = v;
                self.clip_loaded = true;
                self.clip_refilter();
            }
            Msg::Trash(v, note) => {
                self.trash = v;
                self.trash_loaded = true;
                let present: std::collections::HashSet<&std::path::PathBuf> = self.trash.iter().map(|e| &e.info).collect();
                self.trash_sel.retain(|p| present.contains(p));
                if !note.is_empty() {
                    // dokončená obnova / vyprázdnenie
                    self.trash_note = note;
                    self.trash_confirm = false;
                }
                self.trash_scroll = self.trash_scroll.min(self.trash.len().saturating_sub(self.cfg.trash.rows));
            }
            Msg::Wall(v, current) => {
                self.wall = v;
                self.wall_loaded = true;
                self.wall_current = current;
                let max_start = self.wall_row_count().saturating_sub(self.cfg.wall.rows);
                self.wall_scroll = self.wall_scroll.min(max_start);
            }
            Msg::WallCurrent(path) => self.wall_current = path,
            Msg::WallThemes(list, selected) => {
                self.wall_themes = list;
                self.wall_theme = selected;
            }
            Msg::WallTheme(name) => self.wall_theme = name,
            Msg::Wifi(s) => {
                self.wifi = s;
                self.wifi_loaded = true;
                let max_start = self.wifi_list_len().saturating_sub(self.cfg.wifi.rows);
                self.wifi_scroll = self.wifi_scroll.min(max_start);
            }
            Msg::WifiNote(n) => self.wifi_note = n,
            Msg::WifiPaste(t) => {
                if let Some(pw) = &mut self.wifi_pw {
                    let dst = if pw.ssid_stage { &mut pw.ssid } else { &mut pw.text };
                    dst.extend(t.trim_end_matches(['\n', '\r']).chars().filter(|c| !c.is_control()));
                }
            }
            Msg::WallThumb(i, thumb) => {
                if let Some(e) = self.wall.get_mut(i) {
                    if e.thumb == thumb {
                        e.ready = true;
                    }
                }
            }
            Msg::AudioDev(st) => {
                // počas ťahania posuvníka by nás staré hodnoty z `pactl` vracali späť
                if self.audio_drag.is_none() {
                    self.audio = st;
                }
                self.audio_loaded = true;
            }
            Msg::Monitor(st) => {
                let mut st = st;
                if self.cfg.monitor.night_state.is_empty() {
                    // bez `night_state` stav nevieme zistiť – pamätáme si ho
                    st.night = self.monitor.night;
                }
                if self.monitor_drag.is_none() {
                    self.monitor = st;
                } else {
                    // počas ťahania aktualizuj len to, čo nie je ťahané
                    let night = st.night;
                    let preset = st.preset;
                    let input = st.input;
                    let error = st.error;
                    let loaded = st.loaded;
                    if self.monitor_drag != Some(false) {
                        self.monitor.brightness = st.brightness;
                    }
                    if self.monitor_drag != Some(true) {
                        self.monitor.contrast = st.contrast;
                    }
                    self.monitor.night = night;
                    self.monitor.preset = preset;
                    self.monitor.input = input;
                    self.monitor.error = error;
                    self.monitor.loaded = loaded;
                }
                self.monitor_loaded = true;
            }
            Msg::Bluetooth(st) => {
                self.bluetooth = st;
                self.bluetooth_loaded = true;
                let max_start = self.bluetooth.devices.len().saturating_sub(self.cfg.bluetooth.rows);
                self.bluetooth_scroll = self.bluetooth_scroll.min(max_start);
            }
        }
    }
    // ------------------------------------------------------- animácie
    pub fn update(&mut self, dt: f32, now: Instant, _text: &mut Text) -> bool {
        self.tick(now);
        let mut busy = false;
        if self.big_open() {
            // okno plynulo dobieha rozmer panela (aj pri prepnutí záložky, panela mimo kontajnera alebo zmene obsahu)
            let (w, h) = if self.hw_view() { self.hw_target() } else { self.panel_dims(self.big) };
            if self.big_snap {
                self.big_snap = false;
                self.hw_w.snap(w);
                self.hw_h.snap(h);
            } else {
                self.hw_w.set(w);
                self.hw_h.set(h);
            }
        }
        for sp in [&mut self.hw_w, &mut self.hw_h] {
            sp.step(dt);
            busy |= !sp.settled();
        }
        busy
    }

    // ------------------------------------------------------ notifikácie
    // ---------------------------------------------------------- panely
    /// Prirodzená veľkosť panela `p` (fyzické px).
    fn panel_dims(&self, p: Panel) -> (f32, f32) {
        match p {
            Panel::Menu(mi) => self.menu_size(mi),
            Panel::Audio => {
                let c = &self.cfg.audio_panel;
                let row = c.font_size + AUDIO_ROW_EXTRA;
                let sec = |len: usize| AUDIO_LABEL + row + len.min(c.rows).max(1) as f32 * row;
                let h = 2.0 * AUDIO_PAD + sec(self.audio.sinks.len()) + AUDIO_GAP + sec(self.audio.sources.len());
                (c.width * self.scale, h * self.scale)
            }
            Panel::Capture => {
                let c = &self.cfg.capture;
                (c.width * self.scale, crate::capture::panel_height(c.font_size) * self.scale)
            }
            Panel::Monitor => {
                let c = &self.cfg.monitor;
                let f = c.font_size;
                // 2 posuvníky + 2 rady tlačidiel (preset, input) + nočný režim
                let row = f + 20.0;
                let label = 22.0;
                let gap = 12.0;
                let h = 2.0 * 14.0
                    + label + row          // jas
                    + gap + label + row    // kontrast
                    + gap + label + row    // teplota
                    + gap + label + row;   // vstup
                let h = if c.night_switcher.is_empty() { h } else { h + gap + row }; // nočný režim
                (c.width * self.scale, h * self.scale)
            }
            Panel::Bluetooth => {
                let c = &self.cfg.bluetooth;
                let f = c.font_size;
                let rows = self.bluetooth.devices.len().min(c.rows).max(1) as f32;
                let h = 2.0 * WIFI_PAD + WIFI_HEAD + rows * (f + WIFI_ROW_EXTRA) + WIFI_FOOT;
                (c.width * self.scale, h * self.scale)
            }
            Panel::Wifi => {
                let c = &self.cfg.wifi;
                let f = c.font_size;
                let h = if self.wifi_pw.is_some() {
                    2.0 * WIFI_PAD + WIFI_HEAD + 4.0 + (f + 18.0) + 10.0 + (f * 0.85 + 6.0)
                } else {
                    2.0 * WIFI_PAD + WIFI_HEAD + self.wifi_rows_shown() as f32 * (f + WIFI_ROW_EXTRA) + WIFI_FOOT
                };
                (c.width * self.scale, h * self.scale)
            }
            Panel::Wall => {
                let c = &self.cfg.wall;
                let (tw, th) = c.thumb_size();
                let sb = if self.wall_row_count() > c.rows { WALL_SCROLLBAR } else { 0.0 };
                let w = 2.0 * WALL_PAD + c.columns as f32 * tw + (c.columns - 1) as f32 * WALL_GAP + sb;
                let n = self.wall_rows_shown() as f32;
                let h = 2.0 * WALL_PAD + WALL_HEAD + WALL_GAP + n * th + (n - 1.0) * WALL_GAP;
                (w * self.scale, h * self.scale)
            }
            Panel::Clip => {
                let row_h = self.cfg.clip_font + CLIP_ROW_EXTRA;
                let h = 2.0 * CLIP_PAD + self.clip_rows() as f32 * row_h;
                (self.cfg.clip_width * self.scale, h * self.scale)
            }
            Panel::Trash => {
                let f = self.cfg.trash.font;
                let row_h = f + CLIP_ROW_EXTRA;
                // tlačidlá, hlavička zoznamu, riadky, pätka (počet / hláška)
                let h = 2.0 * TRASH_PAD + (f + 14.0) + TRASH_GAP + row_h + self.trash_rows() as f32 * row_h + TRASH_GAP + (f * 0.85 + 8.0);
                (self.cfg.trash.width * self.scale, h * self.scale)
            }
            Panel::None => (0.0, 0.0),
        }
    }

    fn menu_rows(menu: &crate::config::MenuCfg) -> Vec<MenuLayoutRow> {
        let icon_cols = menu.icon_columns.max(1);
        let text_cols = menu.text_columns.max(1);
        let mut rows: Vec<MenuLayoutRow> = Vec::new();
        let mut icons: Vec<usize> = Vec::new();
        let mut labels: Vec<usize> = Vec::new();

        let flush_icons = |icons: &mut Vec<usize>, rows: &mut Vec<MenuLayoutRow>| {
            if !icons.is_empty() {
                rows.push(MenuLayoutRow::Icons(std::mem::take(icons)));
            }
        };
        let flush_labels = |labels: &mut Vec<usize>, rows: &mut Vec<MenuLayoutRow>| {
            if !labels.is_empty() {
                rows.push(MenuLayoutRow::Labels(std::mem::take(labels)));
            }
        };

        for (i, it) in menu.items.iter().enumerate() {
            if it.separator {
                flush_icons(&mut icons, &mut rows);
                flush_labels(&mut labels, &mut rows);
                rows.push(MenuLayoutRow::Separator(it.sep_align));
                continue;
            }
            if it.line {
                flush_icons(&mut icons, &mut rows);
                flush_labels(&mut labels, &mut rows);
                rows.push(MenuLayoutRow::Line(i));
                continue;
            }
            match menu.kind {
                MenuKind::Text => {
                    // text menu: všetky položky ako labely (label, alebo icon ako nerd-font glyf)
                    if it.label.is_empty() && it.icon.is_empty() && it.exec.is_empty() {
                        continue;
                    }
                    labels.push(i);
                    if labels.len() >= text_cols {
                        flush_labels(&mut labels, &mut rows);
                    }
                }
                MenuKind::Icons => {
                    if it.icon.is_empty() {
                        continue;
                    }
                    icons.push(i);
                    if icons.len() >= icon_cols {
                        flush_icons(&mut icons, &mut rows);
                    }
                }
                MenuKind::Hybrid => {
                    if !it.icon.is_empty() {
                        flush_labels(&mut labels, &mut rows);
                        icons.push(i);
                        if icons.len() >= icon_cols {
                            flush_icons(&mut icons, &mut rows);
                        }
                    } else if !it.label.is_empty() || !it.exec.is_empty() {
                        flush_icons(&mut icons, &mut rows);
                        labels.push(i);
                        if labels.len() >= text_cols {
                            flush_labels(&mut labels, &mut rows);
                        }
                    }
                }
            }
        }
        flush_icons(&mut icons, &mut rows);
        flush_labels(&mut labels, &mut rows);

        if let Some(max_rows) = menu.rows {
            let only_icons = menu.kind == MenuKind::Icons
                || (menu.kind == MenuKind::Hybrid
                    && menu.items.iter().all(|it| it.separator || it.line || !it.icon.is_empty() || (it.label.is_empty() && it.exec.is_empty())));
            if only_icons {
                rows.truncate(max_rows);
            }
        }
        rows
    }

    /// Logické → fyzické rozmery menu (hybrid / icons / text).
    fn menu_size(&self, mi: usize) -> (f32, f32) {
        let Some(m) = self.cfg.menus.get(mi) else {
            return (self.s(120.0), self.s(80.0));
        };
        let icon_cols = m.icon_columns.max(1);
        let text_cols = m.text_columns.max(1);
        let title_h = if m.title.is_empty() { 0.0 } else { 36.0 };
        let icon_cell = m.icon_size + 16.0;
        let label_h = m.text_size + 18.0;
        let sep_h = (m.separator_thickness + 12.0).max(14.0);

        let icon_grid_w = icon_cols as f32 * icon_cell + (icon_cols.saturating_sub(1)) as f32 * m.gap;
        let text_grid_w = text_cols as f32 * m.cell_width + (text_cols.saturating_sub(1)) as f32 * m.gap;
        // Hybrid: šírka len podľa typov, ktoré v menu skutočne sú (nie default cell_width navyše).
        let content_w = menu_content_width(m.kind, icon_grid_w, text_grid_w, m);

        let layout = Self::menu_rows(m);
        let mut body_h = 0.0f32;
        for (ri, row) in layout.iter().enumerate() {
            if ri > 0 {
                body_h += m.gap;
            }
            body_h += match row {
                MenuLayoutRow::Icons(_) => icon_cell,
                MenuLayoutRow::Labels(_) | MenuLayoutRow::Line(_) => label_h,
                MenuLayoutRow::Separator(_) => sep_h,
            };
        }
        if layout.is_empty() {
            body_h = icon_cell;
        }

        let w = m.padding * 2.0 + content_w;
        let h = m.padding * 2.0 + title_h + body_h;
        (w * self.scale, h * self.scale)
    }

    fn set_panel(&mut self, p: Panel) {
        // zmena panela ruší čakanie na výstupy menu (`wait_exec`)
        self.menu_wait = None;
        self.panel = p;
        if p != Panel::None {
            // iný panel otvorený samostatne = už nie je v kontajneri
            self.hw = false;
        }
        if Self::is_big(p) {
            // prvé otvorenie: veľkosť okna sa nastaví naraz (bez animácie); každá ďalšia zmena veľkosti
            // (prepnutie panela / záložky, zmena obsahu) ide pružinami
            if self.big == Panel::None {
                self.big_snap = true;
            }
            self.big = p;
        }
        if p != Panel::Wifi {
            self.wifi_pw = None;
        }
        if p != Panel::Audio {
            self.audio_drag = None;
        }
        if p != Panel::Monitor {
            self.monitor_drag = None;
        }
        if p == Panel::Audio {
            self.audio_acc = 0.0;
            self.queued.push(Action::Audio(crate::audio::AudioCmd::Load));
        }
        if p == Panel::Monitor {
            self.queued.push(Action::Monitor(crate::monitor::MonitorCmd::Load));
        }
        if p == Panel::Bluetooth {
            self.bluetooth_scroll = 0;
            self.bluetooth_acc = 0.0;
            self.queued.push(Action::Bluetooth(crate::bluetooth::BtCmd::Load { scan: true }));
        }
        if p == Panel::Wifi {
            self.wifi_pw = None;
            self.wifi_scroll = 0;
            self.wifi_acc = 0.0;
            self.wifi_note.clear();
            self.queued.push(Action::Wifi(crate::wifi::WifiCmd::Load));
        }
        if p == Panel::Wall {
            // zoznam sa pri každom otvorení načíta znova (nové obrázky, dorobené náhľady)
            self.wall_scroll = 0;
            self.wall_acc = 0.0;
            self.wall_menu = false;
            self.wall_menu_scroll = 0;
            self.queued.push(Action::WallLoad);
        }
        if p == Panel::Clip {
            // pri každom otvorení znova načítať históriu (staré položky ostanú viditeľné, kým nepríde nová)
            self.clip_scroll = 0;
            self.clip_acc = 0.0;
            self.clip_query.clear();
            self.clip_sel = None;
            self.clip_refilter();
            self.queued.push(Action::ClipLoad);
        }
        if p == Panel::Trash {
            // pri každom otvorení znova načítať kôš (staré položky ostanú viditeľné, kým nepríde nový zoznam)
            self.trash_scroll = 0;
            self.trash_acc = 0.0;
            self.trash_sel.clear();
            self.trash_note.clear();
            self.trash_confirm = false;
            self.queued.push(Action::TrashLoad);
        }
    }
    fn big_open(&self) -> bool {
        Self::is_big(self.panel)
    }
    fn is_big(p: Panel) -> bool {
        p != Panel::None
    }

    // ------------------------------------------- kontajner quickset

    /// Panel, ktorý patrí záložke: `audio` | `bluetooth` | `wifi` | `monitor` | `clipboard` | `trash` | `notifications` | `wallpaper`, alebo `menu:NAZOV` = vlastné `[[menu]]`
    /// s daným názvom (neexistujúce menu = `None`, záložka sa nedá otvoriť).
    fn tab_panel(&self, name: &str) -> Option<Panel> {
        match name {
            "audio" => Some(Panel::Audio),
            "bluetooth" => Some(Panel::Bluetooth),
            "wifi" => Some(Panel::Wifi),
            "monitor" => Some(Panel::Monitor),
            "capture" => Some(Panel::Capture),
            "clipboard" => Some(Panel::Clip),
            "trash" => Some(Panel::Trash),
            "wallpaper" => Some(Panel::Wall),
            _ => name.strip_prefix(crate::quickset::MENU_PREFIX).and_then(|m| self.menu_index(m)).map(Panel::Menu),
        }
    }

    /// Panel môže byť obsahom kontajnera `quickset`.
    fn is_hw_inner(p: Panel) -> bool {
        matches!(p, Panel::Audio | Panel::Bluetooth | Panel::Wifi | Panel::Monitor | Panel::Capture | Panel::Menu(_) | Panel::Clip | Panel::Trash | Panel::Wall)
    }

    /// Veľký panel sa práve kreslí v kontajneri `quickset` (aj počas jeho zatvárania).
    fn hw_view(&self) -> bool {
        self.hw && Self::is_hw_inner(self.big)
    }

    /// Príkaz `quickset` (posledná záložka) alebo `quickset:MODUL` (konkrétna záložka): `Some(modul)` / `Some(None)`.
    fn quickset_cmd(cmd: &str) -> Option<Option<&str>> {
        let cmd = cmd.trim();
        // starý názov `hardware` sa ešte akceptuje
        if cmd == "quickset" || cmd == "hardware" {
            Some(None)
        } else {
            cmd.strip_prefix("quickset:").or_else(|| cmd.strip_prefix("hardware:")).map(|m| Some(m.trim()))
        }
    }

    /// Názov vnútornej akcie ostrovčeka (panel, menu, kontajner, vstavaná akcia), nie shell príkaz.
    fn is_internal_action(&self, name: &str) -> bool {
        matches!(name, "calendar" | "disks" | "clipboard" | "notifications" | "media" | "trash" | "wallpaper" | "wifi" | "audio" | "monitor" | "bluetooth" | "capture" | "drun")
            || Self::quickset_cmd(name).is_some()
            || self.menu_index(name).is_some()
            || Self::action_for(name).map_or(false, |a| !matches!(a, Action::Run(_)))
    }

    /// Tlačidlo druhej lišty (`inversetabN`): kontajner sa zatvorí, potom sa otvorí panel / menu samostatne
    /// alebo sa spustí príkaz.
    fn run_quickset_button(&mut self, i: usize, now: Instant) -> Vec<Action> {
        let Some(action) = self.cfg.hw.inverse.get(i).map(|b| b.action.clone()) else { return Vec::new() };
        let mut out = Vec::new();
        self.set_panel(Panel::None);
        let _ = now;
        if self.is_internal_action(&action) {
            out.extend(self.run_module(&action));
        } else {
            out.push(Action::Run(action));
        }
        out
    }

    fn hw_tab_index(&self, module: &str) -> Option<usize> {
        self.cfg.hw.tabs.iter().position(|t| t.module == module)
    }

    /// Cieľová veľkosť okna kontajnera pre aktívnu záložku (fyzické px): výška podľa najvyššej záložky
    /// (okno pri prepínaní nepodskakuje), šírka podľa aktívnej; `width` / `height` z configu to prebijú.
    fn hw_target(&self) -> (f32, f32) {
        let c = &self.cfg.hw;
        let s = self.scale;
        let inner_h = c.tabs.iter().filter_map(|t| self.tab_panel(&t.module)).map(|p| self.panel_dims(p).1).fold(0.0f32, f32::max);
        let inner_w = self.panel_dims(self.big).0;
        let tab = c.tab_size * s;
        let bar_t = crate::quickset::bar_thickness(tab, HW_BAR_PAD * s);
        let mut bar_l = crate::quickset::bar_length(c.tabs.len(), tab, c.tab_gap * s, HW_BAR_PAD * s);
        // druhá lišta na opačnej strane: hrúbka sa sčíta, dĺžka je väčšia z oboch
        let mut bars_t = bar_t;
        if !c.inverse.is_empty() {
            bars_t += bar_t;
            bar_l = bar_l.max(crate::quickset::bar_length(c.inverse.len(), tab, c.inverse_gap * s, HW_BAR_PAD * s));
        }
        crate::quickset::window_size(c.pos, (inner_w, inner_h), bars_t, bar_l, c.width.map(|w| w * s), c.height.map(|h| h * s))
    }

    /// Otvorí kontajner `quickset` na záložke `tab` (`None` = naposledy použitá) alebo prepne záložku.
    fn open_quickset(&mut self, tab: Option<usize>) {
        let n = self.cfg.hw.tabs.len();
        if n == 0 {
            return;
        }
        let idx = tab.unwrap_or(self.hw_tab).min(n - 1);
        let Some(p) = self.tab_panel(&self.cfg.hw.tabs[idx].module) else { return };
        let fresh = !(self.hw && Self::is_hw_inner(self.panel));
        // záložka s menu: spustí `exec` jeho položiek (`wait_exec` sa v kontajneri neuplatní, okno sa otvára hneď)
        if let Panel::Menu(mi) = p {
            self.menu_start(mi);
        }
        // vyčistí príznak kontajnera a inicializuje panel záložky (načítanie, posun, rozpísané heslo…)
        self.set_panel(p);
        self.hw = true;
        self.hw_tab = idx;
        if fresh && self.cfg.hw.preload && p != Panel::Monitor && self.cfg.hw.tabs.iter().any(|t| t.module == "monitor") {
            // `ddcutil` je pomalý – údaje monitora sa načítajú vopred, kým používateľ pracuje s inou záložkou
            self.queued.push(Action::Monitor(crate::monitor::MonitorCmd::Load));
        }
        if fresh {
            // pri otvorení okno nezačína od nuly – rozmer vyrastá z ostrovčeka ako pri iných paneloch
            let (w, h) = self.hw_target();
            self.hw_w.snap(w);
            self.hw_h.snap(h);
        }
    }
    /// Najvyššia hodnota posuvníka v % (`limit` z `[audio]`).
    fn audio_max(&self) -> u32 {
        (self.cfg.vol_limit * 100.0).round().max(1.0) as u32
    }

    /// Index predvoleného zariadenia (alebo prvého, ak predvolené nepoznáme).
    fn audio_default(&self, src: bool) -> Option<usize> {
        let (list, def) = if src { (&self.audio.sources, &self.audio.default_source) } else { (&self.audio.sinks, &self.audio.default_sink) };
        if list.is_empty() {
            None
        } else {
            Some(list.iter().position(|d| &d.name == def).unwrap_or(0))
        }
    }

    /// Nastaví hlasitosť predvoleného zariadenia (hneď v zobrazení, príkaz sa posiela najviac každých 40 ms).
    fn audio_set_volume(&mut self, src: bool, pct: u32, force: bool) {
        let Some(i) = self.audio_default(src) else { return };
        let dev = if src { &mut self.audio.sources[i] } else { &mut self.audio.sinks[i] };
        let changed = dev.volume != pct;
        dev.volume = pct;
        self.audio_unsent |= changed;
        let now = Instant::now();
        if self.audio_unsent && (force || now.duration_since(self.audio_sent) >= Duration::from_millis(40)) {
            self.audio_unsent = false;
            self.audio_sent = now;
            self.queued.push(Action::Audio(crate::audio::AudioCmd::Volume { source: src, pct }));
        }
    }

    /// Z polohy kurzora (fyzické px) na hodnotu posuvníka.
    fn audio_drag_to(&mut self, src: bool, x: f32, force: bool) {
        let r = self.audio_rects[src as usize];
        if r.w <= 1.0 {
            return;
        }
        let pct = (((x - r.x) / r.w).clamp(0.0, 1.0) * self.audio_max() as f32).round() as u32;
        self.audio_set_volume(src, pct, force);
    }

    /// Po skončení ťahania pošle poslednú hodnotu, ak ešte nebola odoslaná.
    fn audio_flush(&mut self, src: bool) {
        if !self.audio_unsent {
            return;
        }
        if let Some(i) = self.audio_default(src) {
            let pct = if src { self.audio.sources[i].volume } else { self.audio.sinks[i].volume };
            self.audio_unsent = false;
            self.audio_sent = Instant::now();
            self.queued.push(Action::Audio(crate::audio::AudioCmd::Volume { source: src, pct }));
        }
    }

    fn monitor_set_value(&mut self, contrast: bool, pct: u32, force: bool) {
        let pct = pct.min(100);
        let cur = if contrast { self.monitor.contrast } else { self.monitor.brightness };
        let changed = cur != pct;
        if contrast {
            self.monitor.contrast = pct;
        } else {
            self.monitor.brightness = pct;
        }
        self.monitor_unsent |= changed;
        let now = Instant::now();
        if self.monitor_unsent && (force || now.duration_since(self.monitor_sent) >= Duration::from_millis(80)) {
            self.monitor_unsent = false;
            self.monitor_sent = now;
            if contrast {
                self.queued.push(Action::Monitor(crate::monitor::MonitorCmd::Contrast(pct)));
            } else {
                self.queued.push(Action::Monitor(crate::monitor::MonitorCmd::Brightness(pct)));
            }
        }
    }

    fn monitor_drag_to(&mut self, contrast: bool, x: f32, force: bool) {
        let r = self.monitor_rects[contrast as usize];
        if r.w <= 1.0 {
            return;
        }
        let pct = (((x - r.x) / r.w).clamp(0.0, 1.0) * 100.0).round() as u32;
        self.monitor_set_value(contrast, pct, force);
    }

    fn monitor_flush(&mut self, contrast: bool) {
        if !self.monitor_unsent {
            return;
        }
        let pct = if contrast { self.monitor.contrast } else { self.monitor.brightness };
        self.monitor_unsent = false;
        self.monitor_sent = Instant::now();
        if contrast {
            self.queued.push(Action::Monitor(crate::monitor::MonitorCmd::Contrast(pct)));
        } else {
            self.queued.push(Action::Monitor(crate::monitor::MonitorCmd::Brightness(pct)));
        }
    }

    /// Uvoľnenie tlačidla myši (koniec ťahania posuvníka).
    pub fn release(&mut self, button: u32, now: Instant) {
        if button != BTN_LEFT {
            return;
        }
        if let Some(src) = self.audio_drag.take() {
            self.audio_flush(src);
        }
        if let Some(contrast) = self.monitor_drag.take() {
            self.monitor_flush(contrast);
        }
    }

    /// Akcie vzniknuté mimo `click` (ťahanie posuvníka, koliesko).
    pub fn take_queued(&mut self) -> Vec<Action> {
        std::mem::take(&mut self.queued)
    }

    /// Počet riadkov zoznamu sietí, ktoré sú vidieť (aspoň 1 – kvôli správe „žiadne siete“).
    fn wifi_rows_shown(&self) -> usize {
        self.wifi_list_len().min(self.cfg.wifi.rows).max(1)
    }

    /// Počet riadkov zoznamu vrátane posledného „Skrytá sieť…“ (0 = zoznam sa nezobrazuje).
    fn wifi_list_len(&self) -> usize {
        if self.wifi_loaded && self.wifi.available && self.wifi.enabled && self.wifi.error.is_empty() {
            self.wifi.aps.len() + 1
        } else {
            0
        }
    }
    /// Prebieha zadávanie hesla Wi-Fi.
    fn typing_password(&self) -> bool {
        self.panel == Panel::Wifi && self.wifi_pw.is_some()
    }

    /// Okno drží klávesnicu výhradne, kým je otvorené: Esc zatvára, schránka filtruje, Wi-Fi číta heslo.
    pub fn wants_keyboard(&self) -> bool {
        self.panel != Panel::None
    }

    /// Okno sa má zavrieť (panel je zatvorený a nič sa už neotvára) – proces skončí hneď, bez animácie.
    pub fn finished(&self) -> bool {
        self.started && self.panel == Panel::None && self.menu_wait.is_none()
    }


    fn px_font(&self) -> f32 {
        self.cfg.font_size * self.scale
    }


    fn ellipsize(text: &mut Text, s: &str, px: f32, maxw: f32) -> String {
        if text.measure(s, px) <= maxw {
            return s.to_string();
        }
        let mut chars: Vec<char> = s.chars().collect();
        while !chars.is_empty() {
            chars.pop();
            let t: String = chars.iter().collect::<String>() + "…";
            if text.measure(&t, px) <= maxw {
                return t;
            }
        }
        String::new()
    }


    fn wrap(text: &mut Text, s: &str, px: f32, maxw: f32, max_lines: usize) -> Vec<String> {
        let mut lines: Vec<String> = Vec::new();
        for para in s.split('\n') {
            let mut cur = String::new();
            for word in para.split_whitespace() {
                let cand = if cur.is_empty() { word.to_string() } else { format!("{cur} {word}") };
                if text.measure(&cand, px) <= maxw || cur.is_empty() {
                    cur = cand;
                } else {
                    lines.push(std::mem::take(&mut cur));
                    cur = word.to_string();
                }
            }
            lines.push(cur);
        }
        while lines.last().map(|l| l.is_empty()).unwrap_or(false) {
            lines.pop();
        }
        if lines.len() > max_lines {
            lines.truncate(max_lines);
            let last = lines.pop().unwrap_or_default();
            lines.push(Self::ellipsize(text, &(last + " …"), px, maxw));
        }
        lines.into_iter().map(|l| Self::ellipsize(text, &l, px, maxw)).collect()
    }

    /// Okno sa neotvára naraz, ale vyrastie pružinou z rozmeru `(w, h)` (predošlé okno).
    pub fn start_from(&mut self, w: f32, h: f32) {
        self.big_snap = false;
        self.hw_w.snap((w * self.scale).min(self.surf_w));
        self.hw_h.snap((h * self.scale).min(self.surf_h));
    }

    pub fn open_named(&mut self, name: &str) -> bool {
        let name = name.trim();
        if name.is_empty() {
            return false;
        }
        self.ext_name = name.to_string();
        if let Some(a) = self.run_module(name) {
            self.queued.push(a);
        }
        self.started = self.big_open() || self.menu_wait.is_some();
        self.started
    }

    /// Klávesnicu sa nepodarilo použiť (chýba mapa kláves) – zadávanie hesla sa zruší
    /// (panel schránky funguje ďalej, len bez filtrovania písaním).
    pub fn keyboard_unavailable(&mut self) {
        if self.typing_password() {
            self.wifi_pw = None;
            self.wifi_note = "Klávesnica nie je dostupná (pozri stderr)".into();
        }
    }

    /// Prepočíta zoznam položiek schránky podľa filtra; výber a posun ostanú v platnom rozsahu.
    fn clip_refilter(&mut self) {
        self.clip_view = clip_filter(&self.clip, &self.clip_query);
        let n = self.clip_view.len();
        self.clip_sel = self.clip_sel.filter(|_| n > 0).map(|p| p.min(n - 1));
        self.clip_scroll = self.clip_scroll.min(n.saturating_sub(self.cfg.clip_rows));
    }

    /// Po zmene filtra: späť na začiatok, vybraná je najlepšia (prvá) zhoda – Enter ju skopíruje.
    fn clip_query_changed(&mut self) {
        self.clip_scroll = 0;
        self.clip_acc = 0.0;
        self.clip_sel = None;
        self.clip_refilter();
        if !self.clip_view.is_empty() {
            self.clip_sel = Some(0);
        }
        // pri písaní panel nezatvárame, ani keď myš odišla
    }

    /// Posunie výber o `delta` riadkov a zoznam posunie tak, aby bol vybraný riadok viditeľný.
    fn clip_move_sel(&mut self, delta: isize) {
        let n = self.clip_view.len();
        if n == 0 {
            return;
        }
        // bez výberu sa ráta od „riadku pred prvým“, takže ↓ vyberie prvú položku
        let base = match self.clip_sel {
            Some(p) => p as isize,
            None if delta > 0 => -1,
            None => 0,
        };
        let p = (base + delta).clamp(0, n as isize - 1) as usize;
        self.clip_sel = Some(p);
        let rows = self.cfg.clip_rows;
        if p < self.clip_scroll {
            self.clip_scroll = p;
        } else if p >= self.clip_scroll + rows {
            self.clip_scroll = p + 1 - rows;
        }
    }
    /// Klávesy v otvorenom paneli schránky: písmená filtrujú, ↑/↓ menia výber, Enter skopíruje, Esc zavrie.
    fn clip_key(&mut self, k: &crate::wl::KeyEvent) -> Vec<Action> {
        let mut out = Vec::new();
        match k.sym {
            0xff1b => {
                // Escape
                self.set_panel(Panel::None);
            }
            0xff0d | 0xff8d => {
                // Enter: vybraná položka (po písaní prvá zhoda)
                let pick = self.clip_sel.and_then(|p| self.clip_view.get(p)).and_then(|&i| self.clip.get(i));
                if let Some(e) = pick {
                    out.push(Action::ClipCopy(e.raw.clone()));
                    self.set_panel(Panel::None);
                }
            }
            0xff08 => {
                // Backspace
                if self.clip_query.pop().is_some() {
                    self.clip_query_changed();
                }
            }
            0xff52 => self.clip_move_sel(-1),
            0xff54 | 0xff09 => self.clip_move_sel(1), // ↓, Tab
            0xff55 => self.clip_move_sel(-(self.cfg.clip_rows as isize)),
            0xff56 => self.clip_move_sel(self.cfg.clip_rows as isize),
            0xff50 => self.clip_move_sel(isize::MIN / 2), // Home
            0xff57 => self.clip_move_sel(isize::MAX / 2), // End
            0x75 | 0x55 if k.ctrl => {
                // Ctrl+U: zmazať filter
                if !self.clip_query.is_empty() {
                    self.clip_query.clear();
                    self.clip_query_changed();
                }
            }
            _ if !k.ctrl => {
                let before = self.clip_query.len();
                self.clip_query.extend(k.text.chars().filter(|c| !c.is_control()));
                if self.clip_query.len() != before {
                    self.clip_query_changed();
                }
            }
            _ => {}
        }
        out
    }

    pub fn key(&mut self, k: &crate::wl::KeyEvent) -> Vec<Action> {
        if self.panel == Panel::Clip {
            return self.clip_key(k);
        }
        // Esc zatvorí okno (pri zadávaní hesla Wi-Fi najprv zruší zadávanie)
        if !self.typing_password() && k.sym == 0xff1b {
            self.set_panel(Panel::None);
            return Vec::new();
        }
        self.wifi_pw_until = Some(Instant::now() + Duration::from_secs(WIFI_PW_IDLE_SECS));
        let mut out = Vec::new();
        let Some(pw) = &mut self.wifi_pw else { return out };
        // skrytá sieť, krok 1: názov (SSID)
        if pw.ssid_stage {
            match k.sym {
                0xff1b => self.wifi_pw = None,
                0xff08 => {
                    pw.ssid.pop();
                }
                0xff0d | 0xff8d => {
                    if !pw.ssid.trim().is_empty() {
                        pw.ssid = pw.ssid.trim().to_string();
                        pw.ssid_stage = false;
                    }
                }
                0x76 | 0x56 if k.ctrl => out.push(Action::WifiPaste),
                _ if !k.ctrl => pw.ssid.extend(k.text.chars().filter(|c| !c.is_control())),
                _ => {}
            }
            return out;
        }
        match k.sym {
            0xff1b => self.wifi_pw = None, // Escape
            0xff08 => {
                pw.text.pop();
            }
            0xff0d | 0xff8d if pw.hidden => {
                // Enter: prázdne heslo = otvorená sieť, inak WPA / WPA2 / WPA3
                if !pw.text.is_empty() && pw.text.chars().count() < 8 {
                    self.wifi_note = "Heslo WPA musí mať aspoň 8 znakov".into();
                    return out;
                }
                if let Some(pw) = self.wifi_pw.take() {
                    self.wifi_note = format!("Pripájam k {}…", pw.ssid);
                    let password = (!pw.text.is_empty()).then_some(pw.text);
                    out.push(Action::Wifi(crate::wifi::WifiCmd::ConnectHidden { ssid: pw.ssid, password }));
                }
            }
            0xff0d | 0xff8d => {
                // Enter
                if pw.text.is_empty() {
                    return out;
                }
                if pw.key_mgmt == "wpa-psk" && pw.text.chars().count() < 8 {
                    self.wifi_note = "Heslo WPA musí mať aspoň 8 znakov".into();
                    return out;
                }
                let pw = self.wifi_pw.take().unwrap_or(WifiPw { ssid: String::new(), ap: String::new(), key_mgmt: String::new(), text: String::new(), hidden: false, ssid_stage: false });
                self.wifi_note = format!("Pripájam k {}…", pw.ssid);
                out.push(Action::Wifi(crate::wifi::WifiCmd::Connect { ssid: pw.ssid, ap: pw.ap, saved: None, password: Some(pw.text), key_mgmt: pw.key_mgmt }));
            }
            0x76 | 0x56 if k.ctrl => out.push(Action::WifiPaste),
            _ if !k.ctrl => pw.text.extend(k.text.chars().filter(|c| !c.is_control())),
            _ => {}
        }
        out
    }

    /// Počet riadkov celej mriežky náhľadov.
    fn wall_row_count(&self) -> usize {
        self.wall.len().div_ceil(self.cfg.wall.columns)
    }

    /// Počet práve viditeľných riadkov mriežky (aspoň 1 – aj pre hlášku o prázdnom adresári).
    fn wall_rows_shown(&self) -> usize {
        self.wall_row_count().min(self.cfg.wall.rows).max(1)
    }
    /// Počet riadkov panela schránky, ktoré sú práve vidieť.
    fn clip_rows(&self) -> usize {
        self.cfg.clip_rows.min(self.clip_view.len()).max(1)
    }

    /// Počet riadkov zoznamu koša, ktoré sú práve vidieť.
    fn trash_rows(&self) -> usize {
        crate::trash::rows_shown(self.trash.len(), self.cfg.trash.rows)
    }

    /// Vybrané položky koša (v poradí zoznamu).
    fn trash_selected(&self) -> Vec<crate::trash::TrashEntry> {
        self.trash.iter().filter(|e| self.trash_sel.contains(&e.info)).cloned().collect()
    }
    /// Otvorí menu `mi`: spustí `exec` jeho položiek (výstupy sa začínajú prázdne, nič sa neukladá medzi otvoreniami)
    /// a zobrazí ho hneď, alebo pri `wait_exec` až po načítaní výstupov (najneskôr po `wait_timeout_ms`).
    fn open_menu(&mut self, mi: usize) {
        let Some((wait, wait_ms)) = self.menu_start(mi) else { return };
        if wait {
            // aktuálny panel ostáva, kým výstupy nedobehnú; akákoľvek zmena panela čakanie zruší
            self.menu_wait = Some((mi, Instant::now() + Duration::from_millis(wait_ms)));
        } else {
            self.set_panel(Panel::Menu(mi));
        }
    }

    /// Pripraví otvorenie menu `mi` (nová generácia, prázdne výstupy) a spustí `exec` jeho položiek.
    /// Vráti `(čakať na výstupy?, najdlhšie čakanie v ms)`; `None` = menu neexistuje. Panel nemení.
    fn menu_start(&mut self, mi: usize) -> Option<(bool, u64)> {
        let m = self.cfg.menus.get(mi)?;
        let jobs: Vec<(usize, String)> = m.items.iter().enumerate().filter(|(_, it)| !it.exec.is_empty()).map(|(i, it)| (i, it.exec.clone())).collect();
        let (n, wait, wait_ms) = (m.items.len(), m.wait_exec, m.wait_ms);
        self.menu_gen = self.menu_gen.wrapping_add(1);
        self.menu_mi = mi;
        self.menu_out = vec![None; n];
        self.menu_due = vec![None; n];
        let wait = wait && !jobs.is_empty();
        for (idx, cmd) in jobs {
            self.queued.push(Action::MenuExec { gen: self.menu_gen, idx, cmd });
        }
        Some((wait, wait_ms))
    }

    /// Všetky položky s `exec` otvoreného menu majú načítaný výstup.
    fn menu_ready(&self) -> bool {
        let Some(m) = self.cfg.menus.get(self.menu_mi) else { return true };
        m.items.iter().enumerate().all(|(i, it)| it.exec.is_empty() || self.menu_out.get(i).map_or(false, |o| o.is_some()))
    }

    /// Zobrazený text textovej položky menu (pri `exec` podľa výstupu, inak `label` / `icon`).
    fn menu_item_label(&self, mi: usize, i: usize, it: &crate::config::MenuItemCfg) -> String {
        if it.exec.is_empty() {
            return if !it.label.is_empty() { it.label.clone() } else { it.icon.clone() };
        }
        let out = if mi == self.menu_mi { self.menu_out.get(i).and_then(|o| o.as_deref()) } else { None };
        menu_item_text(&it.label, out)
    }

    /// Znovu spustí `exec` položiek s `interval` > 0, kým je menu otvorené a predošlý beh dobehol.
    fn menu_refresh(&mut self, now: Instant) {
        let Panel::Menu(mi) = self.panel else { return };
        if mi != self.menu_mi {
            return;
        }
        let jobs: Vec<(usize, String)> = match self.cfg.menus.get(mi) {
            Some(m) => m
                .items
                .iter()
                .enumerate()
                .filter(|(i, it)| it.interval > 0.0 && !it.exec.is_empty() && self.menu_due.get(*i).copied().flatten().map_or(false, |t| now >= t))
                .map(|(i, it)| (i, it.exec.clone()))
                .collect(),
            None => return,
        };
        for (idx, cmd) in jobs {
            self.menu_due[idx] = None;
            self.queued.push(Action::MenuExec { gen: self.menu_gen, idx, cmd });
        }
    }

    fn menu_index(&self, name: &str) -> Option<usize> {
        self.cfg.menus.iter().position(|m| m.name == name)
    }
    // ------------------------------------------------------ časovače
    pub fn tick(&mut self, now: Instant) -> bool {
        let mut changed = false;
        if let Some(t) = self.wifi_pw_until {
            if now >= t {
                self.wifi_pw_until = None;
                if self.wifi_pw.take().is_some() {
                    self.wifi_note = "Zadávanie hesla vypršalo".into();
                    changed = true;
                }
            }
        }
        // `wait_exec`: výstupy nedobehli včas – menu sa otvorí s tým, čo je
        if let Some((mi, t)) = self.menu_wait {
            if now >= t {
                self.set_panel(Panel::Menu(mi));
                changed = true;
            }
        }
        self.menu_refresh(now);
        changed
    }
    pub fn next_deadline(&self) -> Option<Instant> {
        // najbližšie obnovenie položky menu s `interval` (len kým je to menu otvorené)
        let menu_due = if self.panel == Panel::Menu(self.menu_mi) { self.menu_due.iter().flatten().min().copied() } else { None };
        [self.wifi_pw.as_ref().and(self.wifi_pw_until), self.menu_wait.map(|w| w.1), menu_due].into_iter().flatten().min()
    }

    // ------------------------------------------------------- ukazovateľ

    fn hit_at(&self, x: f32, y: f32) -> Option<Hit> {
        for (r, h) in self.hits.iter().rev() {
            if r.contains(x, y) {
                return Some(*h);
            }
        }
        if self.pill.contains(x, y) {
            return Some(Hit::Panel);
        }
        None
    }
    pub fn pointer_move(&mut self, lx: f32, ly: f32, _now: Instant) {
        let (x, y) = (lx * self.scale, ly * self.scale);
        self.ptr = Some((x, y));
        if let Some(src) = self.audio_drag {
            self.audio_drag_to(src, x, false);
            return;
        }
        if let Some(contrast) = self.monitor_drag {
            self.monitor_drag_to(contrast, x, false);
            return;
        }
        let h = self.hit_at(x, y);
        if h == self.hover {
            return;
        }
        self.hover = h;
        if matches!(h, Some(Hit::ClipItem(_))) {
            // myš prebrala zvýrazňovanie – klávesnicový výber sa zruší, kým sa znova nepoužije
            self.clip_sel = None;
        }
    }
    /// Okno sa pri odchode myši nezatvára (zatvára sa Esc, klikom na položku alebo druhým spustením).
    pub fn pointer_leave(&mut self, _now: Instant) {
        self.ptr = None;
        self.hover = None;
    }
    fn action_for(cmd: &str) -> Option<Action> {
        match cmd {
            "" | "menu" | "clipboard" | "trash" | "wallpaper" | "wifi" | "audio" | "monitor" | "bluetooth" | "capture" => None,
            c if Self::quickset_cmd(c).is_some() => None,
            other => Some(Action::Run(other.to_string())),
        }
    }

    fn run_module(&mut self, name: &str) -> Option<Action> {
        let p = match name.trim() {
            "clipboard" => Panel::Clip,
            "trash" => Panel::Trash,
            "wallpaper" => Panel::Wall,
            "wifi" => Panel::Wifi,
            "audio" => Panel::Audio,
            "monitor" => Panel::Monitor,
            "bluetooth" => Panel::Bluetooth,
            "capture" => Panel::Capture,
            // `quickset` = kontajner so záložkami (posledná záložka), `quickset:wifi` = rovno konkrétna záložka
            other if Self::quickset_cmd(other).is_some() => {
                let tab = Self::quickset_cmd(other).flatten().and_then(|m| self.hw_tab_index(m));
                self.open_quickset(tab);
                return None;
            }
            other => {
                if let Some(mi) = self.menu_index(other) {
                    self.open_menu(mi);
                }
                return None;
            }
        };
        self.set_panel(p);
        None
    }

    pub fn click(&mut self, button: u32, now: Instant) -> Vec<Action> {
        let mut out = self.click_inner(button, now);
        out.extend(self.queued.drain(..));
        out
    }

    fn click_inner(&mut self, button: u32, now: Instant) -> Vec<Action> {
        let mut out = Vec::new();
        let Some((x, y)) = self.ptr else { return out };

        // custom menu: zatvorí sa klikom na položku
        if matches!(self.panel, Panel::Menu(_)) {
            if button == BTN_LEFT {
                let hit = self.hit_at(x, y);
                // menu otvorené ako záložka kontajnera `quickset`: lišta so záložkami ostáva ovládateľná
                if let Some(Hit::HwTab(i)) = hit {
                    if self.hw && i != self.hw_tab {
                        self.open_quickset(Some(i));
                    }
                    return out;
                }
                if let Some(Hit::HwBtn(i)) = hit {
                    out.extend(self.run_quickset_button(i, now));
                    return out;
                }
                let mut cmd = String::new();
                if let (Some(Hit::MenuItem(k)), Panel::Menu(mi)) = (hit, self.panel) {
                    if let Some(item) = self.cfg.menus.get(mi).and_then(|m| m.items.get(k)) {
                        cmd = item.command.clone();
                    }
                }
                // `module:...` – otvorí iný panel (s animáciou prepnutia) namiesto shell príkazu
                if let Some(name) = cmd.strip_prefix("module:") {
                    let name = name.to_string();
                    out.extend(self.run_module(&name));
                    return out;
                }
                if !cmd.is_empty() {
                    out.push(Action::Run(cmd));
                }
                // klik na položku okno zatvorí; klik na okraj/nadpis ho nechá otvorené
                if matches!(hit, Some(Hit::MenuItem(_))) {
                    self.set_panel(Panel::None);
                }
            }
            return out;
        }

        let Some(h) = self.hit_at(x, y) else { return out };
        match h {
            Hit::ClipItem(i) => {
                if button == BTN_LEFT {
                    if let Some(e) = self.clip.get(i) {
                        out.push(Action::ClipCopy(e.raw.clone()));
                    }
                    self.set_panel(Panel::None);
                }
            }
            Hit::TrashRow(i) => {
                if button == BTN_LEFT {
                    if let Some(e) = self.trash.get(i) {
                        let key = e.info.clone();
                        if !self.trash_sel.remove(&key) {
                            self.trash_sel.insert(key);
                        }
                    }
                    self.trash_note.clear();
                }
            }
            Hit::TrashAll => {
                if button == BTN_LEFT {
                    if self.trash_sel.len() == self.trash.len() {
                        self.trash_sel.clear();
                    } else {
                        self.trash_sel = self.trash.iter().map(|e| e.info.clone()).collect();
                    }
                    self.trash_note.clear();
                }
            }
            Hit::TrashRestore => {
                if button == BTN_LEFT {
                    let items = self.trash_selected();
                    if !items.is_empty() {
                        self.trash_note = "Obnovujem…".into();
                        out.push(Action::TrashRestore(items));
                    }
                }
            }
            Hit::TrashEmpty => {
                if button == BTN_LEFT && !self.trash.is_empty() {
                    if self.cfg.trash.confirm_empty {
                        self.trash_confirm = true;
                    } else {
                        self.trash_note = "Mažem…".into();
                        out.push(Action::TrashEmpty(self.trash.clone()));
                    }
                }
            }
            Hit::TrashYes => {
                if button == BTN_LEFT {
                    self.trash_confirm = false;
                    if !self.trash.is_empty() {
                        self.trash_note = "Mažem…".into();
                        out.push(Action::TrashEmpty(self.trash.clone()));
                    }
                }
            }
            Hit::TrashNo => {
                if button == BTN_LEFT {
                    self.trash_confirm = false;
                }
            }
            Hit::HwTab(i) => {
                if button == BTN_LEFT && i != self.hw_tab {
                    self.open_quickset(Some(i));
                }
            }
            Hit::HwBtn(i) => {
                if button == BTN_LEFT {
                    out.extend(self.run_quickset_button(i, now));
                }
            }
            Hit::WifiToggle => {
                if button == BTN_LEFT {
                    self.wifi_note.clear();
                    out.push(Action::Wifi(crate::wifi::WifiCmd::SetEnabled(!self.wifi.enabled)));
                }
            }
            Hit::AudioMute(src) => {
                if button == BTN_LEFT {
                    if let Some(i) = self.audio_default(src) {
                        let d = if src { &mut self.audio.sources[i] } else { &mut self.audio.sinks[i] };
                        d.mute = !d.mute;
                    }
                    out.push(Action::Audio(crate::audio::AudioCmd::ToggleMute { source: src }));
                }
            }
            Hit::AudioDev(src, i) => {
                if button == BTN_LEFT {
                    let name = if src { self.audio.sources.get(i).map(|d| d.name.clone()) } else { self.audio.sinks.get(i).map(|d| d.name.clone()) };
                    if let Some(name) = name {
                        if src {
                            self.audio.default_source = name.clone();
                        } else {
                            self.audio.default_sink = name.clone();
                        }
                        out.push(Action::Audio(crate::audio::AudioCmd::SetDefault { source: src, name }));
                    }
                }
            }
            Hit::AudioSlider(src) => {
                if button == BTN_LEFT {
                    self.audio_drag = Some(src);
                    self.audio_drag_to(src, x, true);
                }
            }
            Hit::MonSlider(contrast) => {
                if button == BTN_LEFT {
                    self.monitor_drag = Some(contrast);
                    self.monitor_drag_to(contrast, x, true);
                }
            }
            Hit::MonPreset(i) => {
                if button == BTN_LEFT {
                    self.monitor.preset = Some(i);
                    out.push(Action::Monitor(crate::monitor::MonitorCmd::Preset(i)));
                }
            }
            Hit::MonInput(i) => {
                if button == BTN_LEFT {
                    self.monitor.input = Some(i);
                    out.push(Action::Monitor(crate::monitor::MonitorCmd::Input(i)));
                }
            }
            Hit::CapMode(i) => {
                if button == BTN_LEFT {
                    if let Some(m) = crate::capture::Mode::ALL.get(i) {
                        self.cap_mode = *m;
                    }
                }
            }
            Hit::CapKind(i) => {
                if button == BTN_LEFT {
                    if let Some(k) = crate::capture::Kind::ALL.get(i) {
                        self.cap_kind = *k;
                    }
                }
            }
            Hit::CapDelay(i) => {
                if button == BTN_LEFT && i < self.cfg.capture.delays.len() {
                    self.cap_delay = i;
                }
            }
            Hit::CapToggle => {
                if button == BTN_LEFT {
                    if self.cap_kind == crate::capture::Kind::Image {
                        self.cap_cursor = !self.cap_cursor;
                    } else {
                        self.cap_audio = !self.cap_audio;
                    }
                }
            }
            Hit::CapGo => {
                if button == BTN_LEFT {
                    let req = crate::capture::Request {
                        mode: self.cap_mode,
                        kind: self.cap_kind,
                        delay: self.cfg.capture.delays.get(self.cap_delay).copied().unwrap_or(0),
                        cursor: self.cap_cursor,
                        audio: self.cap_audio,
                    };
                    // panel sa zatvorí hneď, aby nebol na snímke / nahrávke; zvyšok robí oddelený proces
                    self.set_panel(Panel::None);
                    out.push(Action::Capture(req));
                }
            }
            Hit::MonNight => {
                if button == BTN_LEFT {
                    let enable = !self.monitor.night;
                    self.monitor.night = enable;
                    out.push(Action::Monitor(crate::monitor::MonitorCmd::SetNight(enable)));
                }
            }
            Hit::BtToggle => {
                if button == BTN_LEFT {
                    let on = !self.bluetooth.powered;
                    self.bluetooth.powered = on;
                    out.push(Action::Bluetooth(crate::bluetooth::BtCmd::SetPowered(on)));
                }
            }
            Hit::BtDiscoverable => {
                if button == BTN_LEFT {
                    let on = !self.bluetooth.discoverable;
                    self.bluetooth.discoverable = on;
                    out.push(Action::Bluetooth(crate::bluetooth::BtCmd::SetDiscoverable(on)));
                }
            }
            Hit::BtRefresh => {
                if button == BTN_LEFT {
                    out.push(Action::Bluetooth(crate::bluetooth::BtCmd::Load { scan: true }));
                }
            }
            Hit::BtEditor => {
                if button == BTN_LEFT && !self.cfg.bluetooth.editor_command.is_empty() {
                    out.push(Action::Run(self.cfg.bluetooth.editor_command.clone()));
                    self.set_panel(Panel::None);
                }
            }
            Hit::BtRow(i) => {
                if let Some(d) = self.bluetooth.devices.get(i).cloned() {
                    if button == BTN_RIGHT {
                        // zabudnúť vždy, ak je v zozname (aj nespárované z discovery)
                        out.push(Action::Bluetooth(crate::bluetooth::BtCmd::Forget(d.path)));
                    } else if button == BTN_MIDDLE {
                        out.push(Action::Bluetooth(crate::bluetooth::BtCmd::SetTrusted {
                            path: d.path,
                            trusted: !d.trusted,
                        }));
                    } else if button == BTN_LEFT {
                        if d.connected {
                            out.push(Action::Bluetooth(crate::bluetooth::BtCmd::Disconnect(d.path)));
                        } else {
                            // Connect sám sparuje, ak treba (náhrada blueman)
                            out.push(Action::Bluetooth(crate::bluetooth::BtCmd::Connect(d.path)));
                        }
                    }
                }
            }
            Hit::WifiEditor => {
                if button == BTN_LEFT {
                    out.push(Action::Run(self.cfg.wifi.editor_command.clone()));
                    self.set_panel(Panel::None);
                }
            }
            Hit::WifiRefresh => {
                if button == BTN_LEFT {
                    self.wifi_note = "Hľadám siete…".into();
                    out.push(Action::Wifi(crate::wifi::WifiCmd::Load));
                }
            }
            Hit::WifiHidden => {
                if button == BTN_LEFT {
                    self.wifi_note.clear();
                    self.wifi_pw = Some(WifiPw { ssid: String::new(), ap: "/".into(), key_mgmt: String::new(), text: String::new(), hidden: true, ssid_stage: true });
                    self.wifi_pw_until = Some(now + Duration::from_secs(WIFI_PW_IDLE_SECS));
                }
            }
            Hit::WifiRow(i) => {
                if let Some(ap) = self.wifi.aps.get(i).cloned() {
                    if button == BTN_RIGHT {
                        if let Some(conn) = ap.saved {
                            out.push(Action::Wifi(crate::wifi::WifiCmd::Forget(conn)));
                            self.wifi_note = format!("Zabúdam {}…", ap.ssid);
                        }
                    } else if button == BTN_LEFT {
                        if ap.active {
                            out.push(Action::Wifi(crate::wifi::WifiCmd::Disconnect));
                            self.wifi_note = "Odpájam…".into();
                        } else if ap.saved.is_some() || !ap.secured {
                            self.wifi_note = format!("Pripájam k {}…", ap.ssid);
                            out.push(Action::Wifi(crate::wifi::WifiCmd::Connect { ssid: ap.ssid, ap: ap.ap, saved: ap.saved, password: None, key_mgmt: ap.key_mgmt }));
                        } else if ap.supported {
                            self.wifi_note.clear();
                            self.wifi_pw = Some(WifiPw { ssid: ap.ssid, ap: ap.ap, key_mgmt: ap.key_mgmt, text: String::new(), hidden: false, ssid_stage: false });
                            self.wifi_pw_until = Some(now + Duration::from_secs(WIFI_PW_IDLE_SECS));
                        } else {
                            self.wifi_note = "Tento typ zabezpečenia ostrovček nepodporuje".into();
                        }
                    }
                }
            }
            Hit::WallItem(i) => {
                if button == BTN_LEFT {
                    if let Some(e) = self.wall.get(i) {
                        // pri vybranej téme sa mení len pozadie (bez matugenu), v režime „wallpaper“ aj farby
                        out.push(Action::WallApply { path: e.path.clone(), background_only: !self.wall_theme.is_empty() });
                    }
                    self.set_panel(Panel::None);
                }
            }
            Hit::WallRollout => {
                if button == BTN_LEFT {
                    self.wall_menu = !self.wall_menu;
                    self.wall_menu_scroll = 0;
                }
            }
            Hit::WallTheme(i) => {
                if button == BTN_LEFT {
                    self.wall_menu = false;
                    if i == 0 {
                        // pseudotéma: len prepne režim (zmaže zapamätanú tému), farby sa zmenia pri ďalšom nastavení pozadia
                        self.wall_theme.clear();
                        out.push(Action::WallTheme(None));
                    } else if let Some((name, path)) = self.wall_themes.get(i - 1).cloned() {
                        out.push(Action::WallTheme(Some((name, path))));
                    }
                }
            }
            Hit::WallButton(i) => {
                if button == BTN_LEFT {
                    if let Some(b) = self.cfg.wall.buttons.get(i) {
                        if !b.command.is_empty() {
                            out.push(Action::Run(b.command.clone()));
                        }
                    }
                    self.set_panel(Panel::None);
                }
            }
            _ => {}
        }
        let _ = now;
        out
    }

    pub fn scroll(&mut self, value: f32) {
        if self.panel == Panel::Audio {
            // koliesko nad posuvníkom mení hlasitosť o `step` % (hore = viac)
            if let Some(Hit::AudioSlider(src)) = self.hover {
                self.audio_acc += value;
                let steps = (self.audio_acc / AUDIO_SCROLL_UNIT).trunc();
                self.audio_acc -= steps * AUDIO_SCROLL_UNIT;
                if steps != 0.0 {
                    if let Some(i) = self.audio_default(src) {
                        let cur = if src { self.audio.sources[i].volume } else { self.audio.sinks[i].volume } as f32;
                        let new = (cur - steps * self.cfg.vol_step as f32).clamp(0.0, self.audio_max() as f32);
                        self.audio_set_volume(src, new.round() as u32, true);
                    }
                }
            }
        }
        if self.panel == Panel::Wifi && self.hover.is_some() && self.wifi_pw.is_none() {
            self.wifi_acc += value;
            let rows = (self.wifi_acc / WIFI_SCROLL_UNIT).trunc();
            self.wifi_acc -= rows * WIFI_SCROLL_UNIT;
            let max_start = self.wifi_list_len().saturating_sub(self.cfg.wifi.rows) as f32;
            self.wifi_scroll = (self.wifi_scroll as f32 + rows).clamp(0.0, max_start) as usize;
        }
        if self.panel == Panel::Bluetooth && self.hover.is_some() {
            self.bluetooth_acc += value;
            let rows = (self.bluetooth_acc / WIFI_SCROLL_UNIT).trunc();
            self.bluetooth_acc -= rows * WIFI_SCROLL_UNIT;
            let max_start = self.bluetooth.devices.len().saturating_sub(self.cfg.bluetooth.rows) as f32;
            self.bluetooth_scroll = (self.bluetooth_scroll as f32 + rows).clamp(0.0, max_start) as usize;
        }
        if self.panel == Panel::Wall && self.hover.is_some() && self.wall_menu {
            self.wall_acc += value;
            let steps = (self.wall_acc / WALL_SCROLL_UNIT).trunc();
            self.wall_acc -= steps * WALL_SCROLL_UNIT;
            let max_start = (self.wall_themes.len() + 1).saturating_sub(1) as f32;
            self.wall_menu_scroll = (self.wall_menu_scroll as f32 + steps).clamp(0.0, max_start) as usize;
        } else if self.panel == Panel::Wall && self.hover.is_some() {
            self.wall_acc += value;
            let rows = (self.wall_acc / WALL_SCROLL_UNIT).trunc();
            self.wall_acc -= rows * WALL_SCROLL_UNIT;
            let max_start = self.wall_row_count().saturating_sub(self.cfg.wall.rows) as f32;
            self.wall_scroll = (self.wall_scroll as f32 + rows).clamp(0.0, max_start) as usize;
        }
        if self.panel == Panel::Trash && self.hover.is_some() {
            self.trash_acc += value;
            let rows = (self.trash_acc / TRASH_SCROLL_UNIT).trunc();
            self.trash_acc -= rows * TRASH_SCROLL_UNIT;
            let max_start = self.trash.len().saturating_sub(self.cfg.trash.rows) as f32;
            self.trash_scroll = (self.trash_scroll as f32 + rows).clamp(0.0, max_start) as usize;
        }
        if self.panel == Panel::Clip && self.hover.is_some() {
            // koliesko aj touchpad: posun sa zbiera a každá celá jednotka = jeden riadok
            self.clip_acc += value;
            let rows = (self.clip_acc / CLIP_SCROLL_UNIT).trunc();
            self.clip_acc -= rows * CLIP_SCROLL_UNIT;
            let max_start = self.clip_view.len().saturating_sub(self.cfg.clip_rows) as f32;
            self.clip_scroll = (self.clip_scroll as f32 + rows).clamp(0.0, max_start) as usize;
        }
    }

    pub fn input_rect(&self) -> Option<(i32, i32, i32, i32)> {
        if self.pill.w < 1.0 {
            return None;
        }
        let k = 1.0 / self.scale;
        let x0 = ((self.pill.x - 2.0) * k).floor().max(0.0) as i32;
        let y0 = ((self.pill.y - 2.0) * k).floor().max(0.0) as i32;
        let x1 = ((self.pill.x + self.pill.w + 2.0) * k).ceil() as i32;
        let y1 = ((self.pill.y + self.pill.h + 2.0) * k).ceil() as i32;
        Some((x0, y0, x1 - x0, y1 - y0))
    }
    // ------------------------------------------------------ kreslenie
    pub fn build(&mut self, text: &mut Text) -> Frame {
        let s = self.scale;
        let t = self.theme;
        // okno je v strede povrchu (povrch je v strede obrazovky); jeho rozmer dobieha pružinami pri prepnutí panela
        let pill_w = self.hw_w.x.min(self.surf_w);
        let pill_h = self.hw_h.x.min(self.surf_h);
        let pill = Rect::new(((self.surf_w - pill_w) * 0.5).round(), ((self.surf_h - pill_h) * 0.5).round(), pill_w, pill_h);
        self.pill = pill;
        self.hits.clear();

        let mut frame = Frame::default();
        let radius = (self.cfg.radius * s).min(pill_h * 0.5).min(pill_w * 0.5);

        // tieň + pozadie
        if self.cfg.shadow {
            frame.back.push(Item::Rect {
                r: Rect::new(pill.x + self.s(2.0), pill.y + self.s(5.0), pill.w - self.s(4.0), pill.h),
                radius,
                soft: self.s(12.0),
                color: [0.0, 0.0, 0.0, 0.32],
            });
        }
        let mut bg = t.bg;
        bg[3] *= self.cfg.opacity;
        frame.back.push(Item::Rect { r: pill, radius, soft: 0.8, color: bg });
        frame.clip = Some(Rect::new(pill.x, pill.y, pill.w, pill.h));

        if self.big_open() && pill_w > 1.0 {
            self.hits.push((pill, Hit::Panel));
            // v kontajneri `quickset` sa panel kreslí do zvyšku okna vedľa lišty so záložkami
            let content = if self.hw_view() { self.build_hw_bar(&mut frame, text, pill, 1.0) } else { pill };
            match self.big {
                Panel::Menu(mi) => self.build_menu(&mut frame, text, content, mi, 1.0),
                Panel::Clip => self.build_clip(&mut frame, text, content, 1.0),
                Panel::Trash => self.build_trash(&mut frame, text, content, 1.0),
                Panel::Wall => self.build_wall(&mut frame, text, content, 1.0),
                Panel::Wifi => self.build_wifi(&mut frame, text, content, 1.0),
                Panel::Audio => self.build_audio(&mut frame, text, content, 1.0),
                Panel::Monitor => self.build_monitor(&mut frame, text, content, 1.0),
                Panel::Capture => self.build_capture(&mut frame, text, content, 1.0),
                Panel::Bluetooth => self.build_bluetooth(&mut frame, text, content, 1.0),
                Panel::None => {}
            }
        }
        frame
    }

    /// Lišty kontajnera `quickset`: záložky a (voliteľne) druhá lišta s tlačidlami na opačnej strane;
    /// vráti obdĺžnik pre obsah (zvyšok okna).
    fn build_hw_bar(&mut self, frame: &mut Frame, text: &mut Text, pill: Rect, pa: f32) -> Rect {
        use crate::quickset as hw;
        let s = self.scale;
        let (pos, tab, active) = (self.cfg.hw.pos, self.cfg.hw.tab_size * s, self.hw_tab);
        let (gap, igap) = (self.cfg.hw.tab_gap * s, self.cfg.hw.inverse_gap * s);
        let icon_px = self.cfg.hw.icon_size * s;
        let icons: Vec<String> = self.cfg.hw.tabs.iter().map(|x| x.icon.clone()).collect();
        let inv_icons: Vec<String> = self.cfg.hw.inverse.iter().map(|x| x.icon.clone()).collect();
        let bar_t = hw::bar_thickness(tab, HW_BAR_PAD * s);
        let win = (pill.x, pill.y, pill.w, pill.h);
        let (bar1, mut content) = hw::split(pos, win, bar_t);
        self.draw_hw_strip(frame, text, bar1, pos, tab, gap, icon_px, &icons, Some(active), Hit::HwTab, pa);
        if !inv_icons.is_empty() {
            let ipos = pos.opposite();
            let (bar2, rest) = hw::split(ipos, content, bar_t);
            content = rest;
            self.draw_hw_strip(frame, text, bar2, ipos, tab, igap, icon_px, &inv_icons, None, Hit::HwBtn, pa);
        }
        Rect::new(content.0, content.1, content.2, content.3)
    }

    /// Jedna lišta tlačidiel (podklad + ikony); `active` = zvýraznená záložka, `mk` = typ zásahu.
    #[allow(clippy::too_many_arguments)]
    fn draw_hw_strip(&mut self, frame: &mut Frame, text: &mut Text, bar: crate::quickset::R, pos: crate::quickset::TabPos, tab: f32, gap: f32, icon_px: f32, icons: &[String], active: Option<usize>, mk: fn(usize) -> Hit, pa: f32) {
        use crate::quickset as hw;
        let s = self.scale;
        let t = self.theme;
        let (bx, by, bw, bh) = bar;
        // podklad lišty
        let inset = HW_BAR_INSET * s;
        let back = Rect::new(bx + inset, by + inset, (bw - 2.0 * inset).max(0.0), (bh - 2.0 * inset).max(0.0));
        frame.content.push(Item::Rect { r: back, radius: (tab * 0.5).min(back.w * 0.5).min(back.h * 0.5), soft: 0.8, color: fade(t.fg, 0.07 * pa) });

        let (asc, desc) = text.line_metrics(icon_px);
        for (i, (rx, ry, rw, rh)) in hw::tab_rects(pos, bar, icons.len(), tab, gap, HW_BAR_PAD * s).into_iter().enumerate() {
            let r = Rect::new(rx, ry, rw, rh);
            self.hits.push((r, mk(i)));
            let on = active == Some(i);
            let hov = self.hover == Some(mk(i));
            let fg = if on {
                frame.content.push(Item::Rect { r, radius: rh * 0.32, soft: 0.8, color: fade(t.menu_selected, pa) });
                t.menu_selected_text
            } else {
                if hov {
                    frame.content.push(Item::Rect { r, radius: rh * 0.32, soft: 0.8, color: fade(t.accent, 0.25 * pa) });
                }
                t.fg
            };
            let icon = &icons[i];
            let iw = text.measure(icon, icon_px);
            text.layout_to(&mut frame.content, icon, icon_px, r.x + (r.w - iw) * 0.5, r.y + r.h * 0.5 + (asc - desc) * 0.5, fade(fg, pa));
        }
    }

    fn build_menu(&mut self, frame: &mut Frame, text: &mut Text, pill: Rect, mi: usize, pa: f32) {
        let Some(menu) = self.cfg.menus.get(mi).cloned() else { return };
        let s = self.scale;
        let t = self.theme;
        let icon_cols = menu.icon_columns.max(1);
        let text_cols = menu.text_columns.max(1);
        let pad = menu.padding * s;
        let gap = menu.gap * s;
        let title_h = if menu.title.is_empty() { 0.0 } else { 36.0 * s };
        let icon_cell = (menu.icon_size + 16.0) * s;
        let label_h = (menu.text_size + 18.0) * s;
        let label_cell_w = menu.cell_width * s;
        let sep_h = ((menu.separator_thickness + 12.0).max(14.0)) * s;
        let sep_thick = menu.separator_thickness * s;

        let icon_grid_w = icon_cols as f32 * icon_cell + (icon_cols.saturating_sub(1)) as f32 * gap;
        let text_grid_w = text_cols as f32 * label_cell_w + (text_cols.saturating_sub(1)) as f32 * gap;
        let content_w = menu_content_width(menu.kind, icon_grid_w, text_grid_w, &menu);

        let icon_px = menu.icon_size * s;
        let text_px = menu.text_size * s;
        let (asc_t, desc_t) = text.line_metrics(text_px);
        let (asc_h, desc_h) = text.line_metrics(self.px_font());
        let layout = Self::menu_rows(&menu);

        if !menu.title.is_empty() {
            let px = self.px_font();
            let tw = text.measure(&menu.title, px);
            let cy = pill.y + title_h * 0.5;
            text.layout_to(
                &mut frame.content,
                &menu.title,
                px,
                pill.x + (pill.w - tw) * 0.5,
                cy + (asc_h - desc_h) * 0.5,
                fade(t.fg, pa),
            );
        }

        let grid_top = pill.y + pad + title_h;
        let grid_left = pill.x + (pill.w - content_w) * 0.5;

        let mut y = grid_top;
        for (ri, row) in layout.iter().enumerate() {
            if ri > 0 {
                y += gap;
            }
            match row {
                MenuLayoutRow::Icons(indices) => {
                    let n = indices.len();
                    let row_w = n as f32 * icon_cell + (n.saturating_sub(1)) as f32 * gap;
                    // centrovať riadok v rámci content_w (neúplný aj pri užšej ikonovej mriežke)
                    let row_left = grid_left + (content_w - row_w) * 0.5;
                    for (c, &i) in indices.iter().enumerate() {
                        let x = row_left + c as f32 * (icon_cell + gap);
                        let cell = Rect::new(x, y, icon_cell, icon_cell);
                        // položka bez `command` je len na zobrazenie: bez hoveru a bez reakcie na klik
                        let clickable = menu.items.get(i).map_or(false, |it| !it.command.is_empty());
                        let hov = clickable && self.hover == Some(Hit::MenuItem(i));
                        if clickable {
                            self.hits.push((cell, Hit::MenuItem(i)));
                        }
                        if hov {
                            frame.content.push(Item::Rect {
                                r: cell,
                                radius: 10.0 * s,
                                soft: 0.8,
                                color: fade(t.fg, 0.10 * pa),
                            });
                        }
                        if let Some(it) = menu.items.get(i) {
                            if !it.icon.is_empty() {
                                if let Some(icon) = self.icons.get(&it.icon) {
                                    let max = icon_px;
                                    let sc = (max / icon.w as f32).min(max / icon.h as f32);
                                    let dw = icon.w as f32 * sc;
                                    let dh = icon.h as f32 * sc;
                                    let ix = x + (icon_cell - dw) * 0.5;
                                    let iy = y + (icon_cell - dh) * 0.5;
                                    frame.content.push(Item::Image {
                                        r: Rect::new(ix, iy, dw, dh),
                                        path: it.icon.clone(),
                                        color: [1.0, 1.0, 1.0, pa],
                                        radius: 0.0,
                                    });
                                }
                            }
                        }
                    }
                    y += icon_cell;
                }
                MenuLayoutRow::Labels(indices) => {
                    let n = indices.len();
                    let row_w = n as f32 * label_cell_w + (n.saturating_sub(1)) as f32 * gap;
                    let row_left = grid_left + (content_w - row_w) * 0.5;
                    for (c, &i) in indices.iter().enumerate() {
                        let x = row_left + c as f32 * (label_cell_w + gap);
                        let cell = Rect::new(x, y, label_cell_w, label_h);
                        // položka bez `command` je len na zobrazenie: bez hoveru a bez reakcie na klik
                        let clickable = menu.items.get(i).map_or(false, |it| !it.command.is_empty());
                        let hov = clickable && self.hover == Some(Hit::MenuItem(i));
                        if clickable {
                            self.hits.push((cell, Hit::MenuItem(i)));
                        }
                        let (bg_col, fg_col) = if hov {
                            (fade(t.menu_selected, pa), fade(t.menu_selected_text, pa))
                        } else {
                            (fade(t.fg, 0.0), fade(t.fg, pa))
                        };
                        if hov {
                            frame.content.push(Item::Rect {
                                r: cell,
                                radius: 10.0 * s,
                                soft: 0.8,
                                color: bg_col,
                            });
                        }
                        if let Some(it) = menu.items.get(i) {
                            let label = self.menu_item_label(mi, i, it);
                            if !label.is_empty() {
                                let maxw = label_cell_w - 12.0 * s;
                                let shown = Self::ellipsize(text, &label, text_px, maxw);
                                let tw = text.measure(&shown, text_px);
                                let cx = x + (label_cell_w - tw) * 0.5;
                                let cy = y + label_h * 0.5;
                                text.layout_to(
                                    &mut frame.content,
                                    &shown,
                                    text_px,
                                    cx,
                                    cy + (asc_t - desc_t) * 0.5,
                                    fg_col,
                                );
                            }
                        }
                    }
                    y += label_h;
                }
                MenuLayoutRow::Line(i) => {
                    let i = *i;
                    // zvýraznenie má po stranách odsadenie, aby nedosadalo na okraj menu (ako ostatné tlačidlá)
                    let inset = 8.0 * s;
                    let cell = Rect::new(grid_left + inset, y, (content_w - 2.0 * inset).max(0.0), label_h);
                    // bez `command` je riadok len na zobrazenie: bez hoveru a bez reakcie na klik
                    let clickable = menu.items.get(i).map_or(false, |it| !it.command.is_empty());
                    let hov = clickable && self.hover == Some(Hit::MenuItem(i));
                    if clickable {
                        self.hits.push((cell, Hit::MenuItem(i)));
                    }
                    let fg_col = if hov { fade(t.menu_selected_text, pa) } else { fade(t.fg, pa) };
                    if hov {
                        frame.content.push(Item::Rect { r: cell, radius: 10.0 * s, soft: 0.8, color: fade(t.menu_selected, pa) });
                    }
                    if let Some(it) = menu.items.get(i) {
                        let label = self.menu_item_label(mi, i, it);
                        if !label.is_empty() {
                            let shown = Self::ellipsize(text, &label, text_px, cell.w - 12.0 * s);
                            let tw = text.measure(&shown, text_px);
                            text.layout_to(
                                &mut frame.content,
                                &shown,
                                text_px,
                                cell.x + (cell.w - tw) * 0.5,
                                y + label_h * 0.5 + (asc_t - desc_t) * 0.5,
                                fg_col,
                            );
                        }
                    }
                    y += label_h;
                }
                MenuLayoutRow::Separator(pos) => {
                    let line_w = content_w * menu.separator_length;
                    let lx = grid_left + (content_w - line_w) * 0.5;
                    // čiara v strede riadku, alebo bližšie k hornému / dolnému okraju (štvrtina voľného miesta)
                    let free = sep_h - sep_thick;
                    let ly = y + match pos {
                        SepAlign::Top => free * 0.25,
                        SepAlign::Center => free * 0.5,
                        SepAlign::Bottom => free * 0.75,
                    };
                    frame.content.push(Item::Rect {
                        r: Rect::new(lx, ly, line_w, sep_thick),
                        radius: sep_thick * 0.5,
                        soft: 0.6,
                        color: fade(t.fg, 0.28 * pa),
                    });
                    y += sep_h;
                }
            }
        }
    }

    /// Nakreslí PNG ikonu `path` do štvorca `size` (zachová pomer strán). `false` = ikonu sa nepodarilo načítať.
    fn push_icon(&mut self, frame: &mut Frame, path: &str, x: f32, y: f32, size: f32, alpha: f32) -> bool {
        let Some(ic) = self.icons.get(path) else { return false };
        let (iw, ih) = (ic.w.max(1) as f32, ic.h.max(1) as f32);
        let sc = (size / iw).min(size / ih);
        let (dw, dh) = (iw * sc, ih * sc);
        frame.content.push(Item::Image {
            r: Rect::new(x + (size - dw) * 0.5, y + (size - dh) * 0.5, dw, dh),
            path: path.to_string(),
            color: [1.0, 1.0, 1.0, alpha.clamp(0.0, 1.0)],
            // zaoblené rohy ikony / obalu úmerné veľkosti
            radius: size * 0.14,
        });
        true
    }

    fn build_clip(&mut self, frame: &mut Frame, text: &mut Text, pill: Rect, pa: f32) {
        let s = self.scale;
        let t = self.theme;
        let px = self.cfg.clip_font * s;
        let (asc, desc) = text.line_metrics(px);
        let pad = CLIP_PAD * s;
        let row_h = (self.cfg.clip_font + CLIP_ROW_EXTRA) * s;
        let n = self.clip_view.len();

        if n == 0 {
            let msg = if !self.clip.is_empty() {
                // filter nič nenašiel (písaný text sa nikde inde nezobrazuje, tak aspoň tu)
                format!("Nič nenájdené pre „{}“", self.clip_query.trim())
            } else if self.clip_loaded {
                "Schránka je prázdna".to_string()
            } else {
                "Načítavam…".to_string()
            };
            let msg = Self::ellipsize(text, &msg, px, pill.w - 2.0 * pad);
            let tw = text.measure(&msg, px);
            let cy = pill.y + pill.h * 0.5;
            text.layout_to(&mut frame.content, &msg, px, pill.x + (pill.w - tw) * 0.5, cy + (asc - desc) * 0.5, fade(t.fg, 0.7 * pa));
            return;
        }

        let rows = self.clip_rows();
        let scrollable = n > rows;
        let sb = if scrollable { CLIP_SCROLLBAR * s } else { 0.0 };
        let start = self.clip_scroll.min(n - rows);
        let inset = 10.0 * s;
        let cell_w = pill.w - 2.0 * pad - sb;

        for k in 0..rows {
            let pos = start + k;
            let i = self.clip_view[pos];
            let y = pill.y + pad + k as f32 * row_h;
            let cell = Rect::new(pill.x + pad, y, cell_w, row_h);
            self.hits.push((cell, Hit::ClipItem(i)));
            // zvýraznený je riadok vybraný klávesnicou, a ak nie je žiadny vybraný, riadok pod myšou
            let hov = match self.clip_sel {
                Some(p) => p == pos,
                None => self.hover == Some(Hit::ClipItem(i)),
            };
            let fg = if hov {
                frame.content.push(Item::Rect { r: cell, radius: 10.0 * s, soft: 0.8, color: fade(t.menu_selected, pa) });
                fade(t.menu_selected_text, pa)
            } else {
                fade(t.fg, pa)
            };
            let label = Self::ellipsize(text, &self.clip[i].text, px, cell_w - 2.0 * inset);
            text.layout_to(&mut frame.content, &label, px, cell.x + inset, y + row_h * 0.5 + (asc - desc) * 0.5, fg);
        }

        if scrollable {
            // posuvník: dráha vpravo, bežec ukazuje polohu a podiel viditeľných riadkov
            let track_h = rows as f32 * row_h;
            let thumb_h = (track_h * rows as f32 / n as f32).max(16.0 * s).min(track_h);
            let frac = start as f32 / (n - rows) as f32;
            let thumb_y = pill.y + pad + (track_h - thumb_h) * frac;
            let w = 4.0 * s;
            let x = pill.x + pill.w - pad - sb + (sb - w) * 0.5;
            frame.content.push(Item::Rect { r: Rect::new(x, thumb_y, w, thumb_h), radius: w * 0.5, soft: 0.8, color: fade(t.fg, 0.35 * pa) });
        }
    }

    /// Tlačidlo hlavičky koša: `hit = None` = vypnuté (stlmené, bez reakcie na myš). Vráti šírku.
    fn trash_button(&mut self, frame: &mut Frame, text: &mut Text, x: f32, y: f32, h: f32, px: f32, label: &str, colors: (Color, Color), hit: Option<Hit>, pa: f32) -> f32 {
        let s = self.scale;
        let t = self.theme;
        let (asc, desc) = text.line_metrics(px);
        let w = text.measure(label, px) + 36.0 * s;
        let r = Rect::new(x, y, w, h);
        let (bg, fg) = match hit {
            Some(hh) => {
                self.hits.push((r, hh));
                let a = if self.hover == Some(hh) { 1.0 } else { 0.85 };
                (fade(colors.0, a * pa), fade(colors.1, pa))
            }
            None => (fade(t.fg, 0.08 * pa), fade(t.fg, 0.35 * pa)),
        };
        frame.content.push(Item::Rect { r, radius: h * 0.5, soft: 0.8, color: bg });
        let tw = text.measure(label, px);
        text.layout_to(&mut frame.content, label, px, x + (w - tw) * 0.5, y + h * 0.5 + (asc - desc) * 0.5, fg);
        w
    }

    /// Zaškrtávacie políčko (štvorec so zaoblením; zaškrtnuté = vyplnené farbou accent s malým štvorčekom).
    fn trash_checkbox(&self, frame: &mut Frame, r: Rect, checked: bool, pa: f32) {
        let s = self.scale;
        let t = self.theme;
        if checked {
            frame.content.push(Item::Rect { r, radius: 4.0 * s, soft: 0.8, color: fade(t.accent, pa) });
            let d = r.w * 0.28;
            frame.content.push(Item::Rect { r: Rect::new(r.x + d, r.y + d, r.w - 2.0 * d, r.h - 2.0 * d), radius: 2.0 * s, soft: 0.8, color: fade(t.on_accent, pa) });
        } else {
            frame.content.push(Item::Rect { r, radius: 4.0 * s, soft: 0.8, color: fade(t.fg, 0.28 * pa) });
            let b = 1.5 * s;
            frame.content.push(Item::Rect { r: Rect::new(r.x + b, r.y + b, r.w - 2.0 * b, r.h - 2.0 * b), radius: 3.0 * s, soft: 0.8, color: fade(t.bg, 0.9 * pa) });
        }
    }

    fn build_trash(&mut self, frame: &mut Frame, text: &mut Text, pill: Rect, pa: f32) {
        let s = self.scale;
        let t = self.theme;
        let c = self.cfg.trash.clone();
        let px = c.font * s;
        let px2 = px * 0.85;
        let (asc, desc) = text.line_metrics(px);
        let (asc2, desc2) = text.line_metrics(px2);
        let pad = TRASH_PAD * s;
        let gap = TRASH_GAP * s;
        let row_h = (c.font + CLIP_ROW_EXTRA) * s;
        let btn_h = (c.font + 14.0) * s;
        let x0 = pill.x + pad;
        let w_in = pill.w - 2.0 * pad;
        let n = self.trash.len();
        let n_sel = self.trash_sel.len();

        // ---- hlavička: Obnoviť vybrané (vľavo) | Vyprázdniť kôš (vpravo, červené); pri potvrdení otázka a Áno / Nie
        let by = pill.y + pad;
        if self.trash_confirm {
            let yes_w = text.measure("Vymazať", px) + 36.0 * s;
            let no_w = text.measure("Zrušiť", px) + 36.0 * s;
            let xr = x0 + w_in;
            self.trash_button(frame, text, xr - yes_w, by, btn_h, px, "Vymazať", (t.alert, t.on_alert), Some(Hit::TrashYes), pa);
            self.trash_button(frame, text, xr - yes_w - gap - no_w, by, btn_h, px, "Zrušiť", (t.fg, t.bg), Some(Hit::TrashNo), pa);
            let q = format!("Natrvalo vymazať {}?", crate::trash::count_label(n));
            let q = Self::ellipsize(text, &q, px, (w_in - yes_w - no_w - 2.0 * gap).max(0.0));
            text.layout_to(&mut frame.content, &q, px, x0 + 4.0 * s, by + btn_h * 0.5 + (asc - desc) * 0.5, fade(t.fg, pa));
        } else {
            let rh = if n_sel > 0 { Some(Hit::TrashRestore) } else { None };
            self.trash_button(frame, text, x0, by, btn_h, px, "Obnoviť vybrané", (t.accent, t.on_accent), rh, pa);
            let eh = if n > 0 { Some(Hit::TrashEmpty) } else { None };
            let ew = text.measure("Vyprázdniť kôš", px) + 36.0 * s;
            self.trash_button(frame, text, x0 + w_in - ew, by, btn_h, px, "Vyprázdniť kôš", (t.alert, t.on_alert), eh, pa);
        }

        // ---- hlavička zoznamu: výber všetkého + názvy stĺpcov
        let rows = self.trash_rows();
        let scrollable = n > rows;
        let sb = if scrollable { TRASH_SCROLLBAR * s } else { 0.0 };
        let inset = 10.0 * s;
        let cb = (c.font * 0.9).max(12.0) * s;
        let col_x0 = x0 + inset + cb + 10.0 * s;
        let col_gap = 10.0 * s;
        let avail = (pill.x + pill.w - pad - sb - inset - col_x0).max(0.0);
        let date_w = text.measure("00.00.0000 00:00", px) + 4.0 * s;
        let (name_w, loc_w, dat_w) = crate::trash::columns(avail, date_w, col_gap, c.show_location, c.show_date);
        let name_x = col_x0;
        let mut nx = name_x + name_w + col_gap;
        let loc_x = nx;
        if c.show_location {
            nx += loc_w + col_gap;
        }
        let dat_x = nx;

        let hy = by + btn_h + gap;
        let cell = Rect::new(x0, hy, inset + cb + 10.0 * s, row_h);
        self.hits.push((cell, Hit::TrashAll));
        let all = n > 0 && n_sel == n;
        let hov = self.hover == Some(Hit::TrashAll);
        if hov {
            frame.content.push(Item::Rect { r: cell, radius: 8.0 * s, soft: 0.8, color: fade(t.fg, 0.10 * pa) });
        }
        self.trash_checkbox(frame, Rect::new(x0 + inset, hy + (row_h - cb) * 0.5, cb, cb), all, pa);
        let title_col = fade(t.fg, 0.55 * pa);
        let ty = hy + row_h * 0.5 + (asc2 - desc2) * 0.5;
        text.layout_to(&mut frame.content, "Názov", px2, name_x, ty, title_col);
        if c.show_location {
            text.layout_to(&mut frame.content, "Pôvodné umiestnenie", px2, loc_x, ty, title_col);
        }
        if c.show_date {
            text.layout_to(&mut frame.content, "Dátum zmazania", px2, dat_x, ty, title_col);
        }
        let ly = hy + row_h - 1.0 * s;
        frame.content.push(Item::Rect { r: Rect::new(x0, ly, w_in - sb, 1.0 * s), radius: 0.0, soft: 0.5, color: fade(t.fg, 0.12 * pa) });

        // ---- riadky
        let list_y = hy + row_h;
        if n == 0 {
            let msg = if self.trash_loaded { "Kôš je prázdny" } else { "Načítavam…" };
            let tw = text.measure(msg, px);
            let cy = list_y + rows as f32 * row_h * 0.5;
            text.layout_to(&mut frame.content, msg, px, pill.x + (pill.w - tw) * 0.5, cy + (asc - desc) * 0.5, fade(t.fg, 0.7 * pa));
        } else {
            let start = self.trash_scroll.min(n.saturating_sub(rows));
            for k in 0..rows.min(n) {
                let i = start + k;
                let y = list_y + k as f32 * row_h;
                let r = Rect::new(x0, y, w_in - sb, row_h);
                self.hits.push((r, Hit::TrashRow(i)));
                let checked = self.trash_sel.contains(&self.trash[i].info);
                if checked {
                    frame.content.push(Item::Rect { r, radius: 8.0 * s, soft: 0.8, color: fade(t.accent, 0.22 * pa) });
                } else if self.hover == Some(Hit::TrashRow(i)) {
                    frame.content.push(Item::Rect { r, radius: 8.0 * s, soft: 0.8, color: fade(t.fg, 0.10 * pa) });
                }
                self.trash_checkbox(frame, Rect::new(x0 + inset, y + (row_h - cb) * 0.5, cb, cb), checked, pa);
                let by0 = y + row_h * 0.5 + (asc - desc) * 0.5;
                let e = &self.trash[i];
                let name = Self::ellipsize(text, &e.name, px, name_w);
                text.layout_to(&mut frame.content, &name, px, name_x, by0, fade(t.fg, pa));
                if c.show_location {
                    let loc = Self::ellipsize(text, &e.location, px, loc_w);
                    text.layout_to(&mut frame.content, &loc, px, loc_x, by0, fade(t.fg, 0.7 * pa));
                }
                if c.show_date {
                    text.layout_to(&mut frame.content, &e.date, px, dat_x, by0, fade(t.fg, 0.7 * pa));
                }
            }
            if scrollable {
                let track_h = rows as f32 * row_h;
                let thumb_h = (track_h * rows as f32 / n as f32).max(16.0 * s).min(track_h);
                let frac = start as f32 / (n - rows) as f32;
                let thumb_y = list_y + (track_h - thumb_h) * frac;
                let w = 4.0 * s;
                let x = pill.x + pill.w - pad - sb + (sb - w) * 0.5;
                frame.content.push(Item::Rect { r: Rect::new(x, thumb_y, w, thumb_h), radius: w * 0.5, soft: 0.8, color: fade(t.fg, 0.35 * pa) });
            }
        }

        // ---- pätka: hláška o poslednej operácii, inak počet položiek a vybraných
        let foot_h = (c.font * 0.85 + 8.0) * s;
        let fy = list_y + rows as f32 * row_h + gap;
        // hover nad riadkom: pôvodná cesta položky (len kým je myš nad riadkom; počas potvrdenia sa nemení)
        let hovered_path = match self.hover {
            Some(Hit::TrashRow(i)) if !self.trash_confirm => self.trash.get(i).map(|e| {
                if e.location.ends_with('/') {
                    format!("{}{}", e.location, e.name)
                } else {
                    format!("{}/{}", e.location, e.name)
                }
            }),
            _ => None,
        };
        let msg = if let Some(p) = hovered_path {
            p
        } else if !self.trash_note.is_empty() {
            self.trash_note.clone()
        } else if n == 0 {
            String::new()
        } else if n_sel > 0 {
            format!("{} · vybrané: {}", crate::trash::count_label(n), n_sel)
        } else {
            crate::trash::count_label(n)
        };
        let msg = Self::ellipsize(text, &msg, px2, w_in - 2.0 * inset);
        text.layout_to(&mut frame.content, &msg, px2, x0 + inset, fy + foot_h * 0.5 + (asc2 - desc2) * 0.5, fade(t.fg, 0.7 * pa));
    }

    fn build_wifi(&mut self, frame: &mut Frame, text: &mut Text, pill: Rect, pa: f32) {
        let s = self.scale;
        let t = self.theme;
        let f = self.cfg.wifi.font_size;
        let px = f * s;
        let (asc, desc) = text.line_metrics(px);
        let pad = WIFI_PAD * s;
        let head = WIFI_HEAD * s;
        let row_h = (f + WIFI_ROW_EXTRA) * s;
        let x0 = pill.x + pad;
        let w_in = pill.w - 2.0 * pad;
        let inset = 12.0 * s;
        let hy = pill.y + pad;
        // mierne vyššie ako geometrický stred – opticky vycentruje prepínač / text / tlačidlá
        let hcy = hy + head * 0.5 - 6.0 * s;
        let base = |cy: f32| cy + (asc - desc) * 0.5;

        // ---- zadávanie hesla
        if let Some(pw) = &self.wifi_pw {
            let title = if pw.ssid_stage { "\u{f033e}  Skrytá sieť – názov (SSID)".to_string() } else { format!("\u{f033e}  Heslo pre {}", pw.ssid) };
            let title = Self::ellipsize(text, &title, px, w_in - 2.0 * inset);
            text.layout_to(&mut frame.content, &title, px, x0 + inset, base(hcy), fade(t.fg, pa));
            let bx = Rect::new(x0, hy + head + 4.0 * s, w_in, (f + 18.0) * s);
            frame.content.push(Item::Rect { r: bx, radius: 10.0 * s, soft: 0.8, color: fade(t.fg, 0.12 * pa) });
            let max_w = bx.w - 2.0 * inset;
            let mut dots: String = if pw.ssid_stage { pw.ssid.clone() } else { "\u{25cf}".repeat(pw.text.chars().count()) };
            while !dots.is_empty() && text.measure(&dots, px) > max_w {
                dots.remove(0);
            }
            let cy = bx.y + bx.h * 0.5;
            let mut cx = bx.x + inset;
            if dots.is_empty() {
                let ph = if pw.ssid_stage { "Názov siete" } else if pw.hidden { "Heslo (prázdne = otvorená sieť)" } else { "Heslo" };
                text.layout_to(&mut frame.content, ph, px, cx, base(cy), fade(t.fg, 0.4 * pa));
            } else {
                text.layout_to(&mut frame.content, &dots, px, cx, base(cy), fade(t.fg, pa));
                cx += text.measure(&dots, px);
            }
            frame.content.push(Item::Rect { r: Rect::new(cx + 2.0 * s, bx.y + 8.0 * s, 1.5 * s, bx.h - 16.0 * s), radius: 0.7 * s, soft: 0.8, color: fade(t.accent, pa) });
            let px2 = px * 0.85;
            let (a2, d2) = text.line_metrics(px2);
            let msg = if !self.wifi_note.is_empty() {
                self.wifi_note.as_str()
            } else if pw.ssid_stage {
                "Enter – ďalej · Esc – zrušiť · Ctrl+V – vložiť"
            } else {
                "Enter – pripojiť · Esc – zrušiť · Ctrl+V – vložiť"
            };
            let msg = Self::ellipsize(text, msg, px2, w_in - 2.0 * inset);
            let hy2 = bx.y + bx.h + 10.0 * s + (f * 0.85 + 6.0) * s * 0.5;
            text.layout_to(&mut frame.content, &msg, px2, x0 + inset, hy2 + (a2 - d2) * 0.5, fade(t.fg, 0.65 * pa));
            return;
        }

        // ---- hlavička: vľavo prepínač rádia + obnoviť, v strede pripojená sieť, vpravo správca pripojení
        let usable = self.wifi.available && self.wifi.error.is_empty();
        let on = usable && self.wifi.enabled;
        let active = self.wifi.aps.iter().find(|a| a.active).cloned();
        let tw = 40.0 * s;
        let th = 22.0 * s;
        let tog = Rect::new(x0 + inset * 0.5, hcy - th * 0.5, tw, th);
        let ref_sz = px * 1.7;
        let rbtn = Rect::new(tog.x + tog.w + 6.0 * s, hcy - ref_sz * 0.5, ref_sz, ref_sz);
        // tlačidlo správcu: len ikona a / alebo text z configu, pozadie sa kreslí iba pri hoveri
        let ed_label = crate::wifi::editor_text(&self.cfg.wifi.editor_icon, &self.cfg.wifi.editor_label);
        let ed_h = ref_sz * 1.1;
        let mut ed = Rect::new(0.0, 0.0, 0.0, 0.0);
        if !self.cfg.wifi.editor_command.is_empty() && !ed_label.is_empty() {
            let ed_w = (text.measure(&ed_label, px) + 2.0 * inset).max(ed_h);
            ed = Rect::new(pill.x + pill.w - pad - ed_w, hcy - ed_h * 0.5, ed_w, ed_h);
            self.hits.push((ed, Hit::WifiEditor));
            let hov = self.hover == Some(Hit::WifiEditor);
            if hov {
                frame.content.push(Item::Rect { r: ed, radius: ed.h * 0.5, soft: 0.8, color: fade(t.menu_selected, pa) });
            }
            let tw = text.measure(&ed_label, px);
            text.layout_to(&mut frame.content, &ed_label, px, ed.x + (ed.w - tw) * 0.5, base(hcy), fade(if hov { t.menu_selected_text } else { t.fg }, pa));
        }
        if self.wifi.available {
            self.hits.push((tog, Hit::WifiToggle));
            let track = if self.wifi.enabled { t.accent } else { t.fg };
            frame.content.push(Item::Rect { r: tog, radius: th * 0.5, soft: 0.8, color: fade(track, (if self.wifi.enabled { 1.0 } else { 0.3 }) * pa) });
            let kn = th - 6.0 * s;
            let kx = if self.wifi.enabled { tog.x + tog.w - 3.0 * s - kn } else { tog.x + 3.0 * s };
            frame.content.push(Item::Rect { r: Rect::new(kx, tog.y + 3.0 * s, kn, kn), radius: kn * 0.5, soft: 0.8, color: fade(if self.wifi.enabled { t.on_accent } else { t.fg }, pa) });
            if on {
                self.hits.push((rbtn, Hit::WifiRefresh));
                let hov = self.hover == Some(Hit::WifiRefresh);
                if hov {
                    frame.content.push(Item::Rect { r: rbtn, radius: 8.0 * s, soft: 0.8, color: fade(t.menu_selected, pa) });
                }
                let gw = text.measure("\u{f0450}", px);
                text.layout_to(&mut frame.content, "\u{f0450}", px, rbtn.x + (rbtn.w - gw) * 0.5, base(hcy), fade(if hov { t.menu_selected_text } else { t.fg }, pa));
            }
        }
        // stred: názov pripojenej siete (so silou signálu) alebo stav
        let (mid, mid_col) = if !self.wifi.error.is_empty() {
            ("Wi-Fi nedostupné".to_string(), 0.7)
        } else if !self.wifi_loaded {
            ("Načítavam…".to_string(), 0.7)
        } else if !self.wifi.available {
            ("Wi-Fi zariadenie nenájdené".to_string(), 0.7)
        } else if !self.wifi.enabled {
            ("Wi-Fi vypnuté".to_string(), 0.7)
        } else if let Some(a) = &active {
            (format!("{}  {}", crate::wifi::signal_glyph(a.strength), a.ssid), 1.0)
        } else {
            ("Nepripojené".to_string(), 0.7)
        };
        let left = rbtn.x + rbtn.w + 10.0 * s;
        let right = if ed.w > 0.0 { ed.x - 10.0 * s } else { x0 + w_in };
        if right > left {
            let mid = Self::ellipsize(text, &mid, px, right - left);
            let mw = text.measure(&mid, px);
            let col = if active.is_some() && on { t.accent } else { t.fg };
            text.layout_to(&mut frame.content, &mid, px, left + (right - left - mw) * 0.5, base(hcy), fade(col, mid_col * pa));
        }

        // ---- zoznam sietí
        let top = pill.y + pad + head;
        // posledný riadok zoznamu je „Skrytá sieť…“
        let n = self.wifi_list_len();
        let list_on = n > 0;
        let rows = self.wifi_rows_shown();
        if !list_on {
            let msg = if !self.wifi.error.is_empty() {
                self.wifi.error.clone()
            } else if !self.wifi_loaded {
                "Načítavam…".to_string()
            } else if !self.wifi.available {
                "Nenašiel som žiadne Wi-Fi zariadenie".to_string()
            } else if !self.wifi.enabled {
                "Wi-Fi je vypnuté".to_string()
            } else {
                "Žiadne siete".to_string()
            };
            let msg = Self::ellipsize(text, &msg, px, w_in - 2.0 * inset);
            let mw = text.measure(&msg, px);
            text.layout_to(&mut frame.content, &msg, px, x0 + (w_in - mw) * 0.5, base(top + row_h * 0.5), fade(t.fg, 0.7 * pa));
        } else {
            let scrollable = n > rows;
            let sb = if scrollable { WIFI_SCROLLBAR * s } else { 0.0 };
            let start = self.wifi_scroll.min(n - rows.min(n));
            let cell_w = w_in - sb;
            let px_small = px * 0.8;
            let (a3, d3) = text.line_metrics(px_small);
            // šírka stĺpca zabezpečenia = najširší popis v zozname; vpravo je pevné miesto na značku pripojenia
            let check_w = text.measure("\u{f012c}", px) + 6.0 * s;
            let sec_w = self.wifi.aps.iter().map(|a| text.measure(if a.sec.is_empty() { "Otvorená" } else { &a.sec }, px_small)).fold(0.0f32, f32::max);
            for k in 0..rows.min(n) {
                let i = start + k;
                let y = top + k as f32 * row_h;
                let cell = Rect::new(x0, y, cell_w, row_h);
                if i == self.wifi.aps.len() {
                    self.hits.push((cell, Hit::WifiHidden));
                    let hov = self.hover == Some(Hit::WifiHidden);
                    let fg = if hov {
                        frame.content.push(Item::Rect { r: cell, radius: 10.0 * s, soft: 0.8, color: fade(t.menu_selected, pa) });
                        t.menu_selected_text
                    } else {
                        t.fg
                    };
                    let cy = y + row_h * 0.5;
                    text.layout_to(&mut frame.content, "\u{f0415}", px, cell.x + inset, base(cy), fade(fg, 0.8 * pa));
                    let name_x = cell.x + inset + px * 1.9;
                    text.layout_to(&mut frame.content, "Skrytá sieť…", px, name_x, base(cy), fade(fg, 0.8 * pa));
                    continue;
                }
                self.hits.push((cell, Hit::WifiRow(i)));
                let hov = self.hover == Some(Hit::WifiRow(i));
                let ap = &self.wifi.aps[i];
                let fg = if hov {
                    frame.content.push(Item::Rect { r: cell, radius: 10.0 * s, soft: 0.8, color: fade(t.menu_selected, pa) });
                    t.menu_selected_text
                } else {
                    t.fg
                };
                let cy = y + row_h * 0.5;
                text.layout_to(&mut frame.content, crate::wifi::signal_glyph(ap.strength), px, cell.x + inset, base(cy), fade(fg, pa));
                // zprava doľava: značka pripojenia, stĺpec zabezpečenia, „uložená“
                let mut rx = cell.x + cell.w - inset - check_w;
                if ap.active {
                    text.layout_to(&mut frame.content, "\u{f012c}", px, rx, base(cy), fade(fg, pa));
                }
                rx -= 8.0 * s;
                let (label, dim) = if ap.sec.is_empty() { ("Otvorená", 0.5) } else { (ap.sec.as_str(), 0.75) };
                let lw = text.measure(label, px_small);
                // zarovnané vľavo v stĺpci, aby si popisy boli pod sebou
                let col_x = rx - sec_w;
                text.layout_to(&mut frame.content, label, px_small, col_x, cy + (a3 - d3) * 0.5, fade(fg, dim * pa));
                let _ = lw;
                rx = col_x - 10.0 * s;
                if ap.saved.is_some() && !ap.active {
                    let label = "uložená";
                    let gw = text.measure(label, px_small);
                    rx -= gw;
                    text.layout_to(&mut frame.content, label, px_small, rx, cy + (a3 - d3) * 0.5, fade(fg, 0.55 * pa));
                    rx -= 8.0 * s;
                }
                let name_x = cell.x + inset + px * 1.9;
                let name = Self::ellipsize(text, &ap.ssid, px, rx - name_x);
                text.layout_to(&mut frame.content, &name, px, name_x, base(cy), fade(fg, pa));
            }
            if scrollable {
                let track_h = rows as f32 * row_h;
                let thumb_h = (track_h * rows as f32 / n as f32).max(16.0 * s).min(track_h);
                let frac = start as f32 / (n - rows) as f32;
                let w = 4.0 * s;
                let x = x0 + cell_w + (sb - w) * 0.5;
                frame.content.push(Item::Rect { r: Rect::new(x, top + (track_h - thumb_h) * frac, w, thumb_h), radius: w * 0.5, soft: 0.8, color: fade(t.fg, 0.35 * pa) });
            }
        }

        // ---- päta: stav / nápoveda k riadku pod kurzorom
        let hint = match self.hover {
            Some(Hit::WifiRow(i)) => self.wifi.aps.get(i).map(|ap| {
                if ap.active {
                    "Klik – odpojiť"
                } else if ap.saved.is_some() {
                    "Klik – pripojiť · pravý klik – zabudnúť sieť"
                } else if !ap.supported {
                    "Nepodporované zabezpečenie"
                } else if ap.secured {
                    "Klik – zadať heslo"
                } else {
                    "Klik – pripojiť"
                }
            }),
            Some(Hit::WifiHidden) => Some("Klik – pripojiť k skrytej sieti (názov a heslo)"),
            _ => None,
        };
        let msg = if !self.wifi_note.is_empty() { Some(self.wifi_note.as_str()) } else { hint };
        if let Some(m) = msg {
            let px2 = px * 0.85;
            let (a2, d2) = text.line_metrics(px2);
            let m = Self::ellipsize(text, m, px2, w_in - 2.0 * inset);
            let cy = pill.y + pill.h - pad - WIFI_FOOT * s * 0.5;
            text.layout_to(&mut frame.content, &m, px2, x0 + inset, cy + (a2 - d2) * 0.5, fade(t.fg, 0.65 * pa));
        }
    }

    fn build_bluetooth(&mut self, frame: &mut Frame, text: &mut Text, pill: Rect, pa: f32) {
        let s = self.scale;
        let t = self.theme;
        let f = self.cfg.bluetooth.font_size;
        let px = f * s;
        let (asc, desc) = text.line_metrics(px);
        let pad = WIFI_PAD * s;
        let head = WIFI_HEAD * s;
        let row_h = (f + WIFI_ROW_EXTRA) * s;
        let x0 = pill.x + pad;
        let w_in = pill.w - 2.0 * pad;
        let inset = 12.0 * s;
        let hy = pill.y + pad;
        let hcy = hy + head * 0.5 - 6.0 * s;
        let base = |cy: f32| cy + (asc - desc) * 0.5;

        // hlavička: prepínač + obnoviť + voliteľný editor
        let tw = 40.0 * s;
        let th = 22.0 * s;
        let tog = Rect::new(x0 + inset * 0.5, hcy - th * 0.5, tw, th);
        let ref_sz = px * 1.7;
        let rbtn = Rect::new(tog.x + tog.w + 6.0 * s, hcy - ref_sz * 0.5, ref_sz, ref_sz);

        let mut ed = Rect::new(0.0, 0.0, 0.0, 0.0);
        // tlačidlo správcu: len ikona a / alebo text z configu, pozadie sa kreslí iba pri hoveri
        let ed_label = crate::wifi::editor_text(&self.cfg.bluetooth.editor_icon, &self.cfg.bluetooth.editor_label);
        if !self.cfg.bluetooth.editor_command.is_empty() && !ed_label.is_empty() {
            let ed_h = ref_sz * 1.1;
            let ed_w = (text.measure(&ed_label, px) + 2.0 * inset).max(ed_h);
            ed = Rect::new(pill.x + pill.w - pad - ed_w, hcy - ed_h * 0.5, ed_w, ed_h);
            self.hits.push((ed, Hit::BtEditor));
            let hov = self.hover == Some(Hit::BtEditor);
            if hov {
                frame.content.push(Item::Rect { r: ed, radius: ed.h * 0.5, soft: 0.8, color: fade(t.menu_selected, pa) });
            }
            let tw = text.measure(&ed_label, px);
            text.layout_to(
                &mut frame.content,
                &ed_label,
                px,
                ed.x + (ed.w - tw) * 0.5,
                base(hcy),
                fade(if hov { t.menu_selected_text } else { t.fg }, pa),
            );
        }

        if self.bluetooth.available {
            self.hits.push((tog, Hit::BtToggle));
            let on = self.bluetooth.powered;
            let track = if on { t.accent } else { t.fg };
            frame.content.push(Item::Rect {
                r: tog,
                radius: th * 0.5,
                soft: 0.8,
                color: fade(track, (if on { 1.0 } else { 0.3 }) * pa),
            });
            let kn = th - 6.0 * s;
            let kx = if on {
                tog.x + tog.w - 3.0 * s - kn
            } else {
                tog.x + 3.0 * s
            };
            frame.content.push(Item::Rect {
                r: Rect::new(kx, tog.y + 3.0 * s, kn, kn),
                radius: kn * 0.5,
                soft: 0.8,
                color: fade(if on { t.on_accent } else { t.fg }, pa),
            });

            if on {
                self.hits.push((rbtn, Hit::BtRefresh));
                let hov = self.hover == Some(Hit::BtRefresh);
                if hov {
                    frame.content.push(Item::Rect {
                        r: rbtn,
                        radius: 8.0 * s,
                        soft: 0.8,
                        color: fade(t.menu_selected, pa),
                    });
                }
                let gw = text.measure("\u{f0450}", px);
                text.layout_to(
                    &mut frame.content,
                    "\u{f0450}",
                    px,
                    rbtn.x + (rbtn.w - gw) * 0.5,
                    base(hcy),
                    fade(if hov { t.menu_selected_text } else { t.fg }, pa),
                );

                // viditeľnosť (discoverable) – aby ťa našli nové zariadenia
                let dlab = if self.bluetooth.discoverable { "Viditeľný" } else { "Skrytý" };
                let dw = text.measure(dlab, px * 0.85) + 16.0 * s;
                let dh = ref_sz * 1.0;
                let dbtn = Rect::new(rbtn.x + rbtn.w + 8.0 * s, hcy - dh * 0.5, dw, dh);
                self.hits.push((dbtn, Hit::BtDiscoverable));
                let dhov = self.hover == Some(Hit::BtDiscoverable);
                let dbg = if self.bluetooth.discoverable {
                    fade(t.accent, 0.35 * pa)
                } else if dhov {
                    fade(t.menu_selected, pa)
                } else {
                    fade(t.fg, 0.12 * pa)
                };
                frame.content.push(Item::Rect {
                    r: dbtn,
                    radius: dh * 0.5,
                    soft: 0.8,
                    color: dbg,
                });
                let (a2, d2) = text.line_metrics(px * 0.85);
                let lw = text.measure(dlab, px * 0.85);
                text.layout_to(
                    &mut frame.content,
                    dlab,
                    px * 0.85,
                    dbtn.x + (dbtn.w - lw) * 0.5,
                    hcy + (a2 - d2) * 0.5,
                    fade(if self.bluetooth.discoverable { t.on_accent } else if dhov { t.menu_selected_text } else { t.fg }, pa),
                );
            }
        }

        // stred: stav
        let (mid, mid_col) = if !self.bluetooth.note.is_empty() {
            (self.bluetooth.note.clone(), 0.9)
        } else if !self.bluetooth.error.is_empty() {
            (self.bluetooth.error.clone(), 0.7)
        } else if !self.bluetooth_loaded {
            ("Načítavam…".into(), 0.7)
        } else if !self.bluetooth.available {
            ("Adaptér nenájdený".into(), 0.7)
        } else if !self.bluetooth.powered {
            ("Bluetooth vypnutý".into(), 0.7)
        } else if self.bluetooth.discovering {
            ("Hľadám zariadenia…".into(), 0.85)
        } else {
            let n = self.bluetooth.devices.iter().filter(|d| d.connected).count();
            if n == 0 {
                ("Žiadne pripojené · ↻ hľadať".into(), 0.7)
            } else if n == 1 {
                let name = self
                    .bluetooth
                    .devices
                    .iter()
                    .find(|d| d.connected)
                    .map(|d| d.name.as_str())
                    .unwrap_or("");
                (name.to_string(), 1.0)
            } else {
                (format!("{n} pripojené"), 1.0)
            }
        };
        // ľavý okraj textu za tlačidlami (refresh + discoverable)
        let left = if self.bluetooth.powered {
            rbtn.x + rbtn.w + 8.0 * s + 90.0 * s
        } else {
            rbtn.x + rbtn.w + 10.0 * s
        };
        let right = if ed.w > 0.0 { ed.x - 10.0 * s } else { x0 + w_in };
        if right > left {
            let mid = Self::ellipsize(text, &mid, px, right - left);
            let mw = text.measure(&mid, px);
            text.layout_to(
                &mut frame.content,
                &mid,
                px,
                left + (right - left - mw) * 0.5,
                base(hcy),
                fade(t.fg, mid_col * pa),
            );
        }

        // zoznam
        let top = pill.y + pad + head;
        let n = self.bluetooth.devices.len();
        let rows = n.min(self.cfg.bluetooth.rows).max(1);
        if !self.bluetooth.available || !self.bluetooth.powered || n == 0 {
            let msg = if !self.bluetooth.error.is_empty() {
                self.bluetooth.error.clone()
            } else if !self.bluetooth_loaded {
                "Načítavam…".into()
            } else if !self.bluetooth.available {
                "Bluetooth adaptér sa nenašiel".into()
            } else if !self.bluetooth.powered {
                // stav „vypnutý“ už ukazuje hlavička (a prepínač), v zozname sa neopakuje
                String::new()
            } else {
                "Žiadne zariadenia – skús obnoviť".into()
            };
            let msg = Self::ellipsize(text, &msg, px, w_in - 2.0 * inset);
            let mw = text.measure(&msg, px);
            text.layout_to(
                &mut frame.content,
                &msg,
                px,
                x0 + (w_in - mw) * 0.5,
                base(top + row_h * 0.5),
                fade(t.fg, 0.7 * pa),
            );
        } else {
            let scrollable = n > rows;
            let sb = if scrollable { WIFI_SCROLLBAR * s } else { 0.0 };
            let start = self.bluetooth_scroll.min(n.saturating_sub(rows));
            let cell_w = w_in - sb;
            for k in 0..rows.min(n) {
                let i = start + k;
                let d = &self.bluetooth.devices[i];
                let y = top + k as f32 * row_h;
                let cell = Rect::new(x0, y, cell_w, row_h);
                self.hits.push((cell, Hit::BtRow(i)));
                let hov = self.hover == Some(Hit::BtRow(i));
                if hov {
                    frame.content.push(Item::Rect {
                        r: cell,
                        radius: 10.0 * s,
                        soft: 0.8,
                        color: fade(t.menu_selected, pa),
                    });
                }
                let fg = if hov {
                    t.menu_selected_text
                } else {
                    t.fg
                };
                let cy = cell.y + row_h * 0.5;
                let glyph = crate::bluetooth::device_glyph(d);
                let gw = text.measure(glyph, px);
                text.layout_to(&mut frame.content, glyph, px, cell.x + inset, base(cy), fade(fg, pa));
                let mut right = cell.x + cell.w - inset;
                if d.connected {
                    let mark = "\u{f012c}";
                    let mw = text.measure(mark, px);
                    right -= mw;
                    text.layout_to(&mut frame.content, mark, px, right, base(cy), fade(fg, pa));
                    right -= 8.0 * s;
                }
                if let Some(bat) = d.battery {
                    let bt = format!("{bat}%");
                    let bw = text.measure(&bt, px * 0.85);
                    right -= bw;
                    let (a2, d2) = text.line_metrics(px * 0.85);
                    text.layout_to(
                        &mut frame.content,
                        &bt,
                        px * 0.85,
                        right,
                        cy + (a2 - d2) * 0.5,
                        fade(fg, 0.75 * pa),
                    );
                    right -= 8.0 * s;
                }
                let name = Self::ellipsize(text, &d.name, px, right - (cell.x + inset + gw + 8.0 * s));
                text.layout_to(
                    &mut frame.content,
                    &name,
                    px,
                    cell.x + inset + gw + 8.0 * s,
                    base(cy),
                    fade(fg, pa),
                );
            }
            if scrollable {
                let track_h = rows as f32 * row_h;
                let thumb_h = (track_h * rows as f32 / n as f32).max(16.0 * s).min(track_h);
                let frac = start as f32 / (n - rows) as f32;
                let w = 4.0 * s;
                let x = pill.x + pill.w - pad - (WIFI_SCROLLBAR * s - w) * 0.5 - w;
                let y = top + (track_h - thumb_h) * frac;
                frame.content.push(Item::Rect {
                    r: Rect::new(x, y, w, thumb_h),
                    radius: w * 0.5,
                    soft: 0.8,
                    color: fade(t.fg, 0.35 * pa),
                });
            }
        }

        // päta
        let hint = if !self.bluetooth.note.is_empty() {
            Some(self.bluetooth.note.as_str())
        } else if !self.bluetooth.powered {
            Some("Zapni Bluetooth prepínačom vľavo")
        } else if self.hover == Some(Hit::BtRefresh) {
            Some("Hľadať nové zariadenia (sken)")
        } else if self.hover == Some(Hit::BtDiscoverable) {
            Some("Viditeľný = iné zariadenia ťa nájdu")
        } else {
            match self.hover {
                Some(Hit::BtRow(i)) => self.bluetooth.devices.get(i).map(|d| {
                    if d.connected {
                        "Klik – odpojiť · stred – trust · pravý – zabudnúť"
                    } else if d.paired {
                        "Klik – pripojiť · stred – trust · pravý – zabudnúť"
                    } else {
                        "Klik – spárovať a pripojiť · pravý – odstrániť"
                    }
                }),
                _ => Some("Klik = spárovať/pripojiť · ↻ = hľadať nové"),
            }
        };
        if let Some(m) = hint {
            let px2 = px * 0.85;
            let (a2, d2) = text.line_metrics(px2);
            let m = Self::ellipsize(text, m, px2, w_in - 2.0 * inset);
            let cy = pill.y + pill.h - pad - WIFI_FOOT * s * 0.5;
            text.layout_to(
                &mut frame.content,
                &m,
                px2,
                x0 + inset,
                cy + (a2 - d2) * 0.5,
                fade(t.fg, 0.65 * pa),
            );
        }
    }

    fn build_audio(&mut self, frame: &mut Frame, text: &mut Text, pill: Rect, pa: f32) {
        let s = self.scale;
        let t = self.theme;
        let f = self.cfg.audio_panel.font_size;
        let px = f * s;
        let px_small = px * 0.8;
        let (asc, desc) = text.line_metrics(px);
        let (a3, d3) = text.line_metrics(px_small);
        let base = |cy: f32| cy + (asc - desc) * 0.5;
        let pad = AUDIO_PAD * s;
        let row_h = (f + AUDIO_ROW_EXTRA) * s;
        let inset = 12.0 * s;
        let x0 = pill.x + pad;
        let w_in = pill.w - 2.0 * pad;
        let max_pct = self.audio_max() as f32;
        let mut y = pill.y + pad;

        for src in [false, true] {
            let list_len = if src { self.audio.sources.len() } else { self.audio.sinks.len() };
            let shown = list_len.min(self.cfg.audio_panel.rows).max(1);
            let di = self.audio_default(src);
            let (vol, muted) = match di {
                Some(i) => {
                    let d = if src { &self.audio.sources[i] } else { &self.audio.sinks[i] };
                    (d.volume, d.mute)
                }
                None => (0, false),
            };

            // názov sekcie
            let label = if src { "Vstup" } else { "Výstup" };
            let lh = AUDIO_LABEL * s;
            text.layout_to(&mut frame.content, label, px_small, x0 + inset, y + lh * 0.5 + (a3 - d3) * 0.5, fade(t.fg, 0.6 * pa));
            y += lh;

            // riadok posuvníka: tlačidlo stlmenia, dráha, percentá
            let cy = y + row_h * 0.5;
            let mb = Rect::new(x0, y, row_h, row_h);
            self.hits.push((mb, Hit::AudioMute(src)));
            let mhov = self.hover == Some(Hit::AudioMute(src));
            if mhov {
                frame.content.push(Item::Rect { r: mb, radius: 10.0 * s, soft: 0.8, color: fade(t.menu_selected, pa) });
            }
            let glyph = crate::audio::icon(src, muted, vol);
            let gw = text.measure(glyph, px);
            text.layout_to(&mut frame.content, glyph, px, mb.x + (mb.w - gw) * 0.5, base(cy), fade(if mhov { t.menu_selected_text } else if muted { t.alert } else { t.fg }, pa));
            let pct_w = text.measure("150%", px);
            let track_x = mb.x + mb.w + 8.0 * s;
            let track = Rect::new(track_x, cy - 3.0 * s, (x0 + w_in - pct_w - 12.0 * s - track_x).max(10.0 * s), 6.0 * s);
            self.audio_rects[src as usize] = track;
            self.hits.push((Rect::new(track.x - 8.0 * s, y, track.w + 16.0 * s, row_h), Hit::AudioSlider(src)));
            frame.content.push(Item::Rect { r: track, radius: 3.0 * s, soft: 0.8, color: fade(t.fg, 0.2 * pa) });
            let frac = (vol as f32 / max_pct).clamp(0.0, 1.0);
            let fill = (track.w * frac).max(if vol > 0 { 6.0 * s } else { 0.0 });
            let fill_col = if muted { fade(t.fg, 0.45 * pa) } else { fade(t.accent, pa) };
            if fill > 0.0 {
                frame.content.push(Item::Rect { r: Rect::new(track.x, track.y, fill, track.h), radius: 3.0 * s, soft: 0.8, color: fill_col });
            }
            let kn = 14.0 * s;
            let dragging = self.audio_drag == Some(src);
            let khov = dragging || self.hover == Some(Hit::AudioSlider(src));
            let kd = if khov { kn + 2.0 * s } else { kn };
            frame.content.push(Item::Rect { r: Rect::new(track.x + track.w * frac - kd * 0.5, cy - kd * 0.5, kd, kd), radius: kd * 0.5, soft: 0.8, color: fade(if muted { t.fg } else { t.accent }, pa) });
            let ptxt = format!("{vol}%");
            let pw = text.measure(&ptxt, px);
            text.layout_to(&mut frame.content, &ptxt, px, x0 + w_in - pw, base(cy), fade(t.fg, (if muted { 0.5 } else { 1.0 }) * pa));
            y += row_h;

            // zoznam zariadení
            if list_len == 0 {
                let msg = if !self.audio.error.is_empty() {
                    self.audio.error.clone()
                } else if !self.audio_loaded {
                    "Načítavam…".to_string()
                } else {
                    "Žiadne zariadenie".to_string()
                };
                let msg = Self::ellipsize(text, &msg, px, w_in - 2.0 * inset);
                text.layout_to(&mut frame.content, &msg, px, x0 + inset, base(y + row_h * 0.5), fade(t.fg, 0.6 * pa));
            } else {
                for k in 0..shown.min(list_len) {
                    let cell = Rect::new(x0, y + k as f32 * row_h, w_in, row_h);
                    self.hits.push((cell, Hit::AudioDev(src, k)));
                    let hov = self.hover == Some(Hit::AudioDev(src, k));
                    let d = if src { &self.audio.sources[k] } else { &self.audio.sinks[k] };
                    let is_def = Some(k) == di;
                    let fg = if hov {
                        frame.content.push(Item::Rect { r: cell, radius: 10.0 * s, soft: 0.8, color: fade(t.menu_selected, pa) });
                        t.menu_selected_text
                    } else {
                        t.fg
                    };
                    let ccy = cell.y + row_h * 0.5;
                    let mut right = cell.x + cell.w - inset;
                    if is_def {
                        let cw = text.measure("\u{f012c}", px);
                        right -= cw;
                        text.layout_to(&mut frame.content, "\u{f012c}", px, right, base(ccy), fade(fg, pa));
                        right -= 6.0 * s;
                    }
                    let name = Self::ellipsize(text, &d.desc, px, right - cell.x - inset);
                    text.layout_to(&mut frame.content, &name, px, cell.x + inset, base(ccy), fade(fg, pa));
                }
            }
            y += shown as f32 * row_h + AUDIO_GAP * s;
        }
    }

    /// Jedno segmentové tlačidlo panela capture (vyplnená „pilulka“ s popisom).
    #[allow(clippy::too_many_arguments)]
    fn cap_seg(&mut self, frame: &mut Frame, text: &mut Text, r: Rect, label: &str, selected: bool, hit: Hit, enabled: bool, px: f32, pa: f32) {
        let s = self.scale;
        let t = self.theme;
        let (a3, d3) = text.line_metrics(px);
        let dim = if enabled { 1.0 } else { 0.45 };
        if enabled {
            self.hits.push((r, hit));
        }
        let hov = enabled && self.hover == Some(hit);
        let bg = if selected {
            fade(t.accent, (if enabled { 0.35 } else { 0.2 }) * pa)
        } else if hov {
            fade(t.menu_selected, pa)
        } else {
            fade(t.fg, 0.12 * dim * pa)
        };
        frame.content.push(Item::Rect { r, radius: r.h * 0.5, soft: 0.8, color: bg });
        let fg = if selected && enabled {
            t.on_accent
        } else if hov {
            t.menu_selected_text
        } else {
            fade(t.fg, dim)
        };
        let lab = Self::ellipsize(text, label, px, r.w - 10.0 * s);
        let lw = text.measure(&lab, px);
        text.layout_to(&mut frame.content, &lab, px, r.x + (r.w - lw) * 0.5, r.y + r.h * 0.5 + (a3 - d3) * 0.5, fade(fg, pa));
    }

    /// Panel snímania: oblasť (obrazovka / okno / región), typ (obrázok / video), časovač, kurzor / zvuk a hlavné tlačidlo.
    /// Výška musí sedieť s `capture::panel_height`.
    fn build_capture(&mut self, frame: &mut Frame, text: &mut Text, pill: Rect, pa: f32) {
        use crate::capture::{Kind, Mode};
        let s = self.scale;
        let t = self.theme;
        let c = self.cfg.capture.clone();
        let f = c.font_size;
        let px = f * s;
        let px_small = px * 0.8;
        let (asc, desc) = text.line_metrics(px);
        let (a3, d3) = text.line_metrics(px_small);
        let base = |cy: f32| cy + (asc - desc) * 0.5;
        let pad = 14.0 * s;
        let row_h = (f + 20.0) * s;
        let label_h = 22.0 * s;
        let gap = 12.0 * s;
        let inset = 12.0 * s;
        let x0 = pill.x + pad;
        let w_in = pill.w - 2.0 * pad;
        let mut y = pill.y + pad;
        let idle = true;

        // popisok sekcie
        let section = |frame: &mut Frame, text: &mut Text, y: f32, label: &str| {
            text.layout_to(&mut frame.content, label, px_small, x0 + inset, y + label_h * 0.5 + (a3 - d3) * 0.5, fade(t.fg, 0.6 * pa));
        };
        // rad segmentových tlačidiel: (popis, vybrané, hit)
        let btn_gap = 8.0 * s;
        let bh = (row_h * 0.85).min(32.0 * s);

        // --- oblasť
        section(frame, text, y, "Oblasť");
        y += label_h;
        {
            let n = Mode::ALL.len() as f32;
            let bw = ((w_in - 2.0 * inset - (n - 1.0) * btn_gap) / n).max(40.0 * s);
            for (i, m) in Mode::ALL.iter().enumerate() {
                let r = Rect::new(x0 + inset + i as f32 * (bw + btn_gap), y + (row_h - bh) * 0.5, bw, bh);
                self.cap_seg(frame, text, r, m.label(), self.cap_mode == *m, Hit::CapMode(i), idle, px_small, pa);
            }
        }
        y += row_h + gap;

        // --- typ
        section(frame, text, y, "Typ");
        y += label_h;
        {
            let n = Kind::ALL.len() as f32;
            let bw = ((w_in - 2.0 * inset - (n - 1.0) * btn_gap) / n).max(40.0 * s);
            for (i, k) in Kind::ALL.iter().enumerate() {
                let r = Rect::new(x0 + inset + i as f32 * (bw + btn_gap), y + (row_h - bh) * 0.5, bw, bh);
                self.cap_seg(frame, text, r, k.label(), self.cap_kind == *k, Hit::CapKind(i), idle, px_small, pa);
            }
        }
        y += row_h + gap;

        // --- časovač
        section(frame, text, y, "Časovač");
        y += label_h;
        {
            let n = c.delays.len().max(1) as f32;
            let bw = ((w_in - 2.0 * inset - (n - 1.0) * btn_gap) / n).max(30.0 * s);
            for (i, d) in c.delays.iter().enumerate() {
                let r = Rect::new(x0 + inset + i as f32 * (bw + btn_gap), y + (row_h - bh) * 0.5, bw, bh);
                let lab = if *d == 0 { "Hneď".to_string() } else { format!("{d} s") };
                self.cap_seg(frame, text, r, &lab, self.cap_delay == i, Hit::CapDelay(i), idle, px_small, pa);
            }
        }
        y += row_h + gap;

        // --- prepínač: kurzor myši (obrázok) / zvuk (video)
        {
            let cy = y + row_h * 0.5;
            let (label, on) = if self.cap_kind == Kind::Image { ("Zobraziť kurzor myši", self.cap_cursor) } else { ("Nahrávať zvuk", self.cap_audio) };
            let dim = if idle { 1.0 } else { 0.45 };
            text.layout_to(&mut frame.content, label, px, x0 + inset, base(cy), fade(t.fg, dim * pa));
            let tw = 44.0 * s;
            let th = 24.0 * s;
            let tog = Rect::new(x0 + w_in - tw, cy - th * 0.5, tw, th);
            if idle {
                self.hits.push((Rect::new(x0, y, w_in, row_h), Hit::CapToggle));
            }
            let track = if on { t.accent } else { t.fg };
            frame.content.push(Item::Rect { r: tog, radius: th * 0.5, soft: 0.8, color: fade(track, (if on { 1.0 } else { 0.3 }) * dim * pa) });
            let kn = th - 6.0 * s;
            let kx = if on { tog.x + tog.w - 3.0 * s - kn } else { tog.x + 3.0 * s };
            frame.content.push(Item::Rect { r: Rect::new(kx, tog.y + 3.0 * s, kn, kn), radius: kn * 0.5, soft: 0.8, color: fade(if on { t.on_accent } else { t.fg }, dim * pa) });
        }
        y += row_h + gap;

        // --- hlavné tlačidlo
        {
            let video = self.cap_kind == Kind::Video;
            let h = row_h + 4.0 * s;
            let r = Rect::new(x0, y, w_in, h);
            self.hits.push((r, Hit::CapGo));
            let hov = self.hover == Some(Hit::CapGo);
            let (label, bg, fg, dot) = (if video { "Nahrávať".to_string() } else { "Odfotiť".to_string() }, t.accent, t.on_accent, video);
            frame.content.push(Item::Rect { r, radius: h * 0.5, soft: 0.8, color: fade(bg, (if hov { 0.85 } else { 1.0 }) * pa) });
            let lw = text.measure(&label, px);
            let dot_d = 10.0 * s;
            let total = lw + if dot { dot_d + 8.0 * s } else { 0.0 };
            let mut lx = r.x + (r.w - total) * 0.5;
            if dot {
                // kotúčik: červený pri nahrávaní z pokoja, inak v farbe textu
                let col = t.alert;
                frame.content.push(Item::Rect { r: Rect::new(lx, r.y + (r.h - dot_d) * 0.5, dot_d, dot_d), radius: dot_d * 0.5, soft: 0.8, color: fade(col, pa) });
                lx += dot_d + 8.0 * s;
            }
            text.layout_to(&mut frame.content, &label, px, lx, base(r.y + r.h * 0.5), fade(fg, pa));
        }
    }

    fn build_monitor(&mut self, frame: &mut Frame, text: &mut Text, pill: Rect, pa: f32) {
        let s = self.scale;
        let t = self.theme;
        let c = &self.cfg.monitor;
        let f = c.font_size;
        let px = f * s;
        let px_small = px * 0.8;
        let (asc, desc) = text.line_metrics(px);
        let (a3, d3) = text.line_metrics(px_small);
        let base = |cy: f32| cy + (asc - desc) * 0.5;
        let pad = 14.0 * s;
        let row_h = (f + 20.0) * s;
        let label_h = 22.0 * s;
        let gap = 12.0 * s;
        let inset = 12.0 * s;
        let x0 = pill.x + pad;
        let w_in = pill.w - 2.0 * pad;
        let mut y = pill.y + pad;

        if !self.monitor.error.is_empty() {
            let msg = Self::ellipsize(text, &self.monitor.error, px, w_in);
            text.layout_to(
                &mut frame.content,
                &msg,
                px,
                x0 + inset,
                base(y + row_h * 0.5),
                fade(t.alert, pa),
            );
            return;
        }

        if !self.monitor_loaded {
            text.layout_to(
                &mut frame.content,
                "Načítavam…",
                px,
                x0 + inset,
                base(y + row_h * 0.5),
                fade(t.fg, 0.6 * pa),
            );
            return;
        }

        // --- helper: sekcia s popiskom
        let mut section_label = |out: &mut Vec<Item>, text: &mut Text, y: &mut f32, label: &str| {
            text.layout_to(
                out,
                label,
                px_small,
                x0 + inset,
                *y + label_h * 0.5 + (a3 - d3) * 0.5,
                fade(t.fg, 0.6 * pa),
            );
            *y += label_h;
        };

        // --- jas
        section_label(&mut frame.content, text, &mut y, "Jas");
        {
            let cy = y + row_h * 0.5;
            let pct = self.monitor.brightness;
            let pct_w = text.measure("100%", px);
            let track_x = x0 + inset;
            let track = Rect::new(
                track_x,
                cy - 3.0 * s,
                (w_in - 2.0 * inset - pct_w - 10.0 * s).max(20.0 * s),
                6.0 * s,
            );
            self.monitor_rects[0] = track;
            self.hits.push((
                Rect::new(track.x - 4.0 * s, y, track.w + 8.0 * s, row_h),
                Hit::MonSlider(false),
            ));
            let fill_w = track.w * (pct as f32 / 100.0);
            frame.content.push(Item::Rect {
                r: track,
                radius: 3.0 * s,
                soft: 0.8,
                color: fade(t.fg, 0.18 * pa),
            });
            if fill_w > 0.5 {
                frame.content.push(Item::Rect {
                    r: Rect::new(track.x, track.y, fill_w, track.h),
                    radius: 3.0 * s,
                    soft: 0.8,
                    color: fade(t.accent, pa),
                });
            }
            // gulička
            let kx = track.x + fill_w - 5.0 * s;
            frame.content.push(Item::Rect {
                r: Rect::new(kx.max(track.x), cy - 7.0 * s, 10.0 * s, 14.0 * s),
                radius: 5.0 * s,
                soft: 0.8,
                color: fade(t.fg, pa),
            });
            let ptxt = format!("{pct}%");
            let pw = text.measure(&ptxt, px);
            text.layout_to(
                &mut frame.content,
                &ptxt,
                px,
                x0 + w_in - pw,
                base(cy),
                fade(t.fg, pa),
            );
            y += row_h;
        }

        y += gap;

        // --- kontrast
        section_label(&mut frame.content, text, &mut y, "Kontrast");
        {
            let cy = y + row_h * 0.5;
            let pct = self.monitor.contrast;
            let pct_w = text.measure("100%", px);
            let track_x = x0 + inset;
            let track = Rect::new(
                track_x,
                cy - 3.0 * s,
                (w_in - 2.0 * inset - pct_w - 10.0 * s).max(20.0 * s),
                6.0 * s,
            );
            self.monitor_rects[1] = track;
            self.hits.push((
                Rect::new(track.x - 4.0 * s, y, track.w + 8.0 * s, row_h),
                Hit::MonSlider(true),
            ));
            let fill_w = track.w * (pct as f32 / 100.0);
            frame.content.push(Item::Rect {
                r: track,
                radius: 3.0 * s,
                soft: 0.8,
                color: fade(t.fg, 0.18 * pa),
            });
            if fill_w > 0.5 {
                frame.content.push(Item::Rect {
                    r: Rect::new(track.x, track.y, fill_w, track.h),
                    radius: 3.0 * s,
                    soft: 0.8,
                    color: fade(t.accent, pa),
                });
            }
            let kx = track.x + fill_w - 5.0 * s;
            frame.content.push(Item::Rect {
                r: Rect::new(kx.max(track.x), cy - 7.0 * s, 10.0 * s, 14.0 * s),
                radius: 5.0 * s,
                soft: 0.8,
                color: fade(t.fg, pa),
            });
            let ptxt = format!("{pct}%");
            let pw = text.measure(&ptxt, px);
            text.layout_to(
                &mut frame.content,
                &ptxt,
                px,
                x0 + w_in - pw,
                base(cy),
                fade(t.fg, pa),
            );
            y += row_h;
        }

        y += gap;

        // --- teplota farieb
        section_label(&mut frame.content, text, &mut y, "Teplota farieb");
        {
            let n = c.preset_labels.len().max(1) as f32;
            let btn_gap = 8.0 * s;
            let btn_w = ((w_in - 2.0 * inset - (n - 1.0) * btn_gap) / n).max(40.0 * s);
            let bh = (row_h * 0.85).min(32.0 * s);
            let by = y + (row_h - bh) * 0.5;
            for (i, label) in c.preset_labels.iter().enumerate() {
                let bx = x0 + inset + i as f32 * (btn_w + btn_gap);
                let r = Rect::new(bx, by, btn_w, bh);
                self.hits.push((r, Hit::MonPreset(i)));
                let selected = self.monitor.preset == Some(i);
                let hov = self.hover == Some(Hit::MonPreset(i));
                let bg = if selected {
                    fade(t.accent, 0.35 * pa)
                } else if hov {
                    fade(t.menu_selected, pa)
                } else {
                    fade(t.fg, 0.12 * pa)
                };
                frame.content.push(Item::Rect {
                    r,
                    radius: bh * 0.5,
                    soft: 0.8,
                    color: bg,
                });
                let fg = if selected {
                    t.on_accent
                } else if hov {
                    t.menu_selected_text
                } else {
                    t.fg
                };
                let lab = Self::ellipsize(text, label, px_small, btn_w - 10.0 * s);
                let lw = text.measure(&lab, px_small);
                text.layout_to(
                    &mut frame.content,
                    &lab,
                    px_small,
                    r.x + (r.w - lw) * 0.5,
                    by + bh * 0.5 + (a3 - d3) * 0.5,
                    fade(fg, pa),
                );
            }
            y += row_h;
        }

        y += gap;

        // --- vstup
        section_label(&mut frame.content, text, &mut y, "Vstup");
        {
            let n = c.input_labels.len().max(1) as f32;
            let btn_gap = 8.0 * s;
            let btn_w = ((w_in - 2.0 * inset - (n - 1.0) * btn_gap) / n).max(40.0 * s);
            let bh = (row_h * 0.85).min(32.0 * s);
            let by = y + (row_h - bh) * 0.5;
            for (i, label) in c.input_labels.iter().enumerate() {
                let bx = x0 + inset + i as f32 * (btn_w + btn_gap);
                let r = Rect::new(bx, by, btn_w, bh);
                self.hits.push((r, Hit::MonInput(i)));
                let selected = self.monitor.input == Some(i);
                let hov = self.hover == Some(Hit::MonInput(i));
                let bg = if selected {
                    fade(t.accent, 0.35 * pa)
                } else if hov {
                    fade(t.menu_selected, pa)
                } else {
                    fade(t.fg, 0.12 * pa)
                };
                frame.content.push(Item::Rect {
                    r,
                    radius: bh * 0.5,
                    soft: 0.8,
                    color: bg,
                });
                let fg = if selected {
                    t.on_accent
                } else if hov {
                    t.menu_selected_text
                } else {
                    t.fg
                };
                let lab = Self::ellipsize(text, label, px_small, btn_w - 10.0 * s);
                let lw = text.measure(&lab, px_small);
                text.layout_to(
                    &mut frame.content,
                    &lab,
                    px_small,
                    r.x + (r.w - lw) * 0.5,
                    by + bh * 0.5 + (a3 - d3) * 0.5,
                    fade(fg, pa),
                );
            }
            y += row_h;
        }

        y += gap;

        // --- nočný režim (len ak je nastavený `night_switcher`)
        if !self.cfg.monitor.night_switcher.is_empty() {
            let cy = y + row_h * 0.5;
            let label = self.cfg.monitor.night_label.clone();
            let label = label.as_str();
            text.layout_to(
                &mut frame.content,
                label,
                px,
                x0 + inset,
                base(cy),
                fade(t.fg, pa),
            );
            // switch vpravo
            let tw = 44.0 * s;
            let th = 24.0 * s;
            let tx = x0 + w_in - tw;
            let ty = cy - th * 0.5;
            let tog = Rect::new(tx, ty, tw, th);
            self.hits.push((tog, Hit::MonNight));
            let on = self.monitor.night;
            let track = if on { t.accent } else { t.fg };
            frame.content.push(Item::Rect {
                r: tog,
                radius: th * 0.5,
                soft: 0.8,
                color: fade(track, (if on { 1.0 } else { 0.3 }) * pa),
            });
            let kn = th - 6.0 * s;
            let kx = if on {
                tog.x + tog.w - 3.0 * s - kn
            } else {
                tog.x + 3.0 * s
            };
            frame.content.push(Item::Rect {
                r: Rect::new(kx, tog.y + 3.0 * s, kn, kn),
                radius: kn * 0.5,
                soft: 0.8,
                color: fade(if on { t.on_accent } else { t.fg }, pa),
            });
        }
    }

    fn build_wall(&mut self, frame: &mut Frame, text: &mut Text, pill: Rect, pa: f32) {
        let s = self.scale;
        let t = self.theme;
        let (tw, th) = self.cfg.wall.thumb_size();
        let (tw, th, gap, pad) = (tw * s, th * s, WALL_GAP * s, WALL_PAD * s);
        let cols = self.cfg.wall.columns;
        let n = self.wall.len();
        let px = self.px_font();
        let (asc, desc) = text.line_metrics(px);
        let base = |cy: f32| cy + (asc - desc) * 0.5;
        let inset = 12.0 * s;
        let x0 = pill.x + pad;
        let w_in = pill.w - 2.0 * pad;

        // ---- hlavička: tlačidlá + rollout s témou
        let head = WALL_HEAD * s;
        let hcy = pill.y + pad + head * 0.5;
        let bh = (px * 1.9).min(head);
        let rows = self.wall_rows_shown();
        let (rx, rw, bxs) = crate::wallpaper::header_layout(x0, w_in, self.cfg.wall.theme_width * s, self.cfg.wall.buttons.len(), self.cfg.wall.button_max_width.map(|w| w * s), gap);
        for (i, (bx, bw)) in bxs.iter().enumerate() {
            let r = Rect::new(*bx, hcy - bh * 0.5, *bw, bh);
            self.hits.push((r, Hit::WallButton(i)));
            let hov = self.hover == Some(Hit::WallButton(i));
            frame.content.push(Item::Rect { r, radius: bh * 0.5, soft: 0.8, color: if hov { fade(t.menu_selected, pa) } else { fade(t.fg, 0.12 * pa) } });
            let label = Self::ellipsize(text, &self.cfg.wall.buttons[i].label, px, bw - 2.0 * inset);
            let lw = text.measure(&label, px);
            text.layout_to(&mut frame.content, &label, px, r.x + (r.w - lw) * 0.5, base(hcy), fade(if hov { t.menu_selected_text } else { t.fg }, pa));
        }
        let rr = Rect::new(rx, hcy - bh * 0.5, rw, bh);
        self.hits.push((rr, Hit::WallRollout));
        let rhov = self.hover == Some(Hit::WallRollout);
        let rbg = if rhov || self.wall_menu { fade(t.accent, 0.25 * pa) } else { fade(t.fg, 0.12 * pa) };
        frame.content.push(Item::Rect { r: rr, radius: bh * 0.5, soft: 0.8, color: rbg });
        let chev = if self.wall_menu { "\u{f0143}" } else { "\u{f0140}" };
        let cw = text.measure(chev, px);
        text.layout_to(&mut frame.content, chev, px, rr.x + rr.w - inset - cw, base(hcy), fade(t.fg, pa));
        let cur = if self.wall_theme.is_empty() { "wallpaper" } else { self.wall_theme.as_str() };
        let cur = Self::ellipsize(text, cur, px, rw - 3.0 * inset - cw);
        text.layout_to(&mut frame.content, &cur, px, rr.x + inset, base(hcy), fade(t.fg, pa));

        // ---- oblasť pod hlavičkou: zoznam tém (rozbalený rollout) alebo mriežka náhľadov
        let top = pill.y + pad + head + gap;
        let area_h = rows as f32 * th + (rows - 1) as f32 * gap;

        if self.wall_menu {
            let row_h = px * 1.9;
            let vis = ((area_h / row_h).floor() as usize).max(1);
            let total = self.wall_themes.len() + 1; // + pseudotéma „wallpaper“
            let start = self.wall_menu_scroll.min(total.saturating_sub(vis));
            let sb = if total > vis { WALL_SCROLLBAR * s } else { 0.0 };
            for k in 0..vis.min(total) {
                let i = start + k;
                let name = if i == 0 { "wallpaper" } else { self.wall_themes[i - 1].0.as_str() };
                let sel = if i == 0 { self.wall_theme.is_empty() } else { self.wall_theme == name };
                let cell = Rect::new(x0, top + k as f32 * row_h, w_in - sb, row_h);
                self.hits.push((cell, Hit::WallTheme(i)));
                let hov = self.hover == Some(Hit::WallTheme(i));
                let fg = if hov {
                    frame.content.push(Item::Rect { r: cell, radius: 10.0 * s, soft: 0.8, color: fade(t.menu_selected, pa) });
                    t.menu_selected_text
                } else if sel {
                    frame.content.push(Item::Rect { r: cell, radius: 10.0 * s, soft: 0.8, color: fade(t.accent, 0.18 * pa) });
                    t.accent
                } else {
                    t.fg
                };
                let mark = if sel { "\u{f012c}" } else { "" };
                let mw = if sel { text.measure(mark, px) } else { 0.0 };
                if sel {
                    text.layout_to(&mut frame.content, mark, px, cell.x + cell.w - inset - mw, base(cell.y + row_h * 0.5), fade(fg, pa));
                }
                let label = Self::ellipsize(text, name, px, cell.w - 3.0 * inset - mw);
                text.layout_to(&mut frame.content, &label, px, cell.x + inset, base(cell.y + row_h * 0.5), fade(fg, pa));
            }
            if total > vis {
                let track_h = vis as f32 * row_h;
                let thumb_h = (track_h * vis as f32 / total as f32).max(16.0 * s).min(track_h);
                let frac = start as f32 / (total - vis) as f32;
                let w = 4.0 * s;
                let x = x0 + w_in - sb + (sb - w) * 0.5;
                frame.content.push(Item::Rect { r: Rect::new(x, top + (track_h - thumb_h) * frac, w, thumb_h), radius: w * 0.5, soft: 0.8, color: fade(t.fg, 0.35 * pa) });
            }
            return;
        }

        if n == 0 {
            let msg = if self.wall_loaded { "Žiadne obrázky" } else { "Načítavam…" };
            let mw = text.measure(msg, px);
            let cy = top + area_h * 0.5;
            text.layout_to(&mut frame.content, msg, px, pill.x + (pill.w - mw) * 0.5, base(cy), fade(t.fg, 0.7 * pa));
            return;
        }

        let total_rows = self.wall_row_count();
        let scrollable = total_rows > rows;
        let start = self.wall_scroll.min(total_rows - rows);

        for r in 0..rows {
            for c in 0..cols {
                let i = (start + r) * cols + c;
                if i >= n {
                    break;
                }
                let cell = Rect::new(x0 + c as f32 * (tw + gap), top + r as f32 * (th + gap), tw, th);
                self.hits.push((cell, Hit::WallItem(i)));
                let e = &self.wall[i];
                let hov = self.hover == Some(Hit::WallItem(i)) && self.cfg.wall.hover_ring;
                let current = self.cfg.wall.current_ring && !self.wall_current.is_empty() && e.path == self.wall_current;
                // rámik okolo náhľadu: zvýraznenie pod kurzorom / aktuálne pozadie
                if hov || current {
                    let ring = if hov { t.menu_selected } else { t.accent };
                    let g = 3.0 * s;
                    let outer = Rect::new(cell.x - g, cell.y - g, cell.w + 2.0 * g, cell.h + 2.0 * g);
                    frame.content.push(Item::Rect { r: outer, radius: (crate::wallpaper::THUMB_RADIUS + g / s) * s, soft: 0.8, color: fade(ring, (if hov { 1.0 } else { 0.8 }) * pa) });
                }
                if e.ready {
                    frame.content.push(Item::Image { r: cell, path: e.thumb.clone(), color: [1.0, 1.0, 1.0, pa], radius: 0.0 });
                } else {
                    frame.content.push(Item::Rect { r: cell, radius: crate::wallpaper::THUMB_RADIUS * s, soft: 0.8, color: fade(t.fg, 0.12 * pa) });
                }
            }
        }

        if scrollable {
            let track_h = rows as f32 * th + (rows - 1) as f32 * gap;
            let thumb_h = (track_h * rows as f32 / total_rows as f32).max(16.0 * s).min(track_h);
            let frac = start as f32 / (total_rows - rows) as f32;
            let w = 4.0 * s;
            let x = pill.x + pill.w - pad - (WALL_SCROLLBAR * s - w) * 0.5 - w;
            let y = top + (track_h - thumb_h) * frac;
            frame.content.push(Item::Rect { r: Rect::new(x, y, w, thumb_h), radius: w * 0.5, soft: 0.8, color: fade(t.fg, 0.35 * pa) });
        }
    }
}

impl Text {
    /// Rozloží reťazec priamo do zoznamu položiek.
    pub fn layout_to(&mut self, out: &mut Vec<Item>, s: &str, px: f32, x: f32, baseline: f32, color: Color) {
        let mut q: Vec<GlyphQuad> = Vec::with_capacity(s.len());
        self.layout(s, px, x, baseline, color, &mut q);
        out.extend(q.into_iter().map(Item::Glyph));
    }
}

#[cfg(test)]
mod tests {
    use super::*;
}
