//! dynamic-launcher – efektná náhrada rofi pre Wayland (wlroots): spúšťač aplikácií, schránka, kôš,
//! wallpaper, snímanie obrazovky, Wi-Fi, Bluetooth, monitor, audio, vlastné menu a kontajner quickset.
//! Rust + EGL/OpenGL ES 2.0, bez UI frameworku. Každé okno je samostatný proces v strede obrazovky.
mod anim;
mod app;
mod audio;
mod bluetooth;
mod capture;
mod clip;
mod config;
mod data;
mod dbus;
mod desktop;
mod drun;
mod fonts;
mod gl;
mod grid;
mod icons;
mod json;
mod monitor;
mod nicons;
mod quickset;
mod render;
mod sys;
mod sysinfo;
mod text;
mod toml;
mod trash;
mod ui;
mod wallpaper;
mod wifi;
mod wl;
mod xkb;

use std::path::PathBuf;

const HELP: &str = "dynamic-launcher [--config CESTA] [--check] [--action NAZOV] [--drun] [--drun-list] [--clip]

  --config CESTA      konfigurácia (predvolene ~/.config/dynamic-launcher/config.toml)
  --check             skontroluje konfiguráciu a skončí
  --action NAZOV      otvorí okno v strede obrazovky; NAZOV je jeden z:
                        drun, clipboard, capture, trash, wallpaper, wifi, bluetooth, monitor, audio,
                        quickset, quickset:TAB (audio, bluetooth, wifi, monitor, ...), alebo názov vlastného [[menu]]
                      Každé spustenie zatvorí už otvorené okno (aj iné), takže jedna skratka otvára aj zatvára.
  --drun              to isté ako --action drun (spúšťač aplikácií)
  --clip              to isté ako --action clipboard (história schránky)
  --drun-list         vypíše všetky nájdené .desktop súbory a prečo sa niektoré nezobrazia";

/// Okná, ktoré spravuje `--action` (okrem vlastných menu): názov → je to samostatné okno (drun / clip) alebo panel.
const ACTIONS: &[&str] = &["drun", "clipboard", "capture", "trash", "wallpaper", "wifi", "bluetooth", "monitor", "audio", "quickset"];

fn main() {
    let args: Vec<String> = std::env::args().skip(1).collect();
    let mut path: Option<PathBuf> = None;
    let mut check = false;
    let mut drun_list = false;
    let mut action: Option<String> = None;
    let mut capture_job: Option<Vec<String>> = None;
    let mut i = 0;
    while i < args.len() {
        match args[i].as_str() {
            "--config" => {
                i += 1;
                path = args.get(i).map(PathBuf::from);
            }
            "--check" => check = true,
            "--drun" => action = Some("drun".into()),
            "--clip" => action = Some("clipboard".into()),
            "--drun-list" => drun_list = true,
            "--action" => {
                i += 1;
                action = args.get(i).map(|s| s.trim().to_string()).filter(|s| !s.is_empty());
                if action.is_none() {
                    eprintln!("použitie: dynamic-launcher --action NAZOV\n\n{HELP}");
                    std::process::exit(2);
                }
            }
            // vnútorné: samostatný proces, ktorý vykoná snímanie / nahrávanie (prežije zatvorenie okna)
            "--capture-job" => {
                capture_job = Some(args[i + 1..].to_vec());
                break;
            }
            "-h" | "--help" => {
                println!("{HELP}");
                return;
            }
            other => {
                eprintln!("neznámy argument: {other}\n\n{HELP}");
                std::process::exit(2);
            }
        }
        i += 1;
    }
    let cfg = match config::Config::load(path) {
        Ok(c) => c,
        Err(e) => {
            eprintln!("chyba konfigurácie: {e}");
            std::process::exit(1);
        }
    };
    if check {
        println!("konfigurácia v poriadku ({} menu)", cfg.menus.len());
        return;
    }
    if drun_list {
        desktop::print_list(&cfg.drun.desktop);
        return;
    }
    if let Some(a) = capture_job {
        std::process::exit(capture::job_main(cfg, &a));
    }
    let Some(name) = action else {
        eprintln!("{HELP}");
        std::process::exit(2);
    };
    let base = name.split(':').next().unwrap_or(&name);
    if !ACTIONS.contains(&base) && !cfg.menus.iter().any(|m| m.name == name) {
        let menus: Vec<&str> = cfg.menus.iter().map(|m| m.name.as_str()).collect();
        eprintln!("neznámy názov '{name}'. Možnosti: {}{}{}", ACTIONS.join(", "), if menus.is_empty() { "" } else { ", menu: " }, menus.join(", "));
        std::process::exit(2);
    }
    // druhé spustenie (aj inej skratky) už otvorené okno zatvorí
    if drun::close_any_window() {
        return;
    }
    // počas nahrávania `capture` namiesto panela nahrávanie zastaví
    if name == "capture" && capture::stop_running() {
        return;
    }
    let res = match name.as_str() {
        "drun" => drun::run(cfg),
        "clipboard" => clip::run(cfg),
        _ => app::run_panel(cfg, name),
    };
    if let Err(e) = res {
        eprintln!("dynamic-launcher: {e}");
        std::process::exit(1);
    }
}
