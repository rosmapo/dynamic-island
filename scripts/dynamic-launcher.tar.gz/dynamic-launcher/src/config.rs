//! Konfigurácia (TOML podmnožina) a farebná téma (vrátane matugen CSS súboru).
use crate::toml::{self, Table, TableExt, Value};
use std::collections::HashMap;
use std::path::PathBuf;

pub type Color = [f32; 4];

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum MenuKind {
    Icons,
    Text,
    /// Typ podľa položky: `icon` → ikona, `label` → text, `separator` → čiara.
    Hybrid,
}

/// Poloha čiary oddeľovača v jeho riadku (`separator = "top" | "center" | "bottom"`).
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub enum SepAlign {
    Top,
    #[default]
    Center,
    Bottom,
}

#[derive(Clone, Debug, Default)]
pub struct MenuItemCfg {
    pub icon: String,
    pub label: String,
    pub command: String,
    /// Príkaz (alebo skript), ktorého prvý riadok výstupu sa zobrazí v položke (pozri `data::menu_item_text`).
    pub exec: String,
    /// Obnovovanie `exec` počas otvoreného menu v sekundách; 0 = spustí sa len raz pri otvorení menu.
    pub interval: f64,
    /// Vlastný riadok s oddelovačom; `icon`/`label`/`command` sa ignorujú.
    pub separator: bool,
    /// Poloha čiary oddeľovača v riadku (len pri `separator`).
    pub sep_align: SepAlign,
    /// Riadok textu cez celú šírku menu (`line = "text {}"`): text je v `label`, `exec`/`interval` fungujú ako pri
    /// bežnej textovej položke; prázdny text = prázdny riadok. `command` je voliteľný (klik na celý riadok).
    pub line: bool,
}

/// Vlastné menu (`[[menu]]`). Otvára sa cez `dynamic-launcher --action NAZOV`.
#[derive(Clone, Debug)]
pub struct MenuCfg {
    pub name: String,
    pub kind: MenuKind,
    pub title: String,
    /// Spoločný fallback pre `icon_columns` / `text_columns` (staré configy).
    pub columns: usize,
    /// Počet stĺpcov pre ikony (hybrid / icons).
    pub icon_columns: usize,
    /// Počet stĺpcov pre textové položky (hybrid / text).
    pub text_columns: usize,
    pub rows: Option<usize>,
    pub icon_size: f32,
    pub text_size: f32,
    pub cell_width: f32,
    pub gap: f32,
    pub padding: f32,
    /// Hrúbka čiary separátora (logické px).
    pub separator_thickness: f32,
    /// Dĺžka separátora ako podiel šírky obsahu (0.0–1.0).
    pub separator_length: f32,
    /// Menu sa zobrazí až po načítaní všetkých položiek s `exec` (alebo po `wait_ms`); inak hneď s prázdnymi hodnotami.
    pub wait_exec: bool,
    /// Najdlhšie čakanie pri `wait_exec` (ms); potom sa menu zobrazí aj bez dokončených výstupov.
    pub wait_ms: u64,
    pub items: Vec<MenuItemCfg>,
}

/// Spúšťač aplikácií (`dynamic-launcher --drun`).
#[derive(Clone, Debug, PartialEq)]
pub struct DrunCfg {
    pub columns: usize,
    pub rows: usize,
    /// "icon" | "name" | "icon+name-right" | "icon+name-below"
    pub show: String,
    pub icon_size: f32,
    pub name_size: f32,
    /// šírka / výška jednej bunky (0 = podľa režimu a veľkostí)
    pub cell_w: f32,
    pub cell_h: f32,
    pub padding: f32,
    pub radius: f32,
    pub cell_radius: f32,
    /// zoraďovanie (`order = "vertical"`): ďalšia položka je pod predošlou (po stĺpcoch), inak vedľa nej (po riadkoch)
    pub vertical: bool,
    /// krytie pozadia samostatného spúšťača; záporné = ako `[launcher] opacity`
    pub opacity: f32,
    /// zvýraznenie bunky pod ukazovateľom
    pub hover: bool,
    /// riadok hľadania vždy viditeľný (písaním sa filtruje aj bez neho)
    pub search: bool,
    pub terminal: String,
    pub icon_theme: String,
    /// názov prostredia pre OnlyShowIn / NotShowIn (prázdne = nekontrolovať)
    pub desktop: String,
}

impl DrunCfg {
    pub fn from_table(d: &Table) -> DrunCfg {
        let show = d.str_or("show", "icon");
        let show = match show.as_str() {
            "icon" | "name" | "icon+name-right" | "icon+name-below" => show,
            _ => "icon".to_string(),
        };
        DrunCfg {
            columns: d.f64_or("columns", 5.0).clamp(1.0, 20.0) as usize,
            rows: d.f64_or("rows", 4.0).clamp(1.0, 20.0) as usize,
            show,
            icon_size: d.f64_or("icon_size", 64.0).clamp(16.0, 256.0) as f32,
            name_size: d.f64_or("name_size", 14.0).clamp(8.0, 48.0) as f32,
            cell_w: d.f64_or("cell_width", 0.0).clamp(0.0, 600.0) as f32,
            cell_h: d.f64_or("cell_height", 0.0).clamp(0.0, 600.0) as f32,
            padding: d.f64_or("padding", 15.0).clamp(0.0, 100.0) as f32,
            radius: d.f64_or("radius", 30.0).clamp(0.0, 100.0) as f32,
            cell_radius: d.f64_or("cell_radius", 15.0).clamp(0.0, 100.0) as f32,
            opacity: d.f64_or("opacity", -1.0) as f32,
            vertical: matches!(d.str_or("order", "horizontal").trim().to_lowercase().as_str(), "vertical" | "vertikalne" | "columns"),
            hover: d.bool_or("hover", true),
            search: d.bool_or("search", false),
            terminal: d.str_or("terminal", "foot"),
            icon_theme: d.str_or("icon_theme", ""),
            desktop: d.str_or("desktop", ""),
        }
    }
}

#[derive(Clone, Debug)]
pub struct Config {
    pub path: PathBuf,
    pub font_family: Vec<String>,
    pub icon_family: Vec<String>,
    pub font_size: f32,
    pub radius: f32,
    pub opacity: f32,
    pub shadow: bool,
    pub surface_w: u32,
    pub surface_h: u32,
    /// tlačidlo myši, ktoré zatvorí okno (kód Linuxu, 0 = žiadne) – `[launcher] close_button`
    pub close_button: u32,
    pub colors_file: String,
    pub color_spec: HashMap<String, String>,

    /// `[audio] limit`: najvyššia hlasitosť (1.0 = 100 %)
    pub vol_limit: f64,

    pub menus: Vec<MenuCfg>,
    /// panel histórie schránky (cliphist) – `[clipboard]`
    pub clip_font: f32,
    pub clip_rows: usize,
    pub clip_width: f32,
    pub clip_max: usize,
    pub clip_list: String,
    pub clip_copy: String,
    /// zaoblenie rohov samostatného okna `--action clipboard`
    pub clip_window_radius: f32,
    /// zobraziť pole hľadania v samostatnom okne schránky (filtrovanie písaním funguje aj bez neho)
    pub clip_search: bool,
    /// modul wallpaper – `[wallpaper]`
    pub wall: crate::wallpaper::WallCfg,
    /// modul Wi-Fi – `[wifi]`
    pub wifi: crate::wifi::WifiCfg,
    /// panel audio – kľúče `panel_*` v `[audio]`
    /// krok hlasitosti pri kolieska nad posuvníkom (%) – `[audio] step`
    pub vol_step: u32,
    pub audio_panel: crate::audio::AudioCfg,
    /// panel monitor – `[monitor]`
    pub monitor: crate::monitor::MonitorCfg,
    /// panel capture (snímka / nahrávanie obrazovky) – `[capture]`
    pub capture: crate::capture::CaptureCfg,
    /// panel bluetooth – `[bluetooth]`
    pub bluetooth: crate::bluetooth::BtCfg,
    /// kontajner so záložkami – `[quickset]`
    pub hw: crate::quickset::HwCfg,
    /// kôš (zoznam, obnova, vyprázdnenie) – `[trash]`
    pub trash: crate::trash::TrashCfg,
    /// `[system]`: desatinný oddeľovač a rozhranie pre natívne zdroje `exec = "builtin:…"`
    pub sys_decimal: String,
    pub sys_net_iface: String,
    /// `[drun]`: spúšťač aplikácií
    pub drun: DrunCfg,
}

pub fn expand(p: &str) -> String {
    if let Some(rest) = p.strip_prefix("~/") {
        if let Ok(h) = std::env::var("HOME") {
            return format!("{h}/{rest}");
        }
    }
    p.to_string()
}

pub fn default_path() -> PathBuf {
    let base = std::env::var("XDG_CONFIG_HOME")
        .ok()
        .filter(|s| !s.is_empty())
        .unwrap_or_else(|| format!("{}/.config", std::env::var("HOME").unwrap_or_default()));
    PathBuf::from(base).join("dynamic-launcher/config.toml")
}

/// Zoznam písem: pole `["A", "B"]` alebo reťazec `"A, B"`; poradie = poradie náhrad.
fn font_list(t: &Table, key: &str, default: &[&str]) -> Vec<String> {
    if let Some(v) = t.strs(key) {
        return v;
    }
    if let Some(s) = t.get(key).and_then(|v| v.as_str()) {
        return s.split(',').map(|x| x.trim().to_string()).filter(|x| !x.is_empty()).collect();
    }
    default.iter().map(|s| s.to_string()).collect()
}
impl Config {
    pub fn load(path: Option<PathBuf>) -> Result<Config, String> {
        let path = path.unwrap_or_else(default_path);
        let t = match std::fs::read_to_string(&path) {
            Ok(s) => toml::parse(&s).map_err(|e| format!("{}: {e}", path.display()))?,
            Err(_) => Table::new(), // bez súboru: vstavané predvolené hodnoty
        };
        Ok(Config::from_table(&t, path))
    }

    pub fn from_table(t: &Table, path: PathBuf) -> Config {
        let mut c = Self::from_table_raw(t, path);
        // `[launcher] font_scale`: jednotný násobiteľ všetkých veľkostí písma
        let fs = t.sub("launcher").f64_or("font_scale", 1.0).clamp(0.5, 3.0) as f32;
        if (fs - 1.0).abs() > 1e-3 {
            c.font_size *= fs;
            c.clip_font *= fs;
            c.wifi.font_size *= fs;
            c.monitor.font_size *= fs;
            c.capture.font_size *= fs;
            c.bluetooth.font_size *= fs;
            c.trash.font *= fs;
            c.audio_panel.font_size *= fs;
        }
        c
    }

    fn from_table_raw(t: &Table, path: PathBuf) -> Config {
        let isl = t.sub("launcher");
        // presne to, čo je v konfigurácii (bez skrytých náhradných písem); chýbajúci kľúč = predvolené
        let font_family = font_list(&isl, "font_family", &["Adwaita Sans", "DejaVu Sans"]);
        let icon_family = font_list(&isl, "icon_family", &["Hack Nerd Font Propo"]);

        let mut color_spec = HashMap::new();
        for (k, v) in t.sub("colors") {
            if let Some(s) = v.as_str() {
                color_spec.insert(k, s.to_string());
            }
        }

        let clip = t.sub("clipboard");
        let audio = t.sub("audio");
        let system = t.sub("system");

        let mut menus = Vec::new();
        if let Some(arr) = t.get("menu").and_then(|v| v.as_arr()) {
            for v in arr {
                if let Value::Table(m) = v {
                    let name = m.str_or("name", "");
                    if name.is_empty() {
                        continue;
                    }
                    // Explicitný type, inak sa odvodí z položiek (čisté ikony → Icons, …).
                    let type_str = m.str_or("type", "");
                    let mut items = Vec::new();
                    if let Some(ia) = m.get("item").and_then(|v| v.as_arr()) {
                        for iv in ia {
                            if let Value::Table(it) = iv {
                                // `separator = "top" | "center" | "bottom"` (staré `true` = center; `false` / "" = nie je oddeľovač)
                                let sep_align = match it.get("separator") {
                                    Some(Value::Bool(true)) => Some(SepAlign::Center),
                                    Some(Value::Str(s)) => match s.trim().to_lowercase().as_str() {
                                        "" | "false" | "none" => None,
                                        "top" => Some(SepAlign::Top),
                                        "bottom" => Some(SepAlign::Bottom),
                                        _ => Some(SepAlign::Center),
                                    },
                                    _ => None,
                                };
                                if let Some(sep_align) = sep_align {
                                    items.push(MenuItemCfg {
                                        separator: true,
                                        sep_align,
                                        ..Default::default()
                                    });
                                    continue;
                                }
                                // `line = "text"`: riadok na celú šírku (aj prázdny = vynechaný riadok)
                                if let Some(text) = it.get("line").and_then(|v| v.as_str()) {
                                    items.push(MenuItemCfg {
                                        label: text.to_string(),
                                        command: it.str_or("command", ""),
                                        exec: it.str_or("exec", ""),
                                        interval: it.f64_or("interval", 0.0).max(0.0),
                                        line: true,
                                        ..Default::default()
                                    });
                                    continue;
                                }
                                let icon = it.str_or("icon", "");
                                let label = it.str_or("label", "");
                                let command = it.str_or("command", "");
                                let exec = it.str_or("exec", "");
                                if command.is_empty() && icon.is_empty() && label.is_empty() && exec.is_empty() {
                                    continue;
                                }
                                // Buď icon, alebo label — nie oboje; položka s `exec` je vždy textová (label = šablóna).
                                let (icon, label) = if !icon.is_empty() && exec.is_empty() {
                                    (icon, String::new())
                                } else {
                                    (String::new(), label)
                                };
                                items.push(MenuItemCfg {
                                    icon,
                                    label,
                                    command,
                                    exec,
                                    interval: it.f64_or("interval", 0.0).max(0.0),
                                    separator: false,
                                    sep_align: SepAlign::Center,
                                    line: false,
                                });
                            }
                        }
                    }
                    let kind = match type_str.as_str() {
                        "text" => MenuKind::Text,
                        "icons" => MenuKind::Icons,
                        "hybrid" => MenuKind::Hybrid,
                        _ => {
                            // bez type: odvodiť podľa obsahu
                            let has_sep = items.iter().any(|it| it.separator);
                            let has_icon = items.iter().any(|it| !it.icon.is_empty());
                            let has_label = items.iter().any(|it| !it.label.is_empty() || !it.exec.is_empty());
                            if has_sep || (has_icon && has_label) {
                                MenuKind::Hybrid
                            } else if has_label {
                                MenuKind::Text
                            } else {
                                MenuKind::Icons
                            }
                        }
                    };
                    // `columns` = spoločný fallback (staré configy).
                    // Ak chýba úplne a ide o čistý text, default 1 stĺpec (nie 3).
                    let columns_explicit = m.get("columns").and_then(|v| v.as_f64()).map(|v| v.max(1.0) as usize);
                    let columns = columns_explicit.unwrap_or(3);
                    let icon_columns = m
                        .get("icon_columns")
                        .and_then(|v| v.as_f64())
                        .map(|v| v.max(1.0) as usize)
                        .unwrap_or(columns);
                    let text_columns = m
                        .get("text_columns")
                        .and_then(|v| v.as_f64())
                        .map(|v| v.max(1.0) as usize)
                        .unwrap_or_else(|| {
                            if let Some(c) = columns_explicit {
                                c
                            } else if kind == MenuKind::Text {
                                1
                            } else {
                                columns
                            }
                        });
                    let rows = m.get("rows").and_then(|v| v.as_f64()).map(|v| v.max(1.0) as usize);
                    menus.push(MenuCfg {
                        name,
                        kind,
                        title: m.str_or("title", ""),
                        columns,
                        icon_columns,
                        text_columns,
                        rows,
                        icon_size: m.f64_or("icon_size", 28.0).max(8.0) as f32,
                        text_size: m.f64_or("text_size", 15.0).max(8.0) as f32,
                        cell_width: m.f64_or("cell_width", 120.0).max(20.0) as f32,
                        gap: m.f64_or("gap", 8.0).max(0.0) as f32,
                        padding: m.f64_or("padding", 12.0).max(0.0) as f32,
                        separator_thickness: m.f64_or("separator_thickness", 1.5).max(0.5) as f32,
                        separator_length: m.f64_or("separator_length", 0.6).clamp(0.1, 1.0) as f32,
                        wait_exec: m.bool_or("wait_exec", false),
                        wait_ms: m.f64_or("wait_timeout_ms", 1500.0).clamp(100.0, 30_000.0) as u64,
                        items,
                    });
                }
            }
        }

        Config {
            path,
            font_family,
            icon_family,
            font_size: isl.f64_or("font_size", 17.0) as f32,
            radius: isl.f64_or("radius", 26.0).clamp(0.0, 100.0) as f32,
            opacity: isl.f64_or("opacity", 0.75) as f32,
            shadow: isl.bool_or("shadow", true),
            surface_w: isl.f64_or("surface_width", 760.0) as u32,
            surface_h: isl.f64_or("surface_height", 560.0) as u32,
            close_button: isl.get("close_button").map(parse_button).unwrap_or(0),
            colors_file: isl.str_or("colors_file", "~/.config/dynamic-launcher/colors.css"),
            color_spec,
            vol_limit: audio.f64_or("limit", 1.0).max(0.1),
            sys_decimal: system.str_or("decimal", ","),
            sys_net_iface: system.str_or("net_interface", ""),
            drun: DrunCfg::from_table(&t.sub("drun")),
            menus,
            clip_font: clip.f64_or("font_size", 15.0).clamp(8.0, 64.0) as f32,
            clip_rows: clip.f64_or("rows", 8.0).clamp(1.0, 50.0) as usize,
            clip_width: clip.f64_or("width", 420.0).clamp(120.0, 1400.0) as f32,
            clip_max: clip.f64_or("max_items", 200.0).clamp(1.0, 5000.0) as usize,
            clip_list: clip.str_or("list_command", "cliphist list"),
            clip_copy: clip.str_or("copy_command", "cliphist decode | wl-copy"),
            clip_search: clip.bool_or("search", true),
            clip_window_radius: clip.f64_or("window_radius", 24.0).clamp(0.0, 100.0) as f32,
            wall: crate::wallpaper::WallCfg::from_table(&t.sub("wallpaper")),
            wifi: crate::wifi::WifiCfg::from_table(&t.sub("wifi")),
            vol_step: audio.f64_or("step", 5.0).max(1.0) as u32,
            audio_panel: crate::audio::AudioCfg::from_table(&audio),
            monitor: crate::monitor::MonitorCfg::from_table(&t.sub("monitor")),
            capture: crate::capture::CaptureCfg::from_table(&t.sub("capture")),
            bluetooth: crate::bluetooth::BtCfg::from_table(&t.sub("bluetooth")),
            hw: crate::quickset::HwCfg::from_table(&t.sub("quickset")),
            trash: crate::trash::TrashCfg::from_table(&t.sub("trash")),
        }
    }
}

// ------------------------------------------------------------------ farby

#[derive(Clone, Copy, Debug)]
pub struct Theme {
    pub bg: Color,
    pub fg: Color,
    pub accent: Color,
    pub on_accent: Color,
    /// pozadie a text vybranej (hover) položky textového menu; predvolene accent / on_accent
    pub menu_selected: Color,
    pub menu_selected_text: Color,
    pub alert: Color,
    pub on_alert: Color,
    pub urgent_border: Color,
    pub urgent_text: Color,
}

pub fn parse_hex(s: &str) -> Option<Color> {
    let h = s.trim().strip_prefix('#')?;
    let v = |i: usize, n: usize| u32::from_str_radix(h.get(i..i + n)?, 16).ok();
    match h.len() {
        3 => Some([v(0, 1)? as f32 * 17.0 / 255.0, v(1, 1)? as f32 * 17.0 / 255.0, v(2, 1)? as f32 * 17.0 / 255.0, 1.0]),
        6 => Some([v(0, 2)? as f32 / 255.0, v(2, 2)? as f32 / 255.0, v(4, 2)? as f32 / 255.0, 1.0]),
        8 => Some([v(0, 2)? as f32 / 255.0, v(2, 2)? as f32 / 255.0, v(4, 2)? as f32 / 255.0, v(6, 2)? as f32 / 255.0]),
        _ => None,
    }
}

/// `@define-color name #hex;` (matugen / GTK CSS) -> mapa farieb.
pub fn parse_css_palette(src: &str) -> HashMap<String, Color> {
    let mut m = HashMap::new();
    // odstráň /* komentáre */ (matugen ich pridáva na začiatok súboru)
    let mut clean = String::with_capacity(src.len());
    let mut rest = src;
    while let Some(a) = rest.find("/*") {
        clean.push_str(&rest[..a]);
        match rest[a + 2..].find("*/") {
            Some(b) => rest = &rest[a + 2 + b + 2..],
            None => {
                rest = "";
                break;
            }
        }
    }
    clean.push_str(rest);
    for stmt in clean.split(';') {
        let s = stmt.trim();
        if let Some(rest) = s.strip_prefix("@define-color") {
            let mut it = rest.trim().splitn(2, char::is_whitespace);
            if let (Some(name), Some(val)) = (it.next(), it.next()) {
                if let Some(c) = parse_hex(val) {
                    m.insert(name.trim().to_string(), c);
                }
            }
        }
    }
    m
}

fn resolve(spec: &str, pal: &HashMap<String, Color>) -> Option<Color> {
    let s = spec.trim();
    if let Some(n) = s.strip_prefix('@') {
        pal.get(n).copied()
    } else {
        parse_hex(s)
    }
}

impl Theme {
    pub fn load(cfg: &Config) -> Theme {
        let pal = std::fs::read_to_string(expand(&cfg.colors_file))
            .map(|s| parse_css_palette(&s))
            .unwrap_or_default();
        let get = |key: &str, default_spec: &str, fallback: Color| -> Color {
            let spec = cfg.color_spec.get(key).map(String::as_str).unwrap_or(default_spec);
            resolve(spec, &pal).or_else(|| resolve(default_spec, &pal)).unwrap_or(fallback)
        };
        let surface = [0.094, 0.067, 0.082, 1.0]; // #181115
        let primary = [0.988, 0.690, 0.839, 1.0]; // #fcb0d6
        // voliteľná farba bez vlastného predvoleného zápisu: neplatná / chýbajúca = `fallback`
        let opt = |key: &str, fallback: Color| -> Color {
            cfg.color_spec.get(key).and_then(|spec| resolve(spec, &pal)).unwrap_or(fallback)
        };
        let accent = get("accent", "@primary", primary);
        let on_accent = get("on_accent", "@surface", surface);
        Theme {
            bg: get("background", "@surface", surface),
            fg: get("foreground", "@primary", primary),
            accent,
            on_accent,
            menu_selected: opt("menu_selected", accent),
            menu_selected_text: opt("menu_selected_text", on_accent),
            alert: get("alert", "#dc2f2f", [0.863, 0.184, 0.184, 1.0]),
            on_alert: get("on_alert", "#ffffff", [1.0; 4]),
            urgent_border: get("urgent_border", "#fa3939", [0.98, 0.22, 0.22, 1.0]),
            urgent_text: get("urgent_text", "@primary", primary),
        }
    }
}

/// Tlačidlo myši z configu: názov (`left`, `right`, `middle`, `side`/`back`, `extra`/`forward`, `task`)
/// alebo číselný kód Linuxu (`BTN_SIDE` = 275, `BTN_EXTRA` = 276). Neznáme = 0 (vypnuté).
pub fn parse_button(v: &crate::toml::Value) -> u32 {
    if let Some(n) = v.as_f64() {
        return n.max(0.0) as u32;
    }
    match v.as_str().map(|s| s.trim().to_lowercase()).as_deref() {
        Some("left" | "btn_left") => 272,
        Some("right" | "btn_right") => 273,
        Some("middle" | "btn_middle") => 274,
        Some("side" | "back" | "btn_side") => 275,
        Some("extra" | "forward" | "btn_extra") => 276,
        Some("task" | "btn_task") => 277,
        Some(s) => s.parse().unwrap_or(0),
        None => 0,
    }
}

#[cfg(test)]
mod tests {
    #[test]
    fn button_names() {
        let t = toml::parse("a=\"side\"\nb=276\nc=\"BTN_EXTRA\"\nd=\"zzz\"\n").unwrap();
        assert_eq!(parse_button(t.get("a").unwrap()), 275);
        assert_eq!(parse_button(t.get("b").unwrap()), 276);
        assert_eq!(parse_button(t.get("c").unwrap()), 276);
        assert_eq!(parse_button(t.get("d").unwrap()), 0);
    }

    use super::*;
    #[test]
    fn palette_and_theme() {
        let pal = parse_css_palette(
            "    @define-color surface #181115;\n\n @define-color primary #fcb0d6;\n/* c */ @define-color x #12345678;",
        );
        assert!((pal["primary"][0] - 0.988).abs() < 0.01);
        assert!((pal["x"][3] - 0x78 as f32 / 255.0).abs() < 0.01);
        assert_eq!(resolve("@surface", &pal), pal.get("surface").copied());
        assert!(parse_hex("#fff").is_some() && parse_hex("zz").is_none());
    }
    #[test]
    fn menu_selected_colors() {
        // bez nastavenia = accent / on_accent; `[colors]` ich prepíše ("#rrggbb"), neplatná hodnota sa ignoruje
        let d = Theme::load(&Config::from_table(&Table::new(), PathBuf::from("x.toml")));
        assert_eq!(d.menu_selected, d.accent);
        assert_eq!(d.menu_selected_text, d.on_accent);
        let t = toml::parse("[colors]\nmenu_selected=\"#ff0000\"\nmenu_selected_text=\"nonsense\"\n").unwrap();
        let c = Theme::load(&Config::from_table(&t, PathBuf::from("x.toml")));
        assert_eq!(c.menu_selected, [1.0, 0.0, 0.0, 1.0]);
        assert_eq!(c.menu_selected_text, c.on_accent);
    }

    #[test]
    fn clipboard_config() {
        let d = Config::from_table(&Table::new(), PathBuf::new());
        assert_eq!((d.clip_rows, d.clip_max), (8, 200));
        assert_eq!(d.clip_list, "cliphist list");
        assert_eq!(d.clip_copy, "cliphist decode | wl-copy");
        let t = toml::parse("[clipboard]\nfont_size=18\nrows=5\nwidth=500\n").unwrap();
        let c = Config::from_table(&t, PathBuf::new());
        assert_eq!((c.clip_font, c.clip_rows, c.clip_width), (18.0, 5, 500.0));
    }

    #[test]
    fn menu_separator_positions() {
        let t = toml::parse("[[menu]]\nname=\"m\"\n[[menu.item]]\nseparator=true\n[[menu.item]]\nseparator=\"top\"\n[[menu.item]]\nseparator=\"center\"\n[[menu.item]]\nseparator=\"bottom\"\n[[menu.item]]\nseparator=false\nlabel=\"A\"\n[[menu.item]]\nseparator=\"\"\nlabel=\"B\"\n").unwrap();
        let c = Config::from_table(&t, PathBuf::new());
        let it = &c.menus[0].items;
        assert_eq!(it.len(), 6);
        let al: Vec<_> = it.iter().map(|i| (i.separator, i.sep_align)).collect();
        assert_eq!(al[0], (true, SepAlign::Center));
        assert_eq!(al[1], (true, SepAlign::Top));
        assert_eq!(al[2], (true, SepAlign::Center));
        assert_eq!(al[3], (true, SepAlign::Bottom));
        assert!(!it[4].separator && it[4].label == "A");
        assert!(!it[5].separator && it[5].label == "B");
    }

    #[test]
    fn menu_line_items() {
        let t = toml::parse("[[menu]]\nname=\"m\"\n[[menu.item]]\nlabel=\"A\"\ncommand=\"x\"\n[[menu.item]]\nline=\"\"\n[[menu.item]]\nline=\"Hotovo\"\n[[menu.item]]\nline=\"CPU: {}\"\nexec=\"echo 1\"\ninterval=2\n[[menu.item]]\nseparator=true\n").unwrap();
        let c = Config::from_table(&t, PathBuf::new());
        let it = &c.menus[0].items;
        assert_eq!(it.len(), 5);
        assert!(!it[0].line && it[1].line && it[2].line && it[3].line && !it[4].line);
        assert_eq!(it[1].label, "");
        assert_eq!(it[2].label, "Hotovo");
        assert_eq!((it[3].label.as_str(), it[3].exec.as_str(), it[3].interval), ("CPU: {}", "echo 1", 2.0));
        assert!(it[4].separator);
    }

    #[test]
    fn wifi_config() {
        let t = toml::parse("[wifi]\nrows=5\nwidth=400\n").unwrap();
        let c = Config::from_table(&t, PathBuf::new());
        assert_eq!((c.wifi.rows, c.wifi.width), (5, 400.0));
    }

    #[test]
    fn wallpaper_config() {
        let d = Config::from_table(&Table::new(), PathBuf::new());
        assert_eq!((d.wall.columns, d.wall.rows), (4, 4));
        let t = toml::parse("[wallpaper]\ncolumns=5\nrows=2\ndirectory=\"/x\"\n").unwrap();
        let c = Config::from_table(&t, PathBuf::new());
        assert_eq!((c.wall.columns, c.wall.rows, c.wall.dir.as_str()), (5, 2, "/x"));
    }

    #[test]
    fn capture_notify_config() {
        let t = toml::parse("[capture]\nnotify_ms=2000\nvideo_notify_ms=0\nhide_notice=true\n").unwrap();
        let c = Config::from_table(&t, PathBuf::new());
        assert_eq!(c.capture.notify_ms, 2000);
        assert_eq!(c.capture.video_notify_ms, 0);
        assert!(c.capture.hide_notice);
    }

    #[test]
    fn font_lists() {
        let t = toml::parse("[launcher]\nfont_family = \"A, B\"\nicon_family = []\n").unwrap();
        let cfg = Config::from_table(&t, PathBuf::from("x.toml"));
        assert_eq!(cfg.font_family, vec!["A", "B"]);
        assert!(cfg.icon_family.is_empty());
        let d = Config::from_table(&Table::new(), PathBuf::from("x.toml"));
        assert_eq!(d.icon_family, vec!["Hack Nerd Font Propo"]);
    }

    #[test]
    fn shipped_config_parses() {
        let text = include_str!("../config/dynamic-launcher/config.toml");
        let t = toml::parse(text).expect("config.toml");
        let c = Config::from_table(&t, PathBuf::new());
        let names: Vec<_> = c.menus.iter().map(|m| m.name.as_str()).collect();
        assert!(names.contains(&"radio") && names.contains(&"settings"), "{names:?}");
        assert!(c.capture.video_notify_ms == 0 && c.capture.hide_notice);
    }
}
