# dynamic-launcher

Efektná náhrada rofi pre Wayland (wlroots / Wayfire…). Vznikol z kódu `dynamic-island`, ale bez lišty: každé okno je
samostatný proces v strede obrazovky, vykreslený cez vlastný EGL/GLES2 renderer (bez UI frameworku).

Obsahuje: spúšťač aplikácií (`drun`), schránku, kôš, wallpaper, snímanie obrazovky, Wi-Fi, Bluetooth, monitor (DDC),
audio, vlastné menu (`[[menu]]`) a kontajner `quickset` so záložkami.

## Zostavenie

```sh
sudo apt install build-essential pkg-config cargo libwayland-dev
cargo build --release      # target/release/dynamic-launcher
cargo test
```

Za behu: `libEGL.so.1`, `libGLESv2.so.2`, `libxkbcommon.so.0`, písma. Voliteľné programy podľa modulov:
`cliphist` + `wl-copy` (schránka), `nmcli` (Wi-Fi), `bluetoothctl`/`bt-agent` (Bluetooth), `ddcutil` (monitor),
`wpctl` (audio), `grim` + `slurp` + `wf-recorder` (snímanie), `gio` (kôš).

## Spúšťanie

```
dynamic-launcher [--config CESTA] [--check] [--action NAZOV] [--drun] [--clip] [--drun-list]
```

`NAZOV`: `drun`, `clipboard`, `capture`, `trash`, `wallpaper`, `wifi`, `bluetooth`, `monitor`, `audio`, `quickset`,
`quickset:TAB` (napr. `quickset:wifi`) alebo názov vlastného `[[menu]]` (`sysmenu`, `radio`, `settings`, …).
`--drun` = `--action drun`, `--clip` = `--action clipboard`.

V `.desktop` súbore: `Exec=dynamic-launcher --action radio`.

### Zatváranie

- Všetky okná sú len v strede obrazovky a štandardne sa **nezatvárajú odchodom myši**. S `[drun] autoclose = true`
  sa zatvoria (drun, schránka aj panely) po odchode myši z okna, po `[launcher] collapse_delay_ms` (predvolene 700 ms);
  návrat myši alebo stlačenie klávesy zatvorenie zruší. Okno sa nezatvára pri rozpísanom filtri (drun, schránka),
  zadávaní hesla Wi-Fi, ťahaní posuvníka ani kým myš do okna (alebo do nového panela) nevstúpila.
- **Jedna skratka otvára aj zatvára**: druhé spustenie (`--drun` alebo ľubovoľné `--action …`) už otvorené okno zatvorí,
  aj keď je otvorený iný modul. Typicky skratka na `dynamic-launcher --drun`.
- Esc zatvorí okno; klik na položku menu ho zatvorí. Voliteľne aj ľubovoľné tlačidlo myši: `[launcher] close_button = "side"` (BACK = `BTN_SIDE`; ďalej `extra`, `middle`, `right`, `task` alebo číselný kód).
- Zatvorenie panela, spustenie `drun` aj otvorenie panela skratkou sú okamžité (bez animácie).
- Otvorenie panela **z drun** je animované pružinou: `drun` spustí panel s premennou `DL_FROM` (rozmer svojho okna),
  počká, kým panel zobrazí prvý frame, rýchlo zosvetlie a skončí; panel medzitým dorastie z rozmeru `drun`.
  Platí pre položku `.desktop` s presne `Exec=dynamic-launcher --action NAZOV`; iné aplikácie sa spúšťajú bez čakania.
  Prepínanie záložiek `quickset` a `module:NAZOV` v menu ide pružinou tiež.

## Snímanie obrazovky / nahrávanie

Panel `capture` ponúka režim **Screen** a **Region** (bez Wayfire IPC nie je režim Okno), typ obrázok/video, časovač,
kurzor a zvuk. Po kliknutí na tlačidlo sa panel zatvorí a prácu preberie oddelený proces:

- odpočet a stav ukazujú **notifikácie** (`org.freedesktop.Notifications`, nahrádzajú sa na mieste),
- uložená snímka: notifikácia na `notify_ms` (0 = kým ju nezavrieš),
- video: `video_notify_ms = 0` ⇒ trvalá notifikácia s bežiacim časom; **jej zavretie nahrávanie ukončí**. Nahrávanie
  zastaví aj opätovné `dynamic-launcher --action capture`,
- `hide_notice = true` – pred snímkou sa notifikácia skryje a po `settle_ms` sa snímka urobí. Do videa nie je možné
  notifikáciu spoľahlivo skryť (záleží na notifikačnom démone; trvalú notifikáciu o nahrávaní nastav
  `video_notify_ms` na čas, alebo `notify = false`).

## Konfigurácia

`~/.config/dynamic-launcher/config.toml` (predvolené) a `colors.css` (matugen, `@define-color …`), vzor v
`config/dynamic-launcher/`. Sekcie: `[launcher]`, `[colors]`, `[quickset]`, `[drun]`, `[audio]`, `[clipboard]`,
`[trash]`, `[wallpaper]`, `[wifi]`, `[bluetooth]`, `[monitor]`, `[capture]`, `[system]`, `[[menu]]`.
`dynamic-launcher --check` konfiguráciu overí.

Menu: položky `label`/`icon`/`command`, `line` (riadok s textom alebo výstupom `exec`), `separator`
(`top`/`center`/`bottom`), `interval` (obnova výstupu). `command = "module:NAZOV"` otvorí iný panel.
Ikony menu a skripty z ukážkového configu (`icons/`, `scripts/`) si skopíruj zo svojho `dynamic-island`
(`~/.config/dynamic-launcher/`), alebo položky uprav.

**Rádio** nemá sledovanie stavu: položka je obyčajný príkaz (`pkill -x mpv; mpv URL`) a „Vypnúť rádio“ je
`pkill -x mpv`.

## Nastavenia (GUI)

`config/dynamic-launcher-settings/` – okno nastavení v GTK4/libadwaita (`python3-gi gir1.2-adw-1`), ktoré upravuje
`config.toml` so zachovaním komentárov. Pozri jeho `README.md`.

## Čo tu nie je (oproti dynamic-island)

Lišta/kapsula a moduly, práve hrá, idle, notifikačný démon a história, eject, IPC, rozloženie klávesnice, autohide.
