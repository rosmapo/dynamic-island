//! Modul capture: snímka obrazovky / oblasti (`grim`, `slurp`) a nahrávanie videa (`wf-recorder`).
//!
//! Okno launchera sa po spustení snímania zatvorí, preto snímanie vykoná samostatný proces
//! (`dynamic-launcher --capture-job …`, spustený na pozadí). Priebeh (odpočet, nahrávanie, výsledok) ukazuje
//! notifikácia cez D-Bus (`org.freedesktop.Notifications`, teda notifikačný démon, ktorý používaš). Pri videu so
//! `video_notify_ms = 0` je notifikácia trvalá a plynie v nej čas nahrávania; zatvorením notifikácie sa nahrávanie
//! ukončí. Nahrávanie zastaví aj druhé `dynamic-launcher --action capture`.
use crate::config::Config;
use crate::dbus::{Conn, Reader, W, Message, SIGNAL};
use crate::sys;
use crate::toml::{Table, TableExt};
use std::process::{Command, Stdio};
use std::time::{Duration, Instant};

/// Čo sa snímá.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Mode {
    Screen,
    Region,
}

impl Mode {
    pub const ALL: [Mode; 2] = [Mode::Screen, Mode::Region];
    pub fn label(self) -> &'static str {
        match self {
            Mode::Screen => "Obrazovka",
            Mode::Region => "Región",
        }
    }
    fn parse(s: &str) -> Option<Mode> {
        match s.trim().to_lowercase().as_str() {
            "screen" | "obrazovka" | "output" => Some(Mode::Screen),
            "region" | "area" | "oblast" => Some(Mode::Region),
            _ => None,
        }
    }
    fn arg(self) -> &'static str {
        match self {
            Mode::Screen => "screen",
            Mode::Region => "region",
        }
    }
}

/// Obrázok alebo video.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Kind {
    Image,
    Video,
}

impl Kind {
    pub const ALL: [Kind; 2] = [Kind::Image, Kind::Video];
    pub fn label(self) -> &'static str {
        match self {
            Kind::Image => "Obrázok",
            Kind::Video => "Video",
        }
    }
}

/// Nastavenia `[capture]`.
#[derive(Clone, Debug)]
pub struct CaptureCfg {
    pub font_size: f32,
    pub width: f32,
    /// adresár snímok / videí (`~` sa rozvinie)
    pub dir: String,
    pub video_dir: String,
    /// vzor názvu súboru pre `strftime`
    pub name: String,
    /// ponúkané časovače v sekundách (0 = hneď)
    pub delays: Vec<u32>,
    pub mode: Mode,
    pub kind: Kind,
    pub cursor: bool,
    pub audio: bool,
    /// `png` | `jpeg`
    pub format: String,
    /// prípona videa (kontajner určí `wf-recorder` podľa nej): `mp4`, `mkv`, `webm`
    pub video_ext: String,
    /// názov výstupu (monitora) pre režim „Obrazovka“; prázdne = predvolené správanie `grim` / `wf-recorder`
    pub output: String,
    /// ďalšie argumenty pre `wf-recorder` (oddelené medzerami)
    pub recorder_args: Vec<String>,
    /// argumenty pre `slurp` (oddelené medzerami, bez úvodzoviek), napr. `-b #ffffff30 -w 0`
    pub slurp_args: Vec<String>,
    /// skopírovať snímku do schránky (`wl-copy`)
    pub copy: bool,
    /// ukazovať notifikácie (odpočet, nahrávanie, výsledok)
    pub notify: bool,
    /// ako dlho (ms) ostane notifikácia o uloženej snímke / nahrávke a odpočet; 0 = podľa démona
    pub notify_ms: i32,
    /// ako dlho (ms) je vidieť notifikácia pri nahrávaní videa; 0 = trvalá, plynie v nej čas a jej zatvorením sa
    /// nahrávanie ukončí. Pri nenulovej hodnote sa ukáže len raz a nahrávanie sa zastaví `--action capture`
    pub video_notify_ms: i32,
    /// pri snímke zatvoriť notifikáciu odpočtu pred zachytením (aby nebola na obrázku)
    pub hide_notice: bool,
    /// čakanie po zatvorení okna / notifikácie pred snímkou (ms)
    pub settle_ms: u64,
}

fn expand_home(p: &str) -> String {
    match (p.strip_prefix("~/"), std::env::var("HOME")) {
        (Some(rest), Ok(h)) if !h.is_empty() => format!("{h}/{rest}"),
        _ => p.to_string(),
    }
}

impl CaptureCfg {
    pub fn from_table(t: &Table) -> CaptureCfg {
        let mut delays: Vec<u32> = t
            .get("delays")
            .and_then(|v| v.as_arr())
            .map(|a| a.iter().filter_map(|v| v.as_f64()).map(|n| n.clamp(0.0, 120.0) as u32).collect())
            .unwrap_or_default();
        if delays.is_empty() {
            delays = vec![0, 3, 5, 10];
        }
        delays.truncate(6);
        let mode = Mode::parse(&t.str_or("mode", "region")).unwrap_or(Mode::Region);
        let kind = if t.str_or("kind", "image").trim().eq_ignore_ascii_case("video") { Kind::Video } else { Kind::Image };
        let format = match t.str_or("format", "png").trim().to_lowercase().as_str() {
            "jpg" | "jpeg" => "jpeg",
            _ => "png",
        }
        .to_string();
        let video_ext = t.str_or("video_ext", "mp4").trim().trim_start_matches('.').to_lowercase();
        CaptureCfg {
            font_size: t.f64_or("font_size", 15.0).clamp(8.0, 64.0) as f32,
            width: t.f64_or("width", 380.0).clamp(240.0, 800.0) as f32,
            dir: expand_home(&t.str_or("dir", "~/Pictures/Screenshots")),
            video_dir: expand_home(&t.str_or("video_dir", "~/Videos/Recordings")),
            name: t.str_or("name", "%Y-%m-%d_%H-%M-%S"),
            delays,
            mode,
            kind,
            cursor: t.bool_or("cursor", false),
            audio: t.bool_or("audio", false),
            format,
            video_ext: if video_ext.is_empty() { "mp4".into() } else { video_ext },
            output: t.str_or("output", "").trim().to_string(),
            slurp_args: t.str_or("slurp_args", "-b #ffffff30 -w 0").split_whitespace().map(str::to_string).collect(),
            recorder_args: t.str_or("recorder_args", "").split_whitespace().map(str::to_string).collect(),
            copy: t.bool_or("copy", true),
            notify: t.bool_or("notify", true),
            notify_ms: t.f64_or("notify_ms", 4000.0).clamp(0.0, 600_000.0) as i32,
            video_notify_ms: t.f64_or("video_notify_ms", 0.0).clamp(0.0, 600_000.0) as i32,
            hide_notice: t.bool_or("hide_notice", true),
            settle_ms: t.f64_or("settle_ms", 350.0).clamp(0.0, 3000.0) as u64,
        }
    }
}

/// Výška panela (logické px) pre dané písmo – musí sedieť s `build_capture` v `ui.rs`.
pub fn panel_height(font: f32) -> f32 {
    let row = font + 20.0;
    // pad + 3 sekcie (popisok + rad) + prepínač + tlačidlo, s medzerami
    2.0 * 14.0 + 3.0 * (22.0 + row) + 4.0 * 12.0 + row + (row + 4.0)
}

/// Žiadosť o snímanie z panela.
#[derive(Clone, Debug, PartialEq)]
pub struct Request {
    pub mode: Mode,
    pub kind: Kind,
    pub delay: u32,
    pub cursor: bool,
    pub audio: bool,
}

impl Request {
    /// Argumenty pre `--capture-job`.
    fn to_args(&self) -> Vec<String> {
        vec![
            self.mode.arg().into(),
            if self.kind == Kind::Video { "video" } else { "image" }.into(),
            self.delay.to_string(),
            (self.cursor as u8).to_string(),
            (self.audio as u8).to_string(),
        ]
    }

    fn from_args(a: &[String]) -> Option<Request> {
        if a.len() < 5 {
            return None;
        }
        Some(Request {
            mode: Mode::parse(&a[0])?,
            kind: if a[1] == "video" { Kind::Video } else { Kind::Image },
            delay: a[2].parse().ok()?,
            cursor: a[3] == "1",
            audio: a[4] == "1",
        })
    }
}

// ---------------------------------------------------------------- čisté pomocné funkcie

/// Overí výstup `slurp` (`X,Y WxH`) a vráti ho očistený.
pub fn parse_slurp(out: &str) -> Option<String> {
    let s = out.trim();
    let (pos, size) = s.split_once(' ')?;
    let (x, y) = pos.split_once(',')?;
    let (w, h) = size.split_once('x')?;
    let ok = [x, y, w, h].iter().all(|p| p.trim().trim_start_matches('-').parse::<u32>().is_ok());
    (ok && w.trim() != "0" && h.trim() != "0").then(|| s.to_string())
}

/// `m:ss` (alebo `h:mm:ss`).
pub fn format_elapsed(secs: u32) -> String {
    if secs >= 3600 {
        format!("{}:{:02}:{:02}", secs / 3600, secs / 60 % 60, secs % 60)
    } else {
        format!("{}:{:02}", secs / 60, secs % 60)
    }
}

/// Úplná cesta k novému súboru.
pub fn target_path(cfg: &CaptureCfg, kind: Kind, tm: &sys::Tm) -> String {
    let stem = sys::strftime_str(&cfg.name, tm);
    let stem = if stem.trim().is_empty() { "capture".to_string() } else { stem.replace('/', "-") };
    match kind {
        Kind::Image => format!("{}/{}.{}", cfg.dir.trim_end_matches('/'), stem, if cfg.format == "jpeg" { "jpg" } else { "png" }),
        Kind::Video => format!("{}/{}.{}", cfg.video_dir.trim_end_matches('/'), stem, cfg.video_ext),
    }
}

fn base_name(path: &str) -> &str {
    path.rsplit('/').next().unwrap_or(path)
}

// ---------------------------------------------------------------- spustenie a zastavenie

fn pid_file() -> std::path::PathBuf {
    let dir = std::env::var("XDG_RUNTIME_DIR").ok().filter(|s| !s.is_empty()).unwrap_or_else(|| "/tmp".into());
    std::path::PathBuf::from(dir).join("dynamic-launcher-capture.pid")
}

/// Stav bežiacej úlohy zo súboru: (PID úlohy, PID nahrávača alebo 0), ak úloha naozaj beží.
fn running_job() -> Option<(i32, i32)> {
    let s = std::fs::read_to_string(pid_file()).ok()?;
    let mut it = s.split_whitespace().filter_map(|x| x.parse::<i32>().ok());
    let job = it.next()?;
    let rec = it.next().unwrap_or(0);
    let alive = std::fs::read(format!("/proc/{job}/cmdline")).map(|b| b.split(|c| *c == 0).any(|a| a == b"--capture-job")).unwrap_or(false);
    alive.then_some((job, rec))
}

/// Zastaví bežiace nahrávanie (SIGINT pre `wf-recorder`, súbor sa dokončí) alebo zruší odpočet / výber.
/// Vráti `true`, ak niečo bežalo.
pub fn stop_running() -> bool {
    match running_job() {
        Some((_, rec)) if rec > 1 => {
            sys::interrupt(rec);
            true
        }
        Some((job, _)) => {
            sys::terminate_group(job);
            let _ = std::fs::remove_file(pid_file());
            true
        }
        None => false,
    }
}

/// Spustí snímanie v samostatnom procese na pozadí (prežije zatvorenie okna).
pub fn run(req: Request, cfg: &Config) {
    use std::os::unix::process::CommandExt;
    let Ok(exe) = std::env::current_exe() else { return };
    let mut c = Command::new(exe);
    c.arg("--config").arg(&cfg.path).arg("--capture-job").args(req.to_args());
    c.stdin(Stdio::null()).stdout(Stdio::null()).stderr(Stdio::null());
    unsafe {
        c.pre_exec(|| {
            sys::new_session();
            Ok(())
        });
    }
    let _ = c.spawn();
}

/// Zapisuje PID úlohy (a nahrávača) a pri skončení súbor zmaže.
struct JobGuard;

impl JobGuard {
    fn new() -> Option<JobGuard> {
        if running_job().map(|(j, _)| j != std::process::id() as i32).unwrap_or(false) {
            return None;
        }
        let _ = std::fs::write(pid_file(), std::process::id().to_string());
        Some(JobGuard)
    }
    fn set_recorder(&self, pid: i32) {
        let _ = std::fs::write(pid_file(), format!("{} {}", std::process::id(), pid));
    }
}

impl Drop for JobGuard {
    fn drop(&mut self) {
        let _ = std::fs::remove_file(pid_file());
    }
}

// ---------------------------------------------------------------- notifikácie (D-Bus)

const NOTIF_DEST: &str = "org.freedesktop.Notifications";
const NOTIF_PATH: &str = "/org/freedesktop/Notifications";

/// Klient `org.freedesktop.Notifications`: jedna notifikácia, ktorá sa dá nahrádzať a zatvoriť, a hlásenie jej
/// zatvorenia používateľom. Bez notifikačného démona (alebo pri chybe) sa všetko ticho preskočí.
struct Notifier {
    conn: Conn,
    id: u32,
}

impl Notifier {
    fn new() -> Option<Notifier> {
        let mut conn = Conn::connect().ok()?;
        let mut w = W::default();
        w.string("type='signal',interface='org.freedesktop.Notifications',member='NotificationClosed'");
        conn.call("org.freedesktop.DBus", "/org/freedesktop/DBus", "org.freedesktop.DBus", "AddMatch", "s", w.b).ok()?;
        Some(Notifier { conn, id: 0 })
    }

    /// Ukáže (alebo nahradí) notifikáciu; `timeout_ms` 0 = trvalá, -1 = podľa démona.
    fn show(&mut self, summary: &str, body: &str, icon: &str, timeout_ms: i32) {
        let mut w = W::default();
        w.string("dynamic-launcher");
        w.u32(self.id);
        w.string(icon);
        w.string(summary);
        w.string(body);
        w.array(4, |_| {});
        w.array(8, |_| {});
        w.u32(timeout_ms as u32);
        if let Ok(m) = self.conn.call(NOTIF_DEST, NOTIF_PATH, NOTIF_DEST, "Notify", "susssasa{sv}i", w.b) {
            if let Some(id) = Reader::new(&m.body, 0).u32() {
                self.id = id;
            }
        }
    }

    fn close(&mut self) {
        if self.id != 0 {
            let mut w = W::default();
            w.u32(self.id);
            let _ = self.conn.call(NOTIF_DEST, NOTIF_PATH, NOTIF_DEST, "CloseNotification", "u", w.b);
            self.id = 0;
        }
    }

    /// Čaká najviac `ms`; vráti `true`, ak používateľ našu notifikáciu zatvoril (dôvod 2 = zatvorená používateľom).
    fn dismissed_within(&mut self, ms: u64) -> bool {
        let end = Instant::now() + Duration::from_millis(ms);
        loop {
            let left = end.saturating_duration_since(Instant::now());
            if left.is_zero() {
                return false;
            }
            self.conn.set_read_timeout(Some(left));
            let m: Message = match self.conn.recv() {
                Ok(m) => m,
                Err(e) if matches!(e.kind(), std::io::ErrorKind::WouldBlock | std::io::ErrorKind::TimedOut) => return false,
                Err(_) => {
                    // spojenie spadlo – ďalej bez notifikácií (len čakáme)
                    std::thread::sleep(left);
                    return false;
                }
            };
            if m.typ == SIGNAL && m.member.as_deref() == Some("NotificationClosed") {
                let mut r = Reader::new(&m.body, 0);
                if let (Some(id), Some(reason)) = (r.u32(), r.u32()) {
                    if id == self.id && self.id != 0 {
                        self.id = 0;
                        if reason == 2 {
                            return true;
                        }
                    }
                }
            }
        }
    }
}

/// Notifikácie sú voliteľné: bez nich sa čaká obyčajným spánkom.
struct Notice(Option<Notifier>);

impl Notice {
    fn show(&mut self, summary: &str, body: &str, icon: &str, timeout_ms: i32) {
        if let Some(n) = &mut self.0 {
            n.show(summary, body, icon, timeout_ms);
        }
    }
    fn close(&mut self) {
        if let Some(n) = &mut self.0 {
            n.close();
        }
    }
    /// Pauza `ms`; `true` = používateľ zavrel notifikáciu (zrušiť / zastaviť).
    fn pause(&mut self, ms: u64) -> bool {
        match &mut self.0 {
            Some(n) => n.dismissed_within(ms),
            None => {
                std::thread::sleep(Duration::from_millis(ms));
                false
            }
        }
    }
}

// ---------------------------------------------------------------- vykonávanie

/// Výber oblasti `slurp`-om. `None` = zrušené (Esc).
fn run_slurp(cfg: &CaptureCfg) -> Result<Option<String>, String> {
    let out = Command::new("slurp")
        .args(&cfg.slurp_args)
        .stdin(Stdio::null())
        .stdout(Stdio::piped())
        .stderr(Stdio::null())
        .output()
        .map_err(|_| "slurp nie je nainštalovaný".to_string())?;
    if !out.status.success() {
        return Ok(None);
    }
    Ok(parse_slurp(&String::from_utf8_lossy(&out.stdout)))
}

/// Cieľ snímania: celá obrazovka (voliteľne konkrétny výstup) alebo oblasť.
enum Target {
    Output(Option<String>),
    Geometry(String),
}

fn shoot_image(cfg: &CaptureCfg, req: &Request, target: &Target, path: &str) -> Result<(), String> {
    let mut c = Command::new("grim");
    if req.cursor {
        c.arg("-c");
    }
    c.args(["-t", &cfg.format]);
    match target {
        Target::Geometry(g) => {
            c.args(["-g", g]);
        }
        Target::Output(Some(o)) => {
            c.args(["-o", o]);
        }
        Target::Output(None) => {}
    }
    c.arg(path).stdin(Stdio::null()).stdout(Stdio::null()).stderr(Stdio::piped());
    let out = c.output().map_err(|_| "grim nie je nainštalovaný".to_string())?;
    if !out.status.success() {
        let e = String::from_utf8_lossy(&out.stderr);
        return Err(e.lines().last().unwrap_or("grim zlyhal").trim().to_string());
    }
    if cfg.copy {
        if let Ok(f) = std::fs::File::open(path) {
            let mime = if cfg.format == "jpeg" { "image/jpeg" } else { "image/png" };
            // wl-copy sa po načítaní sám odpojí do pozadia
            let _ = Command::new("wl-copy").args(["-t", mime]).stdin(f).stdout(Stdio::null()).stderr(Stdio::null()).status();
        }
    }
    Ok(())
}

fn record_video(cfg: &CaptureCfg, req: &Request, target: &Target, path: &str, guard: &JobGuard, notice: &mut Notice) -> Result<(), String> {
    let log = "/tmp/dynamic-launcher-capture.log";
    let mut c = Command::new("wf-recorder");
    if req.audio {
        c.arg("-a");
    }
    match target {
        Target::Geometry(g) => {
            c.args(["-g", g]);
        }
        Target::Output(Some(o)) => {
            c.args(["-o", o]);
        }
        Target::Output(None) => {}
    }
    c.args(&cfg.recorder_args).args(["-f", path]).stdin(Stdio::null()).stdout(Stdio::null());
    match std::fs::File::create(log) {
        Ok(f) => c.stderr(Stdio::from(f)),
        Err(_) => c.stderr(Stdio::null()),
    };
    let mut child = c.spawn().map_err(|_| "wf-recorder nie je nainštalovaný".to_string())?;
    guard.set_recorder(child.id() as i32);
    let persistent = cfg.video_notify_ms == 0;
    let start = Instant::now();
    let mut shown = u32::MAX;
    let mut stopped = false;
    let status = loop {
        match child.try_wait() {
            Ok(Some(st)) => break st,
            Ok(None) => {}
            Err(e) => return Err(e.to_string()),
        }
        let secs = start.elapsed().as_secs() as u32;
        if secs != shown && (persistent || shown == u32::MAX) {
            shown = secs;
            let body = if persistent { "Zatvorením tejto notifikácie nahrávanie ukončíš." } else { "Nahrávanie zastavíš príkazom dynamic-launcher --action capture." };
            notice.show(&format!("REC {}", format_elapsed(secs)), body, "media-record", if persistent { 0 } else { cfg.video_notify_ms });
        }
        if notice.pause(250) && !stopped {
            stopped = true;
            sys::interrupt(child.id() as i32); // SIGINT: wf-recorder dokončí súbor
        }
    };
    let size = std::fs::metadata(path).map(|m| m.len()).unwrap_or(0);
    if size == 0 {
        let msg = std::fs::read_to_string(log).ok().and_then(|s| s.lines().rev().find(|l| !l.trim().is_empty()).map(|l| l.trim().to_string()));
        return Err(msg.unwrap_or_else(|| format!("wf-recorder skončil ({status})")));
    }
    Ok(())
}

/// Vykoná snímanie / nahrávanie (vnútorný príkaz `--capture-job`); vráti kód skončenia procesu.
pub fn job_main(cfg: Config, args: &[String]) -> i32 {
    let c = cfg.capture.clone();
    let Some(req) = Request::from_args(args) else {
        eprintln!("dynamic-launcher --capture-job: neplatné argumenty");
        return 2;
    };
    let Some(guard) = JobGuard::new() else {
        return 0; // už beží iné snímanie
    };
    let video = req.kind == Kind::Video;
    let mut notice = Notice(if c.notify { Notifier::new() } else { None });
    let result = (|| -> Result<Option<String>, String> {
        // okno launchera sa zatvára – počkať, kým zmizne
        std::thread::sleep(Duration::from_millis(c.settle_ms));
        // 1) výber oblasti pred odpočtom
        let mut target = None;
        if req.mode == Mode::Region {
            match run_slurp(&c)? {
                Some(g) => target = Some(Target::Geometry(g)),
                None => return Ok(None),
            }
        }
        // 2) odpočet v notifikácii (zatvorenie notifikácie = zrušenie)
        for n in (1..=req.delay).rev() {
            notice.show(&format!("{} za {n} s", if video { "Nahrávanie" } else { "Snímanie" }), "Zatvorením notifikácie to zrušíš.", "appointment-soon", 1500);
            if notice.pause(1000) {
                return Ok(None);
            }
        }
        // notifikácia odpočtu sa pred snímkou zatvorí, aby nebola na obrázku (video: nahrávanie má vlastnú)
        if req.delay > 0 && (video || c.hide_notice) {
            notice.close();
            std::thread::sleep(Duration::from_millis(c.settle_ms));
        }
        let target = target.unwrap_or_else(|| Target::Output(Some(c.output.clone()).filter(|o| !o.is_empty())));
        // 3) snímanie
        let path = target_path(&c, req.kind, &sys::local_tm(sys::now_unix()));
        if let Some(dir) = std::path::Path::new(&path).parent() {
            std::fs::create_dir_all(dir).map_err(|e| format!("adresár {}: {e}", dir.display()))?;
        }
        if video {
            record_video(&c, &req, &target, &path, &guard, &mut notice)?;
        } else {
            shoot_image(&c, &req, &target, &path)?;
        }
        Ok(Some(path))
    })();
    match result {
        Ok(Some(path)) => {
            notice.show(if video { "Nahrávka uložená" } else { "Snímka uložená" }, base_name(&path), if video { "video-x-generic" } else { &path }, if c.notify_ms == 0 { -1 } else { c.notify_ms });
            0
        }
        Ok(None) => {
            notice.close();
            0
        }
        Err(e) => {
            if !e.is_empty() {
                notice.show("Snímanie zlyhalo", &e, "dialog-error", if c.notify_ms == 0 { -1 } else { c.notify_ms * 2 });
                eprintln!("dynamic-launcher --capture-job: {e}");
            }
            1
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn defaults() {
        let c = CaptureCfg::from_table(&Table::new());
        assert_eq!(c.delays, vec![0, 3, 5, 10]);
        assert_eq!(c.mode, Mode::Region);
        assert_eq!(c.kind, Kind::Image);
        assert_eq!(c.format, "png");
        assert_eq!(c.video_ext, "mp4");
        assert!(c.copy && c.notify && c.hide_notice);
        assert_eq!((c.notify_ms, c.video_notify_ms), (4000, 0));
        assert_eq!(c.slurp_args, vec!["-b", "#ffffff30", "-w", "0"]);
        assert!(c.dir.ends_with("Pictures/Screenshots"));
    }

    #[test]
    fn slurp_output() {
        assert_eq!(parse_slurp("10,20 300x200\n").as_deref(), Some("10,20 300x200"));
        assert_eq!(parse_slurp("-5,20 300x200").as_deref(), Some("-5,20 300x200"));
        assert_eq!(parse_slurp("10,20 0x200"), None);
        assert_eq!(parse_slurp(""), None);
        assert_eq!(parse_slurp("selection cancelled"), None);
    }

    #[test]
    fn elapsed() {
        assert_eq!(format_elapsed(5), "0:05");
        assert_eq!(format_elapsed(125), "2:05");
        assert_eq!(format_elapsed(3725), "1:02:05");
    }

    #[test]
    fn request_roundtrip() {
        let r = Request { mode: Mode::Region, kind: Kind::Video, delay: 5, cursor: true, audio: false };
        assert_eq!(Request::from_args(&r.to_args()), Some(r));
        assert_eq!(Request::from_args(&["x".into()]), None);
    }

    #[test]
    fn panel_height_matches_layout() {
        // 5 radov (f + 20) + pevné konštanty
        let f = 15.0;
        assert_eq!(panel_height(f), 146.0 + 5.0 * (f + 20.0));
    }
}
