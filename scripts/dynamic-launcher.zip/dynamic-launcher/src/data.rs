//! Správy z pomocných vlákien do hlavnej slučky a pomocné funkcie dát.

/// Položka histórie schránky (cliphist): `raw` je celý riadok z `cliphist list` (ide na vstup
/// `cliphist decode`), `text` je náhľad na zobrazenie.
#[derive(Clone, Debug, PartialEq, Default)]
pub struct ClipEntry {
    pub raw: String,
    pub text: String,
}

/// Rozoberie výstup `cliphist list` (riadok = `id<TAB>náhľad`), najviac `max` najnovších položiek.
pub fn parse_clip_list(out: &str, max: usize) -> Vec<ClipEntry> {
    out.lines()
        .filter(|l| !l.trim().is_empty())
        .take(max)
        .map(|l| {
            let text = match l.split_once('\t') {
                Some((_, t)) => t,
                None => l,
            };
            ClipEntry { raw: l.to_string(), text: text.split_whitespace().collect::<Vec<_>>().join(" ") }
        })
        .collect()
}

/// Indexy položiek, ktoré vyhovujú filtru (ako v rofi): slová oddelené medzerou sa hľadajú ako podreťazce
/// bez ohľadu na veľkosť písmen a všetky musia sedieť. Prázdny filter vráti všetky položky v pôvodnom poradí.
pub fn clip_filter(entries: &[ClipEntry], query: &str) -> Vec<usize> {
    let words: Vec<String> = query.split_whitespace().map(|w| w.to_lowercase()).collect();
    entries
        .iter()
        .enumerate()
        .filter(|(_, e)| {
            if words.is_empty() {
                return true;
            }
            let hay = e.text.to_lowercase();
            words.iter().all(|w| hay.contains(w.as_str()))
        })
        .map(|(i, _)| i)
        .collect()
}

/// Z výstupu príkazu položky menu vyberie prvý neprázdny riadok (bez okrajových medzier a riadiacich znakov).
pub fn menu_exec_line(raw: &str) -> String {
    raw.lines()
        .map(|l| l.chars().filter(|c| !c.is_control()).collect::<String>())
        .map(|l| l.trim().to_string())
        .find(|l| !l.is_empty())
        .unwrap_or_default()
}

/// Text položky menu s `exec`. `out` = výstup príkazu (`None` = ešte nie je načítaný).
/// Ak `label` obsahuje `{}`, je to šablóna a `{}` nahradí výstup (kým nie je načítaný, je prázdny, takže rozloženie
/// ostane stabilné: `CPU: {} %` → `CPU:   %`). Inak sa do načítania zobrazuje `label` a potom samotný výstup.
pub fn menu_item_text(label: &str, out: Option<&str>) -> String {
    if label.contains("{}") {
        label.replace("{}", out.unwrap_or(""))
    } else {
        match out {
            Some(o) => o.to_string(),
            None => label.to_string(),
        }
    }
}

#[derive(Debug)]
pub enum Msg {
    /// výstup príkazu `exec` položky menu: (generácia otvorenia menu, index položky, prvý riadok výstupu)
    MenuExec(u64, usize, String),
    /// história schránky (najnovšie prvé)
    Clip(Vec<ClipEntry>),
    /// obsah koša zo všetkých diskov (najnovšie prvé) + hláška o práve dokončenej obnove / vyprázdnení (inak prázdna)
    Trash(Vec<crate::trash::TrashEntry>, String),
    /// zoznam obrázkov modulu wallpaper + cesta k aktuálnemu pozadiu
    Wall(Vec<crate::wallpaper::WallEntry>, String),
    /// náhľad obrázka s daným indexom je hotový
    WallThumb(usize, String),
    /// pozadie bolo úspešne nastavené (cesta)
    WallCurrent(String),
    /// témy z adresára (názov, cesta) a názov aktuálne nastavenej (prázdny = režim „wallpaper“)
    WallThemes(Vec<(String, String)>, String),
    /// téma bola úspešne nastavená (názov)
    WallTheme(String),
    /// stav Wi-Fi z NetworkManagera
    Wifi(crate::wifi::WifiState),
    /// stavová / chybová správa Wi-Fi panela (prázdna = vymazať)
    WifiNote(String),
    /// text zo schránky pre pole hesla
    WifiPaste(String),
    /// zoznam audio zariadení a predvolené zariadenia
    AudioDev(crate::audio::AudioState),
    /// stav monitora (jas, kontrast, preset, vstup, nočný režim)
    Monitor(crate::monitor::MonitorState),
    /// stav Bluetooth (BlueZ)
    Bluetooth(crate::bluetooth::BtState),
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn clip_list() {
        let out = "12\thello   world\n\n11\t[[ binary data 1 KiB png 10x10 ]]\n10\tx\n";
        let v = parse_clip_list(out, 2);
        assert_eq!(v.len(), 2);
        assert_eq!(v[0], ClipEntry { raw: "12\thello   world".into(), text: "hello world".into() });
        assert_eq!(v[1].text, "[[ binary data 1 KiB png 10x10 ]]");
        assert_eq!(parse_clip_list("", 5), vec![]);
    }
    #[test]
    fn menu_exec_texts() {
        assert_eq!(menu_exec_line("\n  \n  23 %  \nzvyšok\n"), "23 %");
        assert_eq!(menu_exec_line("a\x1b[0mb"), "a[0mb");
        assert_eq!(menu_exec_line(""), "");
        assert_eq!(menu_exec_line("   \n\t\n"), "");
        // šablóna: kým výstup nie je, `{}` je prázdne
        assert_eq!(menu_item_text("CPU: {} %", None), "CPU:  %");
        assert_eq!(menu_item_text("CPU: {} %", Some("23")), "CPU: 23 %");
        // bez šablóny: label ako zástupný text, potom výstup
        assert_eq!(menu_item_text("Kôš", None), "Kôš");
        assert_eq!(menu_item_text("Kôš", Some("3 položky")), "3 položky");
        assert_eq!(menu_item_text("", None), "");
        assert_eq!(menu_item_text("Kôš", Some("")), "");
    }
    #[test]
    fn clip_filtering() {
        let e = |t: &str| ClipEntry { raw: format!("1\t{t}"), text: t.into() };
        let v = vec![e("Hello World"), e("foo bar"), e("world of FOO"), e("ružová")];
        assert_eq!(clip_filter(&v, ""), vec![0, 1, 2, 3]);
        assert_eq!(clip_filter(&v, "   "), vec![0, 1, 2, 3]);
        assert_eq!(clip_filter(&v, "WORLD"), vec![0, 2]);
        assert_eq!(clip_filter(&v, "world foo"), vec![2]);
        assert_eq!(clip_filter(&v, "foo  world"), vec![2]);
        assert_eq!(clip_filter(&v, "ruž"), vec![3]);
        assert_eq!(clip_filter(&v, "nič"), Vec::<usize>::new());
    }
}
