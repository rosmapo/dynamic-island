//! Okno panela (`--action NAZOV`): poll nad Waylandom + budík vlákien + časovače. Proces beží, kým je panel otvorený.
use crate::config::{Config, Theme};
use crate::data::Msg;
use crate::fonts::Fonts;
use crate::render::Renderer;
use crate::sys::{self, Tx, Waker};
use crate::text::Text;
use crate::ui::{Action, Ui};
use crate::wl::{PtrEvent, Wl};
use std::os::unix::process::CommandExt;
use std::process::{Command, Stdio};
use std::time::{Duration, Instant};

/// Rozdelí príkaz na slová, ak neobsahuje žiadnu shell syntax (pipe, presmerovanie, úvodzovky, premenné,
/// `~`, zástupné znaky, `VAR=hodnota` na začiatku…). Inak `None` a príkaz sa pošle do `sh -c`.
fn simple_command(cmd: &str) -> Option<Vec<String>> {
    const SPECIAL: &[char] = &[
        '|', '&', ';', '<', '>', '(', ')', '$', '`', '"', '\'', '\\', '*', '?', '[', ']', '{', '}', '~', '#', '!', '\n',
    ];
    if cmd.contains(SPECIAL) {
        return None;
    }
    let words: Vec<String> = cmd.split_whitespace().map(str::to_string).collect();
    let first = words.first()?;
    if first.contains('=') || matches!(first.as_str(), "exec" | "cd" | "export" | "." | "source" | "eval" | "set" | "umask") {
        return None;
    }
    Some(words)
}

/// Príkaz pripravený na spustenie oddelene od okna launchera (vlastná session = vlastná skupina procesov).
pub(crate) fn session_command(cmd: &str) -> Command {
    // Jednoduchý príkaz (len program a argumenty, bez shell syntaxe) sa spustí priamo – inak by v zozname
    // procesov ostal medzistupeň `sh -c program` (dash nerobí `exec` sám). Zložitejšie príkazy idú cez `sh -c`.
    let mut c = match simple_command(cmd) {
        Some(words) => {
            let mut c = Command::new(&words[0]);
            c.args(&words[1..]);
            c
        }
        None => {
            let mut c = Command::new("sh");
            c.arg("-c").arg(cmd);
            c
        }
    };
    c.stdin(Stdio::null()).stdout(Stdio::null()).stderr(Stdio::null());
    unsafe {
        c.pre_exec(|| {
            sys::new_session();
            Ok(())
        });
    }
    c
}

/// Spustí príkaz oddelene od okna launchera (vlastná session, bez čakania).
pub fn spawn_detached(cmd: &str) {
    if let Ok(mut child) = session_command(cmd).spawn() {
        std::thread::spawn(move || {
            let _ = child.wait();
        });
    }
}

/// Spustí `sh -c cmd` a pošle mu `input` (+ nový riadok) na vstup; beží oddelene od okna launchera.
fn spawn_with_stdin(cmd: &str, input: String) {
    let mut c = Command::new("sh");
    c.arg("-c").arg(cmd).stdin(Stdio::piped()).stdout(Stdio::null()).stderr(Stdio::null());
    unsafe {
        c.pre_exec(|| {
            sys::new_session();
            Ok(())
        });
    }
    if let Ok(mut child) = c.spawn() {
        std::thread::spawn(move || {
            if let Some(mut si) = child.stdin.take() {
                use std::io::Write;
                let _ = si.write_all(input.as_bytes());
                let _ = si.write_all(b"\n");
            }
            let _ = child.wait();
        });
    }
}

/// Najdlhší čas, ktorý má príkaz `exec` položky menu na dokončenie; potom sa ukončí a výstup ostane prázdny.
const MENU_EXEC_TIMEOUT: Duration = Duration::from_secs(5);

/// Spustí `cmd` cez `sh -c` a vráti jeho štandardný výstup (blokuje, volať z vlákna). Pri prekročení `timeout`
/// príkaz ukončí a vráti prázdny reťazec.
fn run_capture(cmd: &str, timeout: Duration) -> String {
    use std::io::Read;
    let mut c = Command::new("sh");
    c.arg("-c").arg(cmd).stdin(Stdio::null()).stdout(Stdio::piped()).stderr(Stdio::null());
    unsafe {
        c.pre_exec(|| {
            sys::die_with_parent();
            Ok(())
        });
    }
    let Ok(mut child) = c.spawn() else { return String::new() };
    let Some(mut out) = child.stdout.take() else { return String::new() };
    // čítanie v samostatnom vlákne po kúskoch: potomok, ktorý by držal rúru otvorenú, nás nezablokuje
    // a už prečítaný výstup nestratíme
    let (rtx, rrx) = std::sync::mpsc::channel::<Vec<u8>>();
    std::thread::spawn(move || {
        let mut buf = [0u8; 4096];
        while let Ok(n) = out.read(&mut buf) {
            if n == 0 || rtx.send(buf[..n].to_vec()).is_err() {
                break;
            }
        }
    });
    let start = Instant::now();
    let finished = loop {
        match child.try_wait() {
            Ok(Some(_)) => break true,
            Ok(None) if start.elapsed() < timeout => std::thread::sleep(Duration::from_millis(15)),
            _ => break false,
        }
    };
    if !finished {
        let _ = child.kill();
        let _ = child.wait();
        return String::new();
    }
    // príkaz skončil: pozbierať, čo prišlo (koniec rúry alebo najviac 300 ms čakania na potomkov)
    let mut all = Vec::new();
    let until = Instant::now() + Duration::from_millis(300);
    while let Ok(chunk) = rrx.recv_timeout(until.saturating_duration_since(Instant::now())) {
        all.extend_from_slice(&chunk);
    }
    String::from_utf8_lossy(&all).into_owned()
}

fn run_action(a: Action, cfg: &Config, tx: &Tx<Msg>) {
    match a {
        Action::MenuExec { gen, idx, cmd } => {
            // výstup príde na pozadí ako `Msg::MenuExec`; hlavná slučka medzitým nečaká
            let tx = tx.clone();
            let opts = crate::sysinfo::Opts { decimal: cfg.sys_decimal.clone(), net_iface: cfg.sys_net_iface.clone() };
            std::thread::spawn(move || {
                // `builtin:ZDROJ` = natívny zdroj (CPU, RAM, disk, sieť, teplota), inak príkaz cez shell
                let raw = match cmd.trim().strip_prefix("builtin:") {
                    Some(spec) => crate::sysinfo::eval(spec, &opts),
                    None => run_capture(&cmd, MENU_EXEC_TIMEOUT),
                };
                tx.send(Msg::MenuExec(gen, idx, crate::data::menu_exec_line(&raw)));
            });
        }
        Action::ClipLoad => {
            // história sa načíta na pozadí, hlavná slučka dostane `Msg::Clip`
            let (cmd, max, tx) = (cfg.clip_list.clone(), cfg.clip_max, tx.clone());
            std::thread::spawn(move || {
                let out = Command::new("sh").arg("-c").arg(&cmd).stdin(Stdio::null()).stderr(Stdio::null()).output();
                let entries = match out {
                    Ok(o) => crate::data::parse_clip_list(&String::from_utf8_lossy(&o.stdout), max),
                    Err(_) => Vec::new(),
                };
                tx.send(Msg::Clip(entries));
            });
        }
        Action::ClipCopy(line) => spawn_with_stdin(&cfg.clip_copy, line),
        Action::TrashLoad => {
            let tx = tx.clone();
            std::thread::spawn(move || {
                tx.send(Msg::Trash(crate::trash::load_all(), String::new()));
            });
        }
        Action::TrashRestore(items) => {
            let tx = tx.clone();
            std::thread::spawn(move || {
                let note = crate::trash::restore_all(&items);
                tx.send(Msg::Trash(crate::trash::load_all(), note));
            });
        }
        Action::TrashEmpty(items) => {
            let tx = tx.clone();
            std::thread::spawn(move || {
                let note = crate::trash::empty_all(&items);
                tx.send(Msg::Trash(crate::trash::load_all(), note));
            });
        }
        Action::Audio(cmd) => crate::audio::run(cmd, cfg.vol_limit, tx.clone()),
        Action::Wifi(cmd) => crate::wifi::run(cmd, tx.clone()),
        Action::Monitor(cmd) => crate::monitor::run(cmd, cfg.monitor.clone(), tx.clone()),
        // snímanie beží v samostatnom procese (prežije zatvorenie okna)
        Action::Capture(req) => crate::capture::run(req, cfg),
        Action::Bluetooth(cmd) => crate::bluetooth::run(cmd, cfg.bluetooth.clone(), tx.clone()),
        Action::WifiPaste => crate::wifi::paste(tx.clone()),
        Action::WallLoad => crate::wallpaper::load(cfg.wall.clone(), tx.clone()),
        Action::WallApply { path, background_only } => crate::wallpaper::apply(cfg.wall.clone(), path, background_only, tx.clone()),
        Action::WallTheme(Some((name, path))) => crate::wallpaper::set_theme(cfg.wall.clone(), name, path, tx.clone()),
        Action::WallTheme(None) => crate::wallpaper::clear_theme(&cfg.wall),
        Action::Run(cmd) => spawn_detached(&cmd),
    }
}

/// Rozbor `DL_FROM` (`ŠÍRKAxVÝŠKA` v logických px); neplatné alebo nulové = `None`.
fn parse_from(s: &str) -> Option<(f32, f32)> {
    let (w, h) = s.trim().split_once('x')?;
    let (w, h) = (w.trim().parse::<f32>().ok()?, h.trim().parse::<f32>().ok()?);
    (w.is_finite() && h.is_finite() && w > 20.0 && h > 20.0).then_some((w, h))
}

/// Otvorí panel `name` v samostatnom okne v strede obrazovky a beží, kým sa panel nezatvorí
/// (Esc, klik na položku menu, tlačidlo zatvorenia alebo druhé spustenie – to proces ukončí zvonka).
/// Zatvorenie je okamžité; animuje sa len prepínanie medzi panelmi.
pub fn run_panel(cfg: Config, name: String) -> Result<(), String> {
    let _guard = crate::drun::PidGuard::new("window");
    let waker = Waker::new();
    let (tx, rx) = sys::channel::<Msg>(waker.clone());

    let fonts = Fonts::load(&cfg.font_family, &cfg.icon_family)?;
    let mut text = Text::new(Box::new(fonts));

    let mut wl = Wl::new_with(cfg.surface_w, cfg.surface_h, true, "dynamic-launcher-panel")?;
    let mut scale = wl.st.scale.max(1);
    let egl = wl.create_egl((cfg.surface_w as i32) * scale, (cfg.surface_h as i32) * scale)?;
    let mut renderer = Renderer::new(&egl)?;

    let theme = Theme::load(&cfg);
    let mut ui = Ui::new(cfg.clone(), theme, scale as f32);
    if !ui.open_named(&name) {
        return Err(format!("'{name}' sa nedá otvoriť (neznámy názov alebo prázdne menu)"));
    }
    // otvorené zo spúšťača (`DL_FROM` = `ŠÍRKAxVÝŠKA` jeho okna, logické px): rozmer pružinou dorastie z neho
    if let Some((w, h)) = std::env::var("DL_FROM").ok().as_deref().and_then(parse_from) {
        ui.start_from(w, h);
    }
    // premenná platila len pre toto okno, aplikácie spustené z panela ju nededia
    std::env::remove_var("DL_FROM");
    for a in ui.take_queued() {
        run_action(a, &cfg, &tx);
    }

    let mut dirty = true;
    let mut animating = false;
    let mut last_frame = Instant::now();
    let mut last_input: Option<Option<(i32, i32, i32, i32)>> = None;
    let mut first_draw = true;
    let mut ready_sent = false;
    let mut kb_on = false;

    loop {
        let now = Instant::now();
        if ui.tick(now) {
            dirty = true;
        }
        // akcie vzniknuté časovačom (obnovenie položiek menu s `interval`)
        for a in ui.take_queued() {
            run_action(a, &cfg, &tx);
        }
        if ui.finished() {
            return Ok(());
        }

        // koľko môžeme spať
        let can_draw = (dirty || animating) && !wl.st.frame_pending;
        let timeout_ms = if can_draw {
            0
        } else {
            ui.next_deadline().map(|d| d.saturating_duration_since(now).as_millis().min(60_000) as i32 + 1).unwrap_or(60_000)
        };

        let ready = wl.wait_events(&[waker.fd()], timeout_ms)?;
        if wl.st.closed {
            return Ok(());
        }

        if ready[0] {
            waker.drain();
            while let Ok(m) = rx.try_recv() {
                ui.apply(m, Instant::now());
                dirty = true;
            }
        }

        // ukazovateľ
        let evs: Vec<PtrEvent> = std::mem::take(&mut wl.st.ptr_events);
        for e in evs {
            let now = Instant::now();
            match e {
                PtrEvent::Enter(x, y) | PtrEvent::Motion(x, y) => ui.pointer_move(x as f32, y as f32, now),
                PtrEvent::Leave => ui.pointer_leave(now),
                PtrEvent::Button(b, true) if cfg.close_button != 0 && b == cfg.close_button => return Ok(()),
                PtrEvent::Button(b, true) => {
                    for a in ui.click(b, now) {
                        run_action(a, &cfg, &tx);
                    }
                }
                PtrEvent::Button(b, false) => ui.release(b, now),
                PtrEvent::Scroll(v) => ui.scroll(v as f32),
            }
            // akcie vzniknuté pohybom / kolieskom (posuvník hlasitosti)
            for a in ui.take_queued() {
                run_action(a, &cfg, &tx);
            }
            dirty = true;
        }

        // klávesnica (Esc, filter schránky, heslo Wi-Fi)
        for k in std::mem::take(&mut wl.st.key_events) {
            for a in ui.key(&k) {
                run_action(a, &cfg, &tx);
            }
            dirty = true;
        }
        let mut want_kb = ui.wants_keyboard();
        if want_kb && !wl.keyboard_ready() {
            // bez mapy kláves by sme klávesnicu zobrali a nevedeli ju použiť – radšej písanie zrušiť
            ui.keyboard_unavailable();
            want_kb = false;
        }
        if want_kb != kb_on {
            wl.set_keyboard(want_kb);
            kb_on = want_kb;
            dirty = true;
        }
        if ui.finished() {
            return Ok(());
        }

        // zmena mierky
        if wl.st.scale_dirty {
            scale = wl.st.scale.max(1);
            wl.apply_scale(cfg.surface_w as i32 * scale, cfg.surface_h as i32 * scale);
            ui.set_scale(scale as f32);
            dirty = true;
        }

        // kreslenie
        if (dirty || animating) && !wl.st.frame_pending {
            let now = Instant::now();
            let dt = if first_draw { 0.0 } else { now.duration_since(last_frame).as_secs_f32().min(0.05) };
            first_draw = false;
            last_frame = now;
            animating = ui.update(dt, now, &mut text);
            let frame = ui.build(&mut text);
            let ir = ui.input_rect();
            if last_input != Some(ir) {
                wl.set_input_region(ir);
                last_input = Some(ir);
            }
            renderer.draw(cfg.surface_w * scale as u32, cfg.surface_h * scale as u32, &frame, &mut text, &mut ui.icons);
            wl.request_frame();
            if !egl.swap() {
                return Err("eglSwapBuffers zlyhalo".into());
            }
            // prvý frame je na obrazovke: spúšťač, z ktorého panel vzišiel, môže zosvetlieť a skončiť
            if !ready_sent {
                ready_sent = true;
                crate::drun::signal_ready();
            }
            dirty = false;
        }
    }
}
