//! Zatvorenie okna odchodom myši (`[drun] autoclose`): časovač, ktorý sa spustí odchodom myši z okna a zruší sa jej
//! návratom alebo stlačením klávesy. Oneskorenie je `[launcher] collapse_delay_ms`.
use std::time::{Duration, Instant};

pub struct LeaveTimer {
    enabled: bool,
    delay: Duration,
    at: Option<Instant>,
}

impl LeaveTimer {
    pub fn new(enabled: bool, delay_ms: u64) -> LeaveTimer {
        LeaveTimer { enabled, delay: Duration::from_millis(delay_ms), at: None }
    }

    /// Myš odišla z okna. `blocked`: okno sa nemá zatvoriť (napr. rozpísaný filter, zadávanie hesla).
    pub fn leave(&mut self, now: Instant, blocked: bool) {
        self.at = if self.enabled && !blocked { Some(now + self.delay) } else { None };
    }

    /// Myš sa vrátila do okna alebo sa stlačila klávesa: zatvorenie sa zruší.
    pub fn cancel(&mut self) {
        self.at = None;
    }

    /// Termín zatvorenia (pre výpočet čakania v hlavnej slučke).
    pub fn deadline(&self) -> Option<Instant> {
        self.at
    }

    /// Oneskorenie už uplynulo – okno sa má zatvoriť.
    pub fn due(&self, now: Instant) -> bool {
        self.at.map(|t| now >= t).unwrap_or(false)
    }

    /// Ako dlho smie slučka čakať na udalosti (ms): najviac `max`, no nie za termín zatvorenia.
    pub fn timeout_ms(&self, now: Instant, max: i32) -> i32 {
        match self.at {
            Some(t) => t.saturating_duration_since(now).as_millis().min(max.max(0) as u128) as i32 + 1,
            None => max,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn disabled_never_closes() {
        let mut t = LeaveTimer::new(false, 100);
        let now = Instant::now();
        t.leave(now, false);
        assert!(t.deadline().is_none());
        assert!(!t.due(now + Duration::from_secs(10)));
        assert_eq!(t.timeout_ms(now, 1000), 1000);
    }

    #[test]
    fn closes_after_delay() {
        let mut t = LeaveTimer::new(true, 700);
        let now = Instant::now();
        t.leave(now, false);
        assert!(!t.due(now + Duration::from_millis(699)));
        assert!(t.due(now + Duration::from_millis(700)));
        // čakanie slučky nepresiahne termín
        assert_eq!(t.timeout_ms(now, 1000), 701);
        assert_eq!(t.timeout_ms(now + Duration::from_millis(650), 1000), 51);
        assert_eq!(t.timeout_ms(now, 300), 301);
    }

    #[test]
    fn return_or_key_cancels() {
        let mut t = LeaveTimer::new(true, 100);
        let now = Instant::now();
        t.leave(now, false);
        t.cancel();
        assert!(!t.due(now + Duration::from_secs(1)));
    }

    #[test]
    fn blocked_leave_does_not_close() {
        let mut t = LeaveTimer::new(true, 100);
        let now = Instant::now();
        t.leave(now, true);
        assert!(!t.due(now + Duration::from_secs(1)));
        // blokovaný odchod zruší aj skôr naplánované zatvorenie
        t.leave(now, false);
        t.leave(now, true);
        assert!(t.deadline().is_none());
    }
}
