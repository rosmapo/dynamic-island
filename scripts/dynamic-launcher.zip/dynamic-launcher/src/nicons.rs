//! Hľadanie PNG ikony podľa názvu v nainštalovaných témach ikon (záloha pre `.desktop` ikony).
use std::collections::HashMap;
use std::path::{Path, PathBuf};
use std::sync::{Mutex, OnceLock};

pub fn fnv(data: &[u8], w: u32, h: u32) -> u64 {
    let mut x: u64 = 0xcbf2_9ce4_8422_2325;
    for b in w.to_le_bytes().iter().chain(h.to_le_bytes().iter()).chain(data.iter()) {
        x ^= *b as u64;
        x = x.wrapping_mul(0x0000_0100_0000_01b3);
    }
    x
}

fn cache() -> &'static Mutex<HashMap<String, Option<PathBuf>>> {
    static C: OnceLock<Mutex<HashMap<String, Option<PathBuf>>>> = OnceLock::new();
    C.get_or_init(|| Mutex::new(HashMap::new()))
}

/// Nájde PNG ikonu podľa názvu (bez prípony); výsledok (aj neúspech) sa pamätá.
pub fn find_theme_icon(name: &str) -> Option<PathBuf> {
    if name.is_empty() || name.contains('/') || name.contains("..") {
        return None;
    }
    if let Some(hit) = cache().lock().ok().and_then(|c| c.get(name).cloned()) {
        return hit;
    }
    let found = search_theme_icon(name);
    if let Ok(mut c) = cache().lock() {
        c.insert(name.to_string(), found.clone());
    }
    found
}

const SIZES: [&str; 8] = ["64x64", "48x48", "96x96", "128x128", "256x256", "32x32", "512x512", "24x24"];
const CONTEXTS: [&str; 9] = ["apps", "status", "actions", "devices", "categories", "mimetypes", "places", "emblems", "notifications"];

fn search_theme_icon(name: &str) -> Option<PathBuf> {
    let home = std::env::var("HOME").unwrap_or_default();
    let bases = [
        PathBuf::from(&home).join(".local/share/icons"),
        PathBuf::from(&home).join(".icons"),
        PathBuf::from("/usr/local/share/icons"),
        PathBuf::from("/usr/share/icons"),
    ];
    let file = format!("{name}.png");
    for base in &bases {
        let Ok(rd) = std::fs::read_dir(base) else { continue };
        let mut themes: Vec<PathBuf> = rd.flatten().map(|e| e.path()).filter(|p| p.is_dir()).collect();
        // hicolor je štandardná záloha s PNG ikonami aplikácií – ide prvá
        themes.sort_by_key(|p| (p.file_name().map(|n| n != "hicolor").unwrap_or(true), p.clone()));
        for theme in themes {
            for size in SIZES {
                let short = size.split('x').next().unwrap_or(size);
                for ctx in CONTEXTS {
                    for cand in [theme.join(size).join(ctx).join(&file), theme.join(ctx).join(short).join(&file)] {
                        if cand.is_file() {
                            return Some(cand);
                        }
                    }
                }
            }
        }
    }
    let px = Path::new("/usr/share/pixmaps").join(&file);
    if px.is_file() {
        return Some(px);
    }
    None
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn invalid_names() {
        assert!(find_theme_icon("../x").is_none());
        assert!(find_theme_icon("").is_none());
    }

    #[test]
    fn hash_differs_by_size() {
        assert_ne!(fnv(&[1, 2, 3, 4], 1, 1), fnv(&[1, 2, 3, 4], 2, 1));
    }
}
