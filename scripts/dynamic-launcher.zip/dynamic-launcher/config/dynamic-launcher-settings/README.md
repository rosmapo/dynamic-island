# dynamic-launcher-settings

Grafické nastavenia pre dynamic-launcher (Python + GTK4 + libadwaita), samostatný nástroj. Upravuje
`~/.config/dynamic-launcher/config.toml` a **zachová komentáre**, poradie a formátovanie súboru.

## Závislosti (Debian 13)

    sudo apt install python3-gi gir1.2-adw-1 gir1.2-gtk-4.0

## Spustenie

    ./dynamic-launcher-settings                 # ~/.config/dynamic-launcher/config.toml
    ./dynamic-launcher-settings -c cesta.toml   # iný súbor

Dá sa spustiť aj z menu: položka `command = "~/.config/dynamic-launcher/dynamic-launcher-settings/dynamic-launcher-settings"`.

## Rozloženie

Taby hore, vľavo sekcie tabu, vpravo možnosti:

| Tab | Sekcie |
|---|---|
| Vzhľad | Okno a písmo (`[launcher]`: písmo, zaoblenie, krytie, **tlačidlo myši na zatvorenie**), Farby |
| Spúšťač | `drun`, kontajner `quickset` (záložky + druhá lišta), schránka a všetky panely: tapety, kôš, Wi-Fi, Bluetooth, monitor, zvuk, snímanie (vrátane notifikácií: `notify_ms`, `video_notify_ms`, `hide_notice`) |
| Vlastné menu | bočný zoznam tvoria priamo konkrétne menu (`sysmenu`, `radio`, `settings`…); vpravo vlastnosti menu a jeho položky; „Pridať menu“ dole, presun a zmazanie v hlavičke vlastností |
| Systém | `[system]` |

Hore je hľadanie vo všetkých kľúčoch. Zmeny sa zapíšu až tlačidlom **Použiť** (záloha `config.toml.bak-…`, kontrola
parserom). ↶ vráti predvolenú hodnotu (riadok sa v súbore zakomentuje). Kľúče, ktoré GUI nepozná, ostanú v súbore
nedotknuté. Zmena sa prejaví pri ďalšom otvorení okna launchera (každé okno je nový proces).

Oproti nastaveniam dynamic-island zmizli: poradie modulov, lišta, notifikácie, vlastné moduly, tracker modulov
(`track`), autohide, jas a všetky moduly lišty.

## Údržba schémy

Predvolené hodnoty a rozsahy generuje `tools/gen_schema.py` zo zdrojov launchera (`schema_gen.json`); slovenské názvy,
voľby a špeciálne kľúče sú v `schema.py`. Po pridaní novej voľby:

    tools/gen_schema.py /cesta/k/dynamic-launcher
    python3 -m unittest discover -s tests

## Stav testovania

`tests/test_model.py` overuje model proti vzorovému `config.toml` (žiadne neznáme kľúče, zápis so zachovaním komentárov,
reset). Samotné okno GTK nebolo v tomto prostredí spustené (nie je tam GTK) – prvé spustenie môže ukázať drobnosti.
