"""Schéma nastavení: spája automaticky vygenerované kľúče (schema_gen.json z kódu ostrovčeka: predvolené hodnoty a
rozsahy) s ručne písanými slovenskými názvami, voľbami a špeciálnymi (indexovanými) kľúčmi.

Typy: bool | int | float | str | color | path | command | icon | enum | strlist | numlist | font | modules
"""
import json, os

HERE = os.path.dirname(os.path.abspath(__file__))

# skupiny v navigácii: (názov, [(sekcia, názov stránky), ...]); poradie ako v config.toml
GROUPS = [
    ('Vzhľad', [('launcher', 'Okno a písmo'), ('colors', 'Farby')]),
    ('Spúšťač', [('drun', 'Spúšťač aplikácií (drun)'), ('quickset', 'Kontajner (quickset)'), ('clipboard', 'Schránka'),
                 ('wallpaper', 'Tapety'), ('trash', 'Kôš'), ('wifi', 'Wi-Fi'), ('bluetooth', 'Bluetooth'),
                 ('monitor', 'Monitor'), ('audio', 'Zvuk'), ('capture', 'Snímanie obrazovky')]),
    ('Systém', [('system', 'Systém')]),
]

# bežné názvy kľúčov
GENERIC = {
    'font_size': 'Veľkosť písma', 'rows': 'Počet viditeľných riadkov', 'columns': 'Počet stĺpcov', 'width': 'Šírka',
    'height': 'Výška', 'radius': 'Zaoblenie rohov', 'opacity': 'Krytie pozadia', 'padding': 'Odsadenie', 'gap': 'Medzera',
    'icon': 'Ikona', 'icon_size': 'Veľkosť ikony', 'on_click': 'Ľavý klik', 'on_click_right': 'Pravý klik',
    'on_click_middle': 'Stredný klik', 'tooltip': 'Tooltip', 'enabled': 'Zapnuté', 'step': 'Krok',
    'editor_command': 'Príkaz tlačidla správcu', 'editor_icon': 'Ikona tlačidla správcu', 'editor_label': 'Text tlačidla správcu',
    'text': 'Text', 'file': 'Súbor', 'notify': 'Posielať notifikácie', 'timeout_ms': 'Čas zobrazenia (ms)',
    'text_size': 'Veľkosť písma', 'hover': 'Zvýraznenie pod kurzorom', 'search': 'Zobraziť pole hľadania',
}

# (sekcia, kľúč) -> názov
LABELS = {
    ('launcher', 'font_scale'): 'Násobiteľ všetkých písem', ('launcher', 'font_size'): 'Základná veľkosť písma',
    ('launcher', 'radius'): 'Zaoblenie okna panelov', ('launcher', 'opacity'): 'Krytie pozadia',
    ('launcher', 'shadow'): 'Tieň', ('launcher', 'surface_width'): 'Šírka priehľadného povrchu',
    ('launcher', 'surface_height'): 'Výška priehľadného povrchu', ('launcher', 'colors_file'): 'Súbor s farbami (matugen)',
    ('launcher', 'font_family'): 'Písmo (zoznam, záložné za čiarkou)', ('launcher', 'icon_family'): 'Písmo ikon (Nerd Font)',
    ('launcher', 'close_button'): 'Tlačidlo myši na zatvorenie okna',
    ('launcher', 'collapse_delay_ms'): 'Oneskorenie zatvorenia odchodom myši (ms)', ('drun', 'autoclose'): 'Zatvoriť okno odchodom myši (drun, schránka, panely)',
    ('drun', 'show'): 'Čo zobraziť v bunke', ('drun', 'name_size'): 'Veľkosť názvu', ('drun', 'cell_width'): 'Šírka bunky (0 = auto)',
    ('drun', 'cell_height'): 'Výška bunky (0 = auto)', ('drun', 'cell_radius'): 'Zaoblenie zvýraznenej bunky',
    ('drun', 'radius'): 'Zaoblenie okna', ('drun', 'opacity'): 'Krytie okna (−1 = ako [launcher])',
    ('drun', 'order'): 'Zoraďovanie', ('drun', 'terminal'): 'Terminál pre aplikácie s Terminal=true',
    ('drun', 'icon_theme'): 'Téma ikon (prázdne = podľa GTK)', ('drun', 'desktop'): 'Pracovné prostredie (OnlyShowIn)',
    ('audio', 'step'): 'Krok hlasitosti kolieskom (%)', ('audio', 'limit'): 'Strop hlasitosti (1.0 = 100 %)',
    ('audio', 'panel_font_size'): 'Veľkosť písma', ('audio', 'panel_width'): 'Šírka', ('audio', 'panel_rows'): 'Počet riadkov',
    ('clipboard', 'max_items'): 'Najviac položiek', ('clipboard', 'list_command'): 'Príkaz na zoznam histórie',
    ('clipboard', 'copy_command'): 'Príkaz na skopírovanie', ('clipboard', 'search'): 'Pole hľadania',
    ('clipboard', 'window_radius'): 'Zaoblenie okna',
    ('trash', 'confirm_empty'): 'Potvrdzovať vysypanie', ('trash', 'show_location'): 'Zobraziť pôvodné umiestnenie', ('trash', 'show_date'): 'Zobraziť dátum vymazania',
    ('wallpaper', 'directory'): 'Adresár s obrázkami', ('wallpaper', 'thumb_width'): 'Šírka náhľadu', ('wallpaper', 'command'): 'Skript na nastavenie tapety',
    ('wallpaper', 'cache_dir'): 'Adresár cache', ('wallpaper', 'themes_directory'): 'Adresár tém (*.json)', ('wallpaper', 'theme_width'): 'Šírka ponuky tém',
    ('wallpaper', 'hover_ring'): 'Rámik pod kurzorom', ('wallpaper', 'current_ring'): 'Rámik aktuálnej tapety',
    ('wallpaper', 'button_max_width'): 'Najväčšia šírka tlačidla (0 = bez limitu)',
    ('bluetooth', 'scan_ms'): 'Trvanie skenovania (ms)',
    ('monitor', 'bus'): 'I²C bus (ddcutil)', ('monitor', 'presets'): 'Presety teploty (VCP 0x14)', ('monitor', 'preset_labels'): 'Popisy presetov',
    ('monitor', 'inputs'): 'Vstupy (VCP 0x60)', ('monitor', 'input_labels'): 'Popisy vstupov',
    ('monitor', 'night_switcher'): 'Skript nočného režimu', ('monitor', 'night_state'): 'Príkaz stavu nočného režimu', ('monitor', 'night_label'): 'Popis nočného režimu',
    ('capture', 'mode'): 'Predvolená oblasť', ('capture', 'kind'): 'Predvolený typ', ('capture', 'format'): 'Formát obrázka', ('capture', 'video_ext'): 'Prípona videa',
    ('capture', 'dir'): 'Adresár snímok', ('capture', 'video_dir'): 'Adresár videí', ('capture', 'name'): 'Vzor názvu súboru (strftime)',
    ('capture', 'cursor'): 'Kurzor na snímke', ('capture', 'audio'): 'Zvuk pri nahrávaní', ('capture', 'output'): 'Výstup pre režim Screen (prázdne = všetky)',
    ('capture', 'slurp_args'): 'Argumenty slurp (vzhľad výberu)', ('capture', 'recorder_args'): 'Ďalšie argumenty wf-recorder',
    ('capture', 'copy'): 'Kopírovať snímku do schránky', ('capture', 'delays'): 'Ponúkané časovače (s)',
    ('capture', 'notify'): 'Posielať notifikácie (odpočet, stav, uložené)', ('capture', 'notify_ms'): 'Notifikácia o uloženej snímke (ms, 0 = kým ju nezavrieš)',
    ('capture', 'video_notify_ms'): 'Notifikácia pri videu (ms, 0 = trvalá s časom; zavretie ukončí nahrávanie)',
    ('capture', 'hide_notice'): 'Skryť notifikáciu pred snímkou', ('capture', 'settle_ms'): 'Pauza po skrytí notifikácie (ms)',
    ('system', 'decimal'): 'Desatinný oddeľovač', ('system', 'net_interface'): 'Rozhranie pre net-down / net-up',
    ('quickset', 'tab_gap'): 'Medzera medzi záložkami', ('quickset', 'tabs_position'): 'Poloha lišty', ('quickset', 'tab_size'): 'Veľkosť tlačidla záložky',
    ('quickset', 'inversetab_gap'): 'Medzera medzi tlačidlami druhej lišty (0 = ako pri záložkách)', ('quickset', 'preload'): 'Načítať údaje monitora vopred',
    ('quickset', 'inversetab'): 'Druhá lišta (inversetab)', ('quickset', 'width'): 'Celková šírka (px, prázdne = auto)', ('quickset', 'height'): 'Celková výška (px, prázdne = auto)',
}

# výber z možností
CHOICES = {
    ('drun', 'show'): ['icon', 'name', 'icon+name-right', 'icon+name-below'], ('drun', 'order'): ['horizontal', 'vertical'],
    ('capture', 'mode'): ['screen', 'region'], ('capture', 'kind'): ['image', 'video'],
    ('capture', 'format'): ['png', 'jpeg'], ('capture', 'video_ext'): ['mp4', 'mkv', 'webm'],
    ('quickset', 'tabs_position'): ['left', 'right', 'top', 'bottom'],
    ('launcher', 'close_button'): ['', 'left', 'right', 'middle', 'side', 'extra', 'task'],
    ('system', 'decimal'): [',', '.'],
}

TYPE_OVERRIDE = {('launcher', 'colors_file'): 'path', ('wallpaper', 'directory'): 'path', ('wallpaper', 'cache_dir'): 'path',
                 ('wallpaper', 'themes_directory'): 'path', ('wallpaper', 'command'): 'command', ('capture', 'dir'): 'path',
                 ('capture', 'video_dir'): 'path',
                 ('clipboard', 'list_command'): 'command', ('clipboard', 'copy_command'): 'command',
                 ('monitor', 'night_switcher'): 'command', ('monitor', 'night_state'): 'command',
                 ('brightness', 'get'): 'command', ('brightness', 'set'): 'command', ('drun', 'terminal'): 'command',
                 ('drun', 'opacity'): 'float', ('launcher', 'opacity'): 'float', ('audio', 'limit'): 'float',
                 ('quickset', 'inversetab_gap'): 'int'}

# kľúče, ktoré kód číta inak než cez `*_or` (v schema_gen.json nie sú)
EXTRA = [
    dict(section='launcher', key='font_family', type='strlist', default=['Inter'], desc='Prvé nájdené písmo sa použije; ďalšie sú záložné.'),
    dict(section='launcher', key='icon_family', type='strlist', default=['Symbols Nerd Font Mono']),
    dict(section='launcher', key='close_button', type='enum', default='', choices=['', 'left', 'right', 'middle', 'side', 'extra', 'task'],
         choice_labels={'': 'žiadne', 'left': 'ľavé', 'right': 'pravé', 'middle': 'stredné', 'side': 'bočné BACK (BTN_SIDE)',
                        'extra': 'bočné FORWARD (BTN_EXTRA)', 'task': 'BTN_TASK'},
         desc='Navyše k Esc, skratke a kliku na položku menu. V config.toml môže byť aj číselný kód tlačidla.'),
    dict(section='quickset', key='inversetab', type='bool', default=False, desc='Druhá lišta na opačnej strane; jej tlačidlá neotvárajú panel v kontajneri.'),
    dict(section='quickset', key='width', type='int', default=None, min=120, max=3000, nullable=True),
    dict(section='quickset', key='height', type='int', default=None, min=120, max=3000, nullable=True),
    dict(section='monitor', key='presets', type='numlist', default=[5, 6, 8], desc='VCP hodnoty teplotného presetu (0x14); desiatkovo.'),
    dict(section='monitor', key='inputs', type='numlist', default=[15, 17], desc='VCP hodnoty vstupu (0x60): 15 = DisplayPort, 17 = HDMI.'),
    dict(section='capture', key='delays', type='numlist', default=[0, 3, 5, 10]),
] + [dict(section='colors', key=k, type='color', default=d, label=l, desc=dd) for k, d, l, dd in [
    ('background', '@surface', 'Pozadie', 'Hodnota „@meno“ z colors_file alebo „#rrggbb“.'),
    ('foreground', '@primary', 'Text', ''), ('accent', '@primary', 'Zvýraznenie', ''), ('on_accent', '@surface', 'Text na zvýraznení', ''),
    ('menu_selected', '', 'Vybraná položka – pozadie', 'Prázdne = ako zvýraznenie.'), ('menu_selected_text', '', 'Vybraná položka – text', 'Prázdne = ako text na zvýraznení.'),
    ('alert', '#dc2f2f', 'Výstraha', ''), ('on_alert', '#ffffff', 'Text na výstrahe', '')]]

# doplnené hranice (kód ich nekontroluje, ale hodnoty mimo nedávajú zmysel)
BOUNDS = {('launcher', 'opacity'): (0.0, 1.0), ('drun', 'opacity'): (-1.0, 1.0), ('audio', 'limit'): (0.1, 2.0)}

# indexované kľúče: (sekcia, názov skupiny, [(vzor kľúča, názov poľa, typ)], najviac)
INDEXED = [
    ('quickset', 'Záložky kontajnera', [('tab{i}', 'Panel', 'tab'), ('tab{i}_icon', 'Ikona', 'icon')], 8,
     'Panel: audio, bluetooth, wifi, monitor, clipboard, trash, wallpaper, capture alebo menu:NÁZOV.'),
    ('quickset', 'Tlačidlá druhej lišty', [('inversetab{i}', 'Príkaz / panel', 'command'), ('inversetab{i}_icon', 'Ikona', 'icon')], 8,
     'Príkaz alebo akcia (napr. menu:capture, wifi, systemctl suspend).'),
    ('wallpaper', 'Tlačidlá v hlavičke tapiet', [('button{i}_label', 'Text', 'str'), ('button{i}_command', 'Príkaz', 'command')], 16,
     'Tlačidlo sa zobrazí len ak má text.'),
]
# tabuľka kľúč -> hodnota: (sekcia, názov, popis)
MAPS = []


def _f(key, type_, label, default=None, desc='', **kw):
    d = dict(key=key, type=type_, label=label, default=default, desc=desc, min=None, max=None)
    d.update(kw)
    return d


def _specs(*fields):
    return {f['key']: f for f in fields}


MENU_SPECS = _specs(
    _f('name', 'str', 'Názov menu', '', 'Spúšťa sa `dynamic-launcher --action názov`; v quickset ako záložka tab = "menu:názov".', write_default=True),
    _f('title', 'str', 'Nadpis', '', 'Prázdne = bez nadpisu.'),
    _f('type', 'enum', 'Typ', '', 'Automaticky podľa položiek (ikony / text / zmiešané).', choices=['', 'icons', 'text', 'hybrid'],
       choice_labels={'': 'automaticky', 'icons': 'ikony', 'text': 'text', 'hybrid': 'zmiešané'}),
    _f('columns', 'int', 'Stĺpce (spoločné)', 3, 'Záloha pre icon_columns a text_columns.', min=1),
    _f('icon_columns', 'int', 'Stĺpce ikon', None, '0 = podľa spoločných stĺpcov.', min=1, nullable=True),
    _f('text_columns', 'int', 'Stĺpce textu', None, '0 = podľa spoločných stĺpcov (pri čistom texte 1).', min=1, nullable=True),
    _f('rows', 'int', 'Najviac riadkov', None, '0 = všetky; viac položiek sa posúva kolieskom.', min=1, nullable=True),
    _f('icon_size', 'int', 'Veľkosť ikony', 28, min=8), _f('text_size', 'int', 'Veľkosť písma', 15, min=8),
    _f('cell_width', 'int', 'Šírka bunky', 120, min=20), _f('gap', 'int', 'Medzera', 8, min=0), _f('padding', 'int', 'Odsadenie', 12, min=0),
    _f('separator_thickness', 'float', 'Hrúbka oddeľovača', 1.5, min=0.5, max=20.0),
    _f('separator_length', 'float', 'Dĺžka oddeľovača (0.1–1)', 0.6, min=0.1, max=1.0),
    _f('wait_exec', 'bool', 'Počkať na výstupy pred otvorením', False, 'Menu sa otvorí, až keď sa načítajú hodnoty položiek s exec.'),
    _f('wait_timeout_ms', 'int', 'Najdlhšie čakanie (ms)', 1500, min=100, max=30000),
)
ITEM_SPECS = _specs(
    _f('separator', 'enum', 'Oddeľovač', '', 'Vodorovná čiara namiesto položky; poloha čiary v riadku.', choices=['', 'top', 'center', 'bottom'],
       choice_labels={'': 'nie je oddeľovač', 'top': 'čiara hore', 'center': 'čiara v strede', 'bottom': 'čiara dole'}),
    _f('line', 'str', 'Riadok (text na celú šírku)', '', 'Namiesto položky: text cez celú šírku menu ({} = výstup exec). Prázdny riadok len v config.toml: line = "".'),
    _f('icon', 'str', 'Ikona (súbor)', '', 'PNG v icons/ vedľa config.toml alebo plná cesta.'),
    _f('label', 'str', 'Text', '', 'S exec je to šablóna, {} sa nahradí výstupom.'),
    _f('command', 'command', 'Príkaz / akcia', '', 'Príkaz (napr. foot, mpv URL, pkill -x mpv) alebo module:wallpaper – otvorí iný panel s animáciou.'),
    _f('exec', 'command', 'Zdroj hodnoty (exec)', '', 'Príkaz alebo builtin:cpu, builtin:ram, builtin:disk:/ …'),
    _f('interval', 'int', 'Obnovovanie exec (s)', 0, '0 = raz pri otvorení.', min=0),
)
# pole tabuliek: id stránky -> popis
ARRAYS = {
    'menu': dict(title='Vlastné menu', family='menu', specs=MENU_SPECS, child=('menu.item', ITEM_SPECS), key='name', add='Pridať menu',
                 child_add='Pridať položku', desc='Otvárajú sa `dynamic-launcher --action názov` (napr. v .desktop) alebo ako záložka menu:názov. Rádio: príkaz „pkill -x mpv; mpv URL“.'),
}



def _kind_type(r, sec, key):
    if (sec, key) in TYPE_OVERRIDE:
        return TYPE_OVERRIDE[(sec, key)]
    if (sec, key) in CHOICES:
        return 'enum'
    k = r['kind']
    if k == 'bool_or':
        return 'bool'
    if k == 'strs':
        return 'strlist'
    if k == 'f64_or':
        d = r.get('default')
        return 'int' if d is None or float(d).is_integer() else 'float'
    if key in ('icon', 'icon_paused', 'icon_muted', 'icon_ethernet', 'icon_disconnected', 'editor_icon'):
        return 'icon'
    if key in ('on_click', 'on_click_right', 'on_click_middle', 'exec', 'command', 'editor_command') or key.endswith('_command'):
        return 'command'
    return 'str'


def build():
    """Zoznam kľúčov (dict) so všetkými vlastnosťami, v poradí GROUPS."""
    gen = json.load(open(os.path.join(HERE, 'schema_gen.json'), encoding='utf8'))
    out = {}
    for r in gen:
        sec, key = r['section'], r['key']
        t = _kind_type(r, sec, key)
        e = dict(section=sec, key=key, type=t, default=r['default'], min=r['min'], max=r['max'], desc=r['comment'])
        if t == 'int' and e['default'] is not None:
            e['default'] = int(e['default'])
        if t in ('int', 'float') and e['default'] is None:
            e['nullable'] = True
        if t == 'enum':
            e['choices'] = CHOICES[(sec, key)]
        out[(sec, key)] = e
    for x in EXTRA:
        e = dict(min=None, max=None, desc='', default=None)
        e.update(x)
        out[(e['section'], e['key'])] = e
    for (sec, key), (lo, hi) in BOUNDS.items():
        if (sec, key) in out:
            out[(sec, key)]['min'], out[(sec, key)]['max'] = lo, hi
    for (sec, key), e in out.items():
        e.setdefault('label', None)
        e['label'] = e['label'] or LABELS.get((sec, key)) or GENERIC.get(key) or key
        if 'icon_list' in e:
            e['type'] = 'strlist'
    return out


def sections_in_order():
    for g, items in GROUPS:
        for sec, title in items:
            yield g, sec, title
