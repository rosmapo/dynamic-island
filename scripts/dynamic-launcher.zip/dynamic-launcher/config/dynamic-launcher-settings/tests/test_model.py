"""Testy modelu nastavení proti vzorovému config.toml launchera (bez GTK)."""
import os, shutil, sys, tempfile, unittest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, '..'))
import schema
from model import Model

SAMPLE = os.environ.get('DL_CONFIG') or os.path.join(HERE, '..', '..', 'dynamic-launcher', 'config.toml')


class ModelTest(unittest.TestCase):
    def setUp(self):
        self.dir = tempfile.mkdtemp()
        self.path = os.path.join(self.dir, 'config.toml')
        shutil.copy(SAMPLE, self.path)
        self.m = Model(self.path)

    def tearDown(self):
        shutil.rmtree(self.dir)

    def test_sample_has_no_unknown_keys(self):
        self.assertEqual(self.m.unknown(), [])

    def test_sample_values(self):
        self.assertEqual(self.m.value('launcher', 'close_button'), 'side')
        self.assertEqual(self.m.value('capture', 'video_notify_ms'), 0)
        names = [r['fields'].get('name') for r in self.m.get_array('menu')]
        self.assertIn('radio', names)

    def test_every_schema_section_is_navigable(self):
        nav = {sec for _g, sec, _t in schema.sections_in_order()}
        used = {s for (s, _k) in self.m.schema}
        self.assertFalse(used - nav, used - nav)

    def test_roundtrip_keeps_comments(self):
        self.m.set('capture', 'notify_ms', 1500)
        self.m.set('launcher', 'close_button', 'extra')
        self.m.save()
        text = open(self.path, encoding='utf8').read()
        self.assertIn('notify_ms = 1500', text)
        self.assertIn('close_button = "extra"', text)
        self.assertIn('# Konfigurácia dynamic-launcher', text)
        self.assertEqual(Model(self.path).value('capture', 'notify_ms'), 1500)

    def test_reset_comments_out(self):
        self.m.reset('launcher', 'close_button')
        self.m.save()
        text = open(self.path, encoding='utf8').read()
        self.assertNotIn('\nclose_button = "side"', text)

    def test_schema_defaults_match_code(self):
        # kľúče bez predvolenej hodnoty v kóde majú byť len nullable / zoznamy / farby
        for (sec, key), e in self.m.schema.items():
            self.assertIn('label', e)
            self.assertTrue(e['label'], (sec, key))


if __name__ == '__main__':
    unittest.main()
